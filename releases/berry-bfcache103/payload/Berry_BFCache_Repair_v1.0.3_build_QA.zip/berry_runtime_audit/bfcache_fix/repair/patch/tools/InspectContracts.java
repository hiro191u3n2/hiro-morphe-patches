import app.hiro.berrybfcache.patches.ExactBody;
import com.android.tools.smali.dexlib2.Opcodes;
import com.android.tools.smali.dexlib2.dexbacked.DexBackedDexFile;
import com.android.tools.smali.dexlib2.iface.*;
import com.android.tools.smali.dexlib2.formatter.DexFormatter;
import java.util.zip.*;
public final class InspectContracts {
 public static void main(String[] args) throws Exception {
  if(args[0].equals("reflect")) { for(int k=1;k<args.length;k++) { Class<?> c=Class.forName(args[k]); System.out.println(c); for(java.lang.reflect.Constructor<?> x:c.getConstructors())System.out.println(x);for(java.lang.reflect.Method x:c.getDeclaredMethods())System.out.println(x); } return; }
  try(ZipFile zip=new ZipFile(args[0])) { java.util.Enumeration<? extends ZipEntry> es=zip.entries(); while(es.hasMoreElements()) { ZipEntry e=es.nextElement(); if(!e.getName().matches("classes[0-9]*\\.dex"))continue; DexBackedDexFile d=DexBackedDexFile.fromInputStream(Opcodes.getDefault(),new java.io.BufferedInputStream(zip.getInputStream(e)));for(ClassDef c:d.getClasses())for(Method m:c.getMethods()) {String desc=DexFormatter.INSTANCE.getMethodDescriptor(m);for(int k=1;k<args.length;k++)if(desc.equals(args[k])) {System.out.println(desc);try{System.out.println(ExactBody.sha256(m)); System.out.println(ExactBody.canonical(m));}catch(Exception ex){System.out.println(ex);}}} } }
 }
}
