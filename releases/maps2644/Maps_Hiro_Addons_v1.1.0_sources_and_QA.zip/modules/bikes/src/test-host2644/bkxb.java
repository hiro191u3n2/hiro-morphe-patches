public final class bkxb { public bkww t; }
