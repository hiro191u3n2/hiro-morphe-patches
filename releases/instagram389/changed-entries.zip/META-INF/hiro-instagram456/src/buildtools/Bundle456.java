import java.nio.file.*;
import java.util.*;
import java.util.zip.*;
import java.io.*;
import org.objectweb.asm.*;
import com.android.tools.smali.dexlib2.iface.*;
import com.android.tools.smali.dexlib2.dexbacked.DexBackedDexFile;
import com.android.tools.smali.dexlib2.writer.pool.DexPool;
import com.android.tools.smali.dexlib2.writer.io.FileDataStore;

public final class Bundle456 {
    private static final String PACKAGE="app/hiro/oneback/patches/";
    private static final String CONTEXT="Lapp/morphe/patcher/patch/BytecodePatchContext;";
    static byte[] route(byte[] input,boolean patchBody) {
        ClassReader reader=new ClassReader(input);
        ClassWriter writer=new ClassWriter(reader,ClassWriter.COMPUTE_MAXS);
        int[] matched={0};
        reader.accept(new ClassVisitor(Opcodes.ASM9,writer) {
            public MethodVisitor visitMethod(int flags,String method,String desc,String sig,String[] errors) {
                MethodVisitor parent=super.visitMethod(flags,method,desc,sig,errors);
                if (patchBody && method.equals("invoke") && desc.equals("("+CONTEXT+")Lkotlin/Unit;")) {
                    matched[0]++;
                    return new MethodVisitor(Opcodes.ASM9,parent) {
                        public void visitCode() {
                            super.visitCode();
                            Label legacy=new Label();
                            visitVarInsn(Opcodes.ALOAD,1);
                            visitMethodInsn(Opcodes.INVOKESTATIC,PACKAGE+"Instagram456Patch","applyIfSelected","("+CONTEXT+")Z",false);
                            visitJumpInsn(Opcodes.IFEQ,legacy);
                            visitFieldInsn(Opcodes.GETSTATIC,"kotlin/Unit","INSTANCE","Lkotlin/Unit;");
                            visitInsn(Opcodes.ARETURN);
                            visitLabel(legacy);
                            visitFrame(Opcodes.F_SAME,0,null,0,null);
                        }
                    };
                }
                if (!patchBody && method.equals("<clinit>")) return new MethodVisitor(Opcodes.ASM9,parent) {
                    public void visitLdcInsn(Object value) {
                        if (value instanceof String && ((String)value).startsWith("Instagram 452.")) {
                            value="Instagram 456.0.0.53.78のホーム・リールで戻ると終了し、履歴から削除します。プロフィールから戻るとリールへ移動します。"+value;
                            matched[0]++;
                        }
                        super.visitLdcInsn(value);
                    }
                };
                return parent;
            }
        },0);
        if(matched[0]!=1)throw new IllegalStateException("Unexpected baseline class");
        return writer.toByteArray();
    }
    public static void main(String[] args)throws Exception {
        if(args[0].equals("route")) {
            try (ZipFile base=new ZipFile(args[1])) {
                for(String cls:Arrays.asList("OneBackPatch","OneBackPatch$3")) {
                    String name=PACKAGE+cls+".class";
                    byte[] previous=base.getInputStream(base.getEntry(name)).readAllBytes();
                    Path out=Paths.get(args[2],name); Files.createDirectories(out.getParent());
                    Files.write(out,route(previous,cls.endsWith("$3")));
                }
            }
            return;
        }
        com.android.tools.smali.dexlib2.Opcodes ops=com.android.tools.smali.dexlib2.Opcodes.getDefault();
        DexBackedDexFile oldDex=DexBackedDexFile.fromInputStream(ops,new ByteArrayInputStream(Files.readAllBytes(Paths.get(args[1]))));
        DexBackedDexFile edits=DexBackedDexFile.fromInputStream(ops,new ByteArrayInputStream(Files.readAllBytes(Paths.get(args[2]))));
        DexPool out=new DexPool(ops);Set<String> changed=new HashSet<>();
        for(ClassDef cls:edits.getClasses()) {
            String t=cls.getType();
            if(!t.equals("L"+PACKAGE+"OneBackPatch;")&&!t.equals("L"+PACKAGE+"OneBackPatch$3;")&&!t.equals("L"+PACKAGE+"Instagram456Patch;"))
                throw new IllegalStateException("Unexpected DEX class "+t);
            out.internClass(cls);changed.add(t);
        }
        if(changed.size()!=3)throw new IllegalStateException("Wrong provider DEX class count");
        for(ClassDef cls:oldDex.getClasses())if(!changed.contains(cls.getType()))out.internClass(cls);
        FileDataStore target=new FileDataStore(new File(args[3]));try{out.writeTo(target);}finally{target.close();}
    }
}
