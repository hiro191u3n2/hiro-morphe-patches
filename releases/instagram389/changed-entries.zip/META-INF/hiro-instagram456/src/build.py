"""Build the combined MPP using the shipped 1.0.388 bundle and supplied tool jars."""
import copy
import argparse
import hashlib
import subprocess
import tempfile
import zipfile
from pathlib import Path

ROOT = Path(__file__).resolve().parent
BASE_HASH = '39f499da5554ab400aec857656d9ab606a260a600d55218c5308cc431d2302d5'

def pack(path, directory):
    with zipfile.ZipFile(path,'w') as out:
        for file in sorted(directory.rglob('*.class')):
            out.write(file,file.relative_to(directory))

def main():
    p = argparse.ArgumentParser(description=__doc__)
    p.add_argument('base', type=Path)
    p.add_argument('tools', type=Path, help='Directory with morphe.jar, ecj.jar, asm.jar, d8.jar and android.jar')
    p.add_argument('output', type=Path)
    args = p.parse_args()
    if hashlib.sha256(args.base.read_bytes()).hexdigest() != BASE_HASH:
        raise ValueError('Expected the original 1.0.388 bundle')
    def jar(name):
        return str(args.tools / (name+'.jar'))
    def run(*command):
        subprocess.run(['java','-XX:-UsePerfData',*map(str,command)],check=True)
    with tempfile.TemporaryDirectory() as stage, zipfile.ZipFile(args.base) as base:
        work = Path(stage)
        for d in ['tools','provider','runtime','runtime-dex','provider-dex']:
            (work/d).mkdir()
        def compile_dir(name,source,classpath,level):
            run('-jar',jar('ecj'),'-nowarn','-source',level,'-target',level,'-cp',classpath,'-d',work/name,*sorted((ROOT/source).glob('*.java')))
        compile_dir('tools','buildtools',jar('morphe')+':'+jar('asm'),'11')
        compile_dir('provider','provider',jar('morphe'),'8')
        compile_dir('runtime','runtime',jar('android'),'8')
        toolcp=str(work/'tools')+':'+jar('morphe')+':'+jar('asm')
        run('-cp',toolcp,'Bundle456','route',args.base,work/'provider')
        for target in ['provider','runtime']:
            part=work/(target+'.jar')
            pack(part,work/target)
            options=['--no-desugaring'] if target=='provider' else ['--lib',jar('android')]
            run('-cp',jar('d8'),'com.android.tools.r8.D8','--min-api','26',*options,'--output',work/(target+'-dex'),part)
        (work/'old.dex').write_bytes(base.read('classes.dex'))
        run('-Xmx2g','-cp',toolcp,'Bundle456','merge',work/'old.dex',work/'provider-dex/classes.dex',work/'merged.dex')
        mf='META-INF/MANIFEST.MF'
        manifest=base.read(mf).replace(b'Version: 1.0.388',b'Version: 1.0.389').replace(b'2026-11-20T00:00:00',b'2026-11-21T00:00:00').replace(b'NewX Japanese and display settings use Piko dependencies \r\n and bytecode structure across versions.', b'Instagram 456.0.0.53.78 Back support.')
        assert b'\r\nVersion: 1.0.389\r\n' in manifest
        changes={mf:manifest, 'classes.dex':(work/'merged.dex').read_bytes(),
                 'extensions/instagram456.mpe':(work/'runtime-dex/classes.dex').read_bytes()}
        for file in (work/'provider').rglob('*.class'):
            changes[str(file.relative_to(work/'provider'))]=file.read_bytes()
        source_files=[Path(__file__).resolve(), *sorted(ROOT.glob('*/*.java'))]
        sources={'META-INF/hiro-instagram456/src/'+str(file.relative_to(ROOT)):file.read_bytes() for file in source_files}
        changes.update(sources)
        with zipfile.ZipFile(args.output,'w') as out:
            for entry in base.infolist():
                out.writestr(copy.copy(entry),changes.pop(entry.filename,base.read(entry)))
            for name,data in sorted(changes.items()):
                info=zipfile.ZipInfo(name,(2026,11,21,0,0,0))
                out.writestr(info,data,compress_type=zipfile.ZIP_DEFLATED)
        with zipfile.ZipFile(args.output) as out:
            assert out.testzip() is None
            diffs={name for name in base.namelist() if base.read(name)!=out.read(name)}
            assert diffs=={mf,'classes.dex','app/hiro/oneback/patches/OneBackPatch.class','app/hiro/oneback/patches/OneBackPatch$3.class'}
            assert set(out.namelist())-set(base.namelist())==set(sources)|{'app/hiro/oneback/patches/Instagram456Patch.class','extensions/instagram456.mpe'}
if __name__=='__main__': main()
