import app.morphe.patcher.patch.*;
import app.hiro.berrybfcache.patches.BfCacheRepairPatch;
import kotlin.Unit;
public final class QaOnly {
 public static final BytecodePatch PATCH = PatchKt.bytecodePatch("QA only: apply BFCache repair to known modified input", "Local JVM test wrapper; never a user deliverable", false, builder -> {
  builder.extendWith(() -> QaOnly.class.getClassLoader().getResourceAsStream(BfCacheRepairPatch.EXTENSION));
  builder.execute(context -> { BfCacheRepairPatch.applyRepair(context); return Unit.INSTANCE; });
  return Unit.INSTANCE;
 });
}
