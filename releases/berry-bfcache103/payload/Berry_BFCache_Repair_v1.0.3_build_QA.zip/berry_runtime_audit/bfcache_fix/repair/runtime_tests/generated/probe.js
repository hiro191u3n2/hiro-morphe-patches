(function(){var s=window.__hiroBerryBFCacheRestoreV1;if(!s||typeof s.id!=='string'||typeof s.serial!=='number')return null;return 'B1|'+s.id+'|'+s.serial+'|'+(s.pending===true?'1':'0');})()
