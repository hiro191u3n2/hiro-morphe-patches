# Maps 26.44 bicycle runtime schema review

Input: uploaded original `26.44.06.1006895251` APK; comparison: original Maps `26.36.04.973607363` base APK. This is bytecode/schema and host verification, not Android UI execution.

## Result

The marker runtime can retain its filtering behavior with the verified reflected class names below. Public instance fields and the public static override resolver retain their expected types/signature. `Lcncl;` extends `java.util.List`.

| 26.36 | 26.44 | Role |
|---|---|---|
| cift | cige | placed label: c point-kind, f layer list |
| cifq | cigb | layer: c kind, d oneof value |
| cifs | cigd | composed icon: b components |
| cifr | cigc | icon component: c source |
| cier | cifb | source: b kind, c oneof value |
| bkjj | bkxb | legacy style: t icon |
| bkje | bkww | legacy composed icon: b URL, c components |
| bkjc | bkwu | legacy component: b URL |
| bken | bksd | public static j(ImmutableList, icon) override resolver |
| chue | chuj | per-feature override: b bitmask, c ID, d bytes, e color, f URL |

**Correction:** `chue -> chuk` is incorrect. `chuk` is a collection wrapper containing `chuj`. Actual `Lbksd.j` casts override items to `Lchuj;` and uses the fields above.

## CompactLegend

The protobuf message-info and ordered field-name strings are byte-for-byte unchanged for LabelStyle `chvx -> chwc`, IconStyle `chuz -> chvf`, and TextBoxStyle `chyj -> chyo`. These preserve the existing wire-field meaning used by BicycleLegendFilter. The shared placed-label protobuf classes and the override schema also retain identical message-info/field-name sequences.

The custom root reader `chyy.c(III) -> chzd.c(III)` has identical field routing after resolving its switch and unconditional branches:

- root 3 -> `e` (LabelStyle slices)
- root 9 -> `j` (IconStyle slices)
- root 10 -> `l` (icon path slices)
- root 11 -> `b` string slot 0 (prefix)
- root 12 -> `b` string slot 1 (suffix)

In both 26.44 style readers, `bkxf.p` and `bkyh.i`, `chwc.m` (wire field 7) is copied into `bkxa.c` and immediately branches past icon/text style construction when true. IconStyle image override ID remains `chvf.d` (wire field 8); TextBox inline icon and indexed-icon fields remain `chyo.r` and `chyo.s`. The resolver still scans overrides backward so the last matching ID wins, checks bit 4 for bytes before bit 1024 for URL, and treats color separately.

The bytecode is not identical: compiler control flow, builder signatures, method names, and registers changed. New strict method fingerprints must be independently pinned; do not reuse old shapes. In particular TextBox dynamicMethod registers increase from 6 to 10 and resolver j instruction count decreases from 132 to 130.

## Artifacts and validation

- `runtime-new/`: updated runtime Java sources (same runtime package/API; class-name adaptation only).
- `test-host-new/`: existing regression fixtures adapted to verified new class names, including chuj.
- `SchemaAudit.java`: reads both actual APKs and checks reflected public fields/types, resolver ABI, nine protobuf message-info sequences, and all root field switch routes.
- `audit-result.txt`: PASS, 284 checks against actual APK bytecode/schema.
- `host-result.txt`: PASS, 352 marker/shared/legacy fixtures; separate LegendFilter run 246 assertions.
- `old-runtime-dump.txt`, `new-runtime-dump.txt`, `new-extra-dump.txt`: bytecode evidence.

The real Roadmap binary fixture was not present in the available workspace; its previous pinned-fixture test was not rerun. The generic LegendFilter implementation is unchanged and the synthetic malformed/override/wire preservation fixtures passed. Android rendering remains unexecuted.
