import java.io.*;import java.util.*;import app.hiro.maps.patches.MapsCategoryRowPatch;import app.morphe.patcher.util.proxy.mutableTypes.*;import com.android.tools.smali.dexlib2.*;import com.android.tools.smali.dexlib2.iface.*;import com.android.tools.smali.dexlib2.iface.instruction.*;import com.android.tools.smali.dexlib2.immutable.*;
public class AuditNew {
static void req(boolean b,String s){if(!b)throw new AssertionError(s);}
static ClassDef read(String p,String t)throws Exception{MultiDexContainer<? extends DexFile>d=DexFileFactory.loadDexContainer(new File(p),Opcodes.getDefault());for(String n:d.getDexEntryNames())for(ClassDef c:d.getEntry(n).getDexFile().getClasses())if(c.getType().equals(t))return c;throw new AssertionError(t);}
static void reject(Runnable r){try{r.run();throw new AssertionError("not rejected");}catch(IllegalStateException expected){}}
public static void main(String[]a)throws Exception{
 Map<String,Set<String>> metadata=new TreeMap<>();
 for(Object entry:(Collection<?>)MapsCategoryRowPatch.PATCH.getClass().getMethod("getCompatiblePackages").invoke(MapsCategoryRowPatch.PATCH)) {kotlin.Pair<?,?> pair=(kotlin.Pair<?,?>)entry;metadata.put((String)pair.getFirst(),new TreeSet<>((Set<String>)pair.getSecond()));}
 req(metadata.keySet().equals(new TreeSet<>(Arrays.asList(MapsCategoryRowPatch.PACKAGE,MapsCategoryRowPatch.STOCK_PACKAGE))),"exact stock/microG metadata");
 for(Set<String> versions:metadata.values())req(versions.equals(new TreeSet<>(Arrays.asList(MapsCategoryRowPatch.VERSION,MapsCategoryRowPatch.VERSION_2644))),"both exact metadata versions");
 String[]versions={MapsCategoryRowPatch.VERSION,MapsCategoryRowPatch.VERSION_2644};String[]codes={MapsCategoryRowPatch.CODE,MapsCategoryRowPatch.CODE_2644};String[]types={MapsCategoryRowPatch.OWNER,MapsCategoryRowPatch.OWNER_2644};
 for(int j=0;j<2;j++){
  for(String p:new String[]{MapsCategoryRowPatch.PACKAGE,MapsCategoryRowPatch.STOCK_PACKAGE})MapsCategoryRowPatch.validatePackage(p,versions[j],codes[j]);
  final int k=j;reject(()->MapsCategoryRowPatch.validatePackage(MapsCategoryRowPatch.PACKAGE,versions[k],codes[1-k]));
  ClassDef c=read(a[j],types[j]);Method orig=MapsCategoryRowPatch.validateClass(c);MutableClass mc=new MutableClass(c);Method before=ImmutableMethod.of(MapsCategoryRowPatch.validateClass(mc));String beforeHash=MapsCategoryRowPatch.fingerprint(before);req(MapsCategoryRowPatch.apply(mc,orig)==1,"one insertion");MutableMethod after=null;for(MutableMethod m:mc.getMethods())if(MapsCategoryRowPatch.isTarget(m))after=m;
  req(after!=null,"target");List<? extends Instruction>ins=after.getImplementation().getInstructions();req(ins.size()==13,"size13");Instruction injected=ins.get(11);req(injected.getOpcode()==Opcode.CONST_4&&((OneRegisterInstruction)injected).getRegisterA()==1&&((NarrowLiteralInstruction)injected).getNarrowLiteral()==0,"null result");req(ins.get(12).getOpcode()==Opcode.RETURN_OBJECT,"return kept");
  reject(()->MapsCategoryRowPatch.validateClass(mc));reject(()->MapsCategoryRowPatch.apply(mc,orig));
  after.getImplementation().removeInstruction(11);req(MapsCategoryRowPatch.fingerprint(after).equals(beforeHash),"entire native method restored after removing added instruction");
  System.out.println("PASS "+versions[j]+" "+types[j]+" exact one null instruction; native body, labels and debug restored; repeat rejected");
 }
 reject(()->MapsCategoryRowPatch.validatePackage(MapsCategoryRowPatch.STOCK_PACKAGE,"26.44.06.1006895252",MapsCategoryRowPatch.CODE_2644));reject(()->MapsCategoryRowPatch.validatePackage("bad.package",MapsCategoryRowPatch.VERSION_2644,MapsCategoryRowPatch.CODE_2644));
 System.out.println("PASS package/version/code guards");
}
}
