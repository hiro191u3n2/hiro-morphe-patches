package app.hiro.oneback.runtime;

import android.app.Activity;
import android.content.Intent;
import android.graphics.Rect;
import android.os.Build;
import android.os.Handler;
import android.os.Looper;
import android.view.View;
import android.view.WindowInsets;
import java.lang.reflect.Method;
import java.util.WeakHashMap;

/** Native Back commit hooks for Instagram 456.0.0.53.78. */
public final class Instagram456Back {
    private static final String MAIN = "com.instagram.mainactivity.InstagramMainActivity";
    private static final String PROFILE = "com.instagram.profile.fragment.UserDetailFragment";
    private static final int CONTAINER = 2131436214;
    private static final WeakHashMap<Activity,Object> pending = new WeakHashMap<>();

    private Instagram456Back() {}
    private static Object get(Object obj, String name) throws ReflectiveOperationException {
        return obj.getClass().getMethod(name).invoke(obj);
    }
    private static Object at(Object manager) throws ReflectiveOperationException {
        return manager.getClass().getMethod("A0P", int.class).invoke(manager, CONTAINER);
    }
    private static boolean is(Object obj, String type) {
        return obj != null && obj.getClass().getName().equals(type);
    }
    private static boolean shown(Object fragment, Activity host) throws ReflectiveOperationException {
        if (fragment == null || get(fragment,"getActivity") != host ||
            !Boolean.TRUE.equals(get(fragment,"isResumed")) || !Boolean.TRUE.equals(get(fragment,"isVisible"))) return false;
        View view = (View)get(fragment,"getView");
        if (view == null || !view.isAttachedToWindow() || !view.isShown() ||
            !view.hasWindowFocus() || view.getRootView() != host.getWindow().getDecorView()) return false;
        WindowInsets insets = view.getRootWindowInsets();
        if (Build.VERSION.SDK_INT >= 30 && insets != null && insets.isVisible(WindowInsets.Type.ime())) return false;
        Rect area = new Rect();
        return view.getGlobalVisibleRect(area) && area.width() * 2 > view.getRootView().getWidth() &&
            area.height() * 2 > view.getRootView().getHeight();
    }
    private static Object nav(Activity host) throws ReflectiveOperationException {
        Object tabs = host.getClass().getField("A08").get(host);
        return tabs == null ? null : tabs.getClass().getField("A03").get(tabs);
    }
    private static Object wrapperChild(Object wrapper) throws ReflectiveOperationException {
        Object child = at(get(wrapper, "getChildFragmentManager"));
        if (child != null) return child;
        return is(wrapper, "X.01wY") ? get(wrapper,"A07") : null;
    }
    /** A viewer opened from a profile can use the same Fragment as the Reels tab. */
    private static boolean root(Object f, Activity host, String tab) throws ReflectiveOperationException {
        if (!is(host, MAIN) || !shown(f, host)) return false;
        Object nav = nav(host);
        if (nav == null || !tab.equals(((Enum<?>)get(nav,"A06")).name())) return false;
        Object wrapper = get(nav,"A05");
        if (!(is(wrapper,"X.01wY") || is(wrapper,"X.02xV"))) return false;
        Object selected = wrapperChild(wrapper);
        Object node = f;
        for (int depth=0; node!=null && depth<12; depth++) {
            if (!Boolean.TRUE.equals(get(node,"isResumed")) || !Boolean.TRUE.equals(get(node,"isVisible"))) return false;
            Object owner = get(node,"getParentFragment");
            if (owner == null || ((Integer)get(get(node,"getParentFragmentManager"),"A0M")) != 0) return false;
            if (owner == wrapper) return node == selected;
            node = owner;
        }
        return false;
    }
    private static boolean rootViewer(Object fragment, Activity host) throws ReflectiveOperationException {
        if (!is(fragment,"X.06ZV") || !root(fragment,host,"CLIPS")) return false;
        Object cfg = get(fragment,"A0i");
        String source = ((Enum<?>)cfg.getClass().getField("A00").get(cfg)).name();
        return source.equals("CLIPS_TAB") || source.equals("CLIPS_TAB_HOMECOMING");
    }
    public static boolean exitRoot(Object fragment) {
        try {
            Activity host = (Activity)get(fragment,"getActivity");
            if (host == null || host.isFinishing() || host.isDestroyed()) return false;
            if (!rootViewer(fragment,host) && !(is(fragment,"X.06iE") && root(fragment,host,"FEED"))) return false;
            host.finishAndRemoveTask();
            return true;
        } catch (ReflectiveOperationException | RuntimeException | LinkageError unavailable) { return false; }
    }
    /** The non-first Reels page normally resets the pager before asking its viewer about Back. */
    public static boolean backOnOtherPage(Object selected) {
        try {
            Object viewer = is(selected,"X.07AW") ? get(selected,"A0h") : selected;
            if (!is(viewer,"X.06ZV")) return false;
            Activity host = (Activity)get(viewer,"getActivity");
            if (host == null || !rootViewer(viewer,host)) return false;
            // Enter the actual viewer callback, including its sheet and overlay guards.
            return Boolean.TRUE.equals(get(viewer,"onBackPressed"));
        } catch (ReflectiveOperationException | RuntimeException | LinkageError unavailable) { return false; }
    }
    private static boolean selectReels(Activity host) throws ReflectiveOperationException {
        Object controller = nav(host);
        if (controller == null) return false;
        Class<?> tabType = Class.forName("X.03cu",false,host.getClassLoader());
        Object clips = tabType.getField("A08").get(null);
        if (!"CLIPS".equals(((Enum<?>)clips).name())) return false;
        host.getClass().getMethod("HjA",tabType).invoke(host,clips);
        return true;
    }
    public static boolean profileResult(Object fragment, boolean consumed) {
        if (consumed) return true;
        try {
            Activity host = (Activity)get(fragment,"getActivity");
            if (host != null && root(fragment,host,"PROFILE") && selectReels(host)) {
                pending.remove(host);
                return true;
            }
        } catch (ReflectiveOperationException | RuntimeException | LinkageError unavailable) { }
        return false;
    }
    private static boolean urlHost(Activity host) {
        return is(host,"com.instagram.url.UrlHandlerActivity") || is(host,"com.instagram.url.UrlHandlerLauncherActivity");
    }
    private static Object currentProfile(Activity host) throws ReflectiveOperationException {
        Object manager;
        if (is(host,MAIN)) manager = get(host,"C0u");
        else if (urlHost(host)) {
            ClassLoader loader = host.getClassLoader();
            Class<?> owner = Class.forName("androidx.fragment.app.FragmentActivity",false,loader);
            Method findManager = Class.forName("X.0BTH",false,loader).getMethod("A0H",owner);
            manager = findManager.invoke(null,host);
        } else return null;
        if (manager == null) return null;
        Object active = at(manager);
        if (active == null && is(host,MAIN)) {
            Object controller = nav(host);
            if (controller != null) active = get(controller,"A05");
        }
        for (int depth=0; active != null && depth<5; depth++) {
            if (is(active,PROFILE)) return shown(active,host) ? active : null;
            active = wrapperChild(active);
        }
        return null;
    }
    /** A committed Back may just dismiss a sheet. Wait for actual profile removal. */
    public static void observe(final Activity host) {
        try {
            final Object f = currentProfile(host);
            if (f != null) observeRemoval(host,f);
        } catch (ReflectiveOperationException | RuntimeException | LinkageError unavailable) { }
    }
    public static void observeProfile(Object f) {
        try {
            Activity host = (Activity)get(f,"getActivity");
            if (host != null && (is(host,MAIN) || urlHost(host)) && shown(f,host)) observeRemoval(host,f);
        } catch (ReflectiveOperationException | RuntimeException | LinkageError unavailable) { }
    }
    private static void observeRemoval(final Activity host, final Object f) throws ReflectiveOperationException {
        if (pending.get(host) == f) return;
        pending.put(host,f);
        final Object parent = get(f,"getParentFragment");
        final Intent intent = host.getIntent();
        new Handler(Looper.getMainLooper()).post(() -> {
            if (pending.get(host) != f) return;
            pending.remove(host);
            try {
                if (host.isChangingConfigurations() || host.getIntent() != intent) return;
                if (!host.isFinishing() && !removed(f) && (parent == null || !removed(parent))) return;
                if (is(host,MAIN) && !host.isFinishing() && !host.isDestroyed()) selectReels(host);
                else if (urlHost(host) || is(host,MAIN)) {
                    Intent reels = new Intent().setClassName(host.getPackageName(),MAIN)
                        .addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP | Intent.FLAG_ACTIVITY_NEW_TASK)
                        .putExtra("INSTAGRAM_MAIN_ACTIVITY_INTENT_ENTRANCE_MODULE_EXTRA_FIELD","CLIPS")
                        .putExtra("MainActivityAccountHelper.STARTUP_TAB","CLIPS")
                        .putExtra("is_cold_start_reel_tab",true);
                    host.startActivity(reels);
                    if (!host.isFinishing()) host.finish();
                }
            } catch (ReflectiveOperationException | RuntimeException | LinkageError unavailable) { }
        });
    }
    private static boolean removed(Object fragment) throws ReflectiveOperationException {
        return !Boolean.TRUE.equals(get(fragment,"isAdded")) || Boolean.TRUE.equals(get(fragment,"isRemoving"));
    }
}
