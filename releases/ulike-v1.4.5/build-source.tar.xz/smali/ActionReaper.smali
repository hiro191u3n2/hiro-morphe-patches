.class public Lcom/ss/android/common/applog/AppLog$ActionReaper;
.super Ljava/lang/Thread;

.method public run()V
    .locals 6

    .line 1
    iget-object v0, p0, Lcom/ss/android/common/applog/AppLog$ActionReaper;->this$0:Lcom/ss/android/common/applog/AppLog;

    iget-object v0, v0, Lcom/ss/android/common/applog/AppLog;->mNetWorkMonitor:Li/f/j/k/a;

    invoke-virtual {v0}, Li/f/j/k/a;->e()V

    .line 2
    invoke-direct {p0}, Lcom/ss/android/common/applog/AppLog$ActionReaper;->tryPrepareUpdateConfig()V

    .line 3
    iget-object v0, p0, Lcom/ss/android/common/applog/AppLog$ActionReaper;->this$0:Lcom/ss/android/common/applog/AppLog;

    invoke-virtual {v0}, Lcom/ss/android/common/applog/AppLog;->setupLogReaper()Z

    move-result v0

    if-nez v0, :cond_0

    const-string v0, "can not setup LogReaper"

    .line 4
    invoke-static {v0}, Li/s/a/n/f/b;->i(Ljava/lang/String;)V

    return-void

    .line 5
    :cond_0
    iget-object v0, p0, Lcom/ss/android/common/applog/AppLog$ActionReaper;->this$0:Lcom/ss/android/common/applog/AppLog;

    invoke-virtual {v0}, Lcom/ss/android/common/applog/AppLog;->ensureHeaderCopy()V

    .line 6
    iget-object v0, p0, Lcom/ss/android/common/applog/AppLog$ActionReaper;->this$0:Lcom/ss/android/common/applog/AppLog;

    invoke-virtual {v0}, Lcom/ss/android/common/applog/AppLog;->checkSessionEnd()V

    :goto_0
    const/4 v0, 0x0

    .line 7
    iget-object v1, p0, Lcom/ss/android/common/applog/AppLog$ActionReaper;->this$0:Lcom/ss/android/common/applog/AppLog;

    iget-object v1, v1, Lcom/ss/android/common/applog/AppLog;->mQueue:Ljava/util/LinkedList;

    monitor-enter v1

    .line 8
    :try_start_0
    sget-boolean v2, Lcom/ss/android/common/applog/AppLog;->sStopped:Z

    if-eqz v2, :cond_1

    .line 9
    monitor-exit v1

    goto :goto_2

    .line 10
    :cond_1
    iget-object v2, p0, Lcom/ss/android/common/applog/AppLog$ActionReaper;->this$0:Lcom/ss/android/common/applog/AppLog;

    iget-object v2, v2, Lcom/ss/android/common/applog/AppLog;->mQueue:Ljava/util/LinkedList;

    invoke-virtual {v2}, Ljava/util/LinkedList;->isEmpty()Z

    move-result v2
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    if-eqz v2, :cond_4

    .line 11
    :try_start_1
    iget-boolean v2, p0, Lcom/ss/android/common/applog/AppLog$ActionReaper;->mCheckEnd:Z

    if-eqz v2, :cond_2

    .line 12
    iget-object v2, p0, Lcom/ss/android/common/applog/AppLog$ActionReaper;->this$0:Lcom/ss/android/common/applog/AppLog;

    iget-object v3, v2, Lcom/ss/android/common/applog/AppLog;->mQueue:Ljava/util/LinkedList;

    iget-wide v4, v2, Lcom/ss/android/common/applog/AppLog;->mSessionInterval:J

    invoke-virtual {v3, v4, v5}, Ljava/lang/Object;->wait(J)V

    goto :goto_1

    .line 13
    :cond_2
    iget-object v2, p0, Lcom/ss/android/common/applog/AppLog$ActionReaper;->this$0:Lcom/ss/android/common/applog/AppLog;

    iget-object v2, v2, Lcom/ss/android/common/applog/AppLog;->mQueue:Ljava/util/LinkedList;

    invoke-virtual {v2}, Ljava/lang/Object;->wait()V
    :try_end_1
    .catch Ljava/lang/InterruptedException; {:try_start_1 .. :try_end_1} :catch_0
    .catchall {:try_start_1 .. :try_end_1} :catchall_0

    .line 14
    :catch_0
    :goto_1
    :try_start_2
    sget-boolean v2, Lcom/ss/android/common/applog/AppLog;->sStopped:Z

    if-eqz v2, :cond_3

    .line 15
    monitor-exit v1
    :try_end_2
    .catchall {:try_start_2 .. :try_end_2} :catchall_0

    :goto_2
    const-string v0, "ActionReadper quit"

    .line 16
    invoke-static {v0}, Li/s/a/n/f/b;->i(Ljava/lang/String;)V

    return-void

    .line 17
    :cond_3
    :try_start_3
    iget-object v2, p0, Lcom/ss/android/common/applog/AppLog$ActionReaper;->this$0:Lcom/ss/android/common/applog/AppLog;

    iget-object v2, v2, Lcom/ss/android/common/applog/AppLog;->mQueue:Ljava/util/LinkedList;

    invoke-virtual {v2}, Ljava/util/LinkedList;->isEmpty()Z

    move-result v2

    if-nez v2, :cond_5

    .line 18
    iget-object v0, p0, Lcom/ss/android/common/applog/AppLog$ActionReaper;->this$0:Lcom/ss/android/common/applog/AppLog;

    iget-object v0, v0, Lcom/ss/android/common/applog/AppLog;->mQueue:Ljava/util/LinkedList;

    invoke-virtual {v0}, Ljava/util/LinkedList;->poll()Ljava/lang/Object;

    move-result-object v0

    check-cast v0, Lcom/ss/android/common/applog/AppLog$ActionQueueItem;

    goto :goto_3

    .line 19
    :cond_4
    iget-object v0, p0, Lcom/ss/android/common/applog/AppLog$ActionReaper;->this$0:Lcom/ss/android/common/applog/AppLog;

    iget-object v0, v0, Lcom/ss/android/common/applog/AppLog;->mQueue:Ljava/util/LinkedList;

    invoke-virtual {v0}, Ljava/util/LinkedList;->poll()Ljava/lang/Object;

    move-result-object v0

    check-cast v0, Lcom/ss/android/common/applog/AppLog$ActionQueueItem;

    .line 20
    :cond_5
    :goto_3
    monitor-exit v1
    :try_end_3
    .catchall {:try_start_3 .. :try_end_3} :catchall_0

    const/4 v1, 0x0

    const/4 v2, 0x1

    if-eqz v0, :cond_6

    .line 21
    iget-object v3, p0, Lcom/ss/android/common/applog/AppLog$ActionReaper;->this$0:Lcom/ss/android/common/applog/AppLog;

    invoke-virtual {v3, v0}, Lcom/ss/android/common/applog/AppLog;->processItem(Lcom/ss/android/common/applog/AppLog$ActionQueueItem;)V

    .line 22
    iput-boolean v2, p0, Lcom/ss/android/common/applog/AppLog$ActionReaper;->mCheckEnd:Z

    goto :goto_4

    .line 23
    :cond_6
    iget-boolean v0, p0, Lcom/ss/android/common/applog/AppLog$ActionReaper;->mCheckEnd:Z

    if-eqz v0, :cond_7

    .line 24
    iput-boolean v1, p0, Lcom/ss/android/common/applog/AppLog$ActionReaper;->mCheckEnd:Z

    .line 25
    iget-object v0, p0, Lcom/ss/android/common/applog/AppLog$ActionReaper;->this$0:Lcom/ss/android/common/applog/AppLog;

    invoke-virtual {v0}, Lcom/ss/android/common/applog/AppLog;->checkSessionEnd()V

    .line 26
    :cond_7
    :goto_4
    iget-object v0, p0, Lcom/ss/android/common/applog/AppLog$ActionReaper;->this$0:Lcom/ss/android/common/applog/AppLog;

    invoke-virtual {v0, v2, v1}, Lcom/ss/android/common/applog/AppLog;->tryUpdateConfig(ZZ)V

    goto :goto_0

    :catchall_0
    move-exception v0

    .line 27
    :try_start_4
    monitor-exit v1
    :try_end_4
    .catchall {:try_start_4 .. :try_end_4} :catchall_0

    throw v0
.end method
