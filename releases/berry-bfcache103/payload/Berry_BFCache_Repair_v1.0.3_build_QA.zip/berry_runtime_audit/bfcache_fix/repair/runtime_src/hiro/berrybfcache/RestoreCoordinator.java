package hiro.berrybfcache;

import android.os.Looper;
import android.util.Log;
import android.webkit.ValueCallback;
import android.webkit.WebView;
import java.lang.ref.WeakReference;
import java.lang.reflect.InvocationHandler;
import java.lang.reflect.Method;
import java.util.WeakHashMap;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

/**
 * Repairs only a positively identified BFCache restore after a visible commit.
 * App bridges must pass a Runnable whose client reference is weak: states must
 * not retain their WeakHashMap key through the completion action.
 */
public final class RestoreCoordinator {
    private static final String TAG = "BerryBFCache";
    private static final String LISTENER = "hiroBerryBFCacheRestoreV1";
    private static final String MESSAGE = "hiro-bfcache-restored-v1";
    private static final WeakHashMap<WebView, State> STATES = new WeakHashMap<WebView, State>();
    private static final Pattern RESULT = Pattern.compile("^\"B1\\|([a-z0-9]{8,64})\\|([0-9]{1,12})\\|([01])\"$");
    private static final String SCRIPT =
        "(function(){'use strict';if(window!==window.top)return;" +
        "var k='__hiroBerryBFCacheRestoreV1';if(Object.prototype.hasOwnProperty.call(window,k))return;" +
        "var s={id:Date.now().toString(36)+Math.random().toString(36).slice(2),serial:0,pending:false};" +
        "Object.defineProperty(window,k,{value:s,enumerable:false,configurable:false,writable:false});" +
        "window.addEventListener('pagehide',function(){s.pending=false;});" +
        "window.addEventListener('pageshow',function(e){s.pending=e.persisted===true;if(!s.pending)return;" +
        "s.serial++;try{var b=window.hiroBerryBFCacheRestoreV1;if(b&&typeof b.postMessage==='function')" +
        "b.postMessage('hiro-bfcache-restored-v1');}catch(ignore){}});})();";
    private static final String PROBE =
        "(function(){var s=window.__hiroBerryBFCacheRestoreV1;" +
        "if(!s||typeof s.id!=='string'||typeof s.serial!=='number')return null;" +
        "return 'B1|'+s.id+'|'+s.serial+'|'+(s.pending===true?'1':'0');})()";

    private static final class State {
        long generation;
        long commitToken;
        long visualRequest;
        boolean committed;
        String url;
        String committedDocument;
        String lastHandledEvent;
        Runnable completion;
        Probe activeProbe;
        boolean probeAgain;
    }

    private static final class Probe {
        final long generation;
        final long commitToken;
        final String url;
        final boolean canBindDocument;
        Probe(State s, boolean bind) {
            generation = s.generation;
            commitToken = s.commitToken;
            url = s.url;
            canBindDocument = bind;
        }
    }

    private static final class Marker {
        final String document;
        final String event;
        final boolean pending;
        Marker(String document, String serial, boolean pending) {
            this.document = document;
            event = document + ":" + serial;
            this.pending = pending && !"0".equals(serial);
        }
    }

    private RestoreCoordinator() {}
    public static String listenerName() { return LISTENER; }
    public static String script() { return SCRIPT; }
    public static InvocationHandler listener() { return new Listener(); }

    public static void started(final WebView view, final String url) {
        if (view == null) return;
        if (!onMainThread()) {
            final WeakReference<WebView> weak = new WeakReference<WebView>(view);
            view.post(new Runnable() { public void run() { started(weak.get(), url); } });
            return;
        }
        State s = state(view);
        s.generation++;
        s.committed = false;
        s.url = null;
        s.committedDocument = null;
        s.completion = null;
        s.activeProbe = null;
        s.probeAgain = false;
    }

    public static void committed(final WebView view, final String url, final Runnable completion) {
        if (view == null || completion == null) return;
        if (!onMainThread()) {
            final WeakReference<WebView> weak = new WeakReference<WebView>(view);
            view.post(new Runnable() { public void run() { committed(weak.get(), url, completion); } });
            return;
        }
        if (!sameUrl(view, url)) return;
        State s = state(view);
        if (s.committed && url.equals(s.url)) {
            // Duplicate commit notification within one navigation must not
            // cancel the visual callback already requested for that restore.
            s.completion = completion;
            probe(view, s, s.committedDocument == null);
            return;
        }
        s.commitToken++;
        s.committed = true;
        s.url = url;
        s.committedDocument = null;
        s.completion = completion;
        s.activeProbe = null;
        s.probeAgain = false;
        probe(view, s, true);
    }

    private static void message(final WebView view) {
        if (view == null) return;
        if (!onMainThread()) {
            final WeakReference<WebView> weak = new WeakReference<WebView>(view);
            view.post(new Runnable() { public void run() { message(weak.get()); } });
            return;
        }
        State s = STATES.get(view);
        if (s != null && s.committed) probe(view, s, false);
    }

    private static void probe(WebView view, State s, boolean mayBind) {
        if (!s.committed || !sameUrl(view, s.url)) return;
        if (s.activeProbe != null) {
            s.probeAgain = true;
            return;
        }
        final Probe p = new Probe(s, mayBind);
        s.activeProbe = p;
        final WeakReference<WebView> weak = new WeakReference<WebView>(view);
        try {
            view.evaluateJavascript(PROBE, new ValueCallback<String>() {
                @Override public void onReceiveValue(String value) {
                    WebView v = weak.get();
                    if (v == null) return;
                    State current = STATES.get(v);
                    if (current == null || current.activeProbe != p) return;
                    current.activeProbe = null;
                    if (!matches(v, current, p)) return;
                    Marker marker = parse(value);
                    if (marker != null) {
                        if (p.canBindDocument) current.committedDocument = marker.document;
                        if (marker.pending && marker.document.equals(current.committedDocument)
                                && !marker.event.equals(current.lastHandledEvent)) {
                            repair(v, current, p, marker);
                        }
                    }
                    // A pageshow wake-up can arrive while a prior read is in flight.
                    // Re-read after that response instead of dropping the notification.
                    if (matches(v, current, p) && current.probeAgain) {
                        current.probeAgain = false;
                        probe(v, current, current.committedDocument == null && p.canBindDocument);
                    }
                }
            });
        } catch (RuntimeException failure) {
            if (s.activeProbe == p) s.activeProbe = null;
            Log.w(TAG, "BFCache marker query was unavailable", failure);
        }
    }

    private static void repair(WebView view, State s, final Probe p, final Marker marker) {
        s.lastHandledEvent = marker.event;
        Runnable completion = s.completion;
        if (completion == null) return;
        try {
            completion.run();
        } catch (RuntimeException failure) {
            Log.w(TAG, "BFCache native completion was unavailable", failure);
            return;
        }
        if (!matches(view, s, p)) return;
        final WeakReference<WebView> weak = new WeakReference<WebView>(view);
        try {
            view.postVisualStateCallback(++s.visualRequest, new WebView.VisualStateCallback() {
                @Override public void onComplete(long requestId) {
                    WebView v = weak.get();
                    if (v == null) return;
                    State current = STATES.get(v);
                    if (current != null && matches(v, current, p)
                            && marker.document.equals(current.committedDocument)
                            && marker.event.equals(current.lastHandledEvent)
                            && v.isAttachedToWindow() && v.isShown()) {
                        v.postInvalidateOnAnimation();
                    }
                }
            });
        } catch (RuntimeException failure) {
            Log.w(TAG, "BFCache visual callback was unavailable", failure);
        }
    }

    private static Marker parse(String value) {
        if (value == null) return null;
        Matcher m = RESULT.matcher(value);
        return m.matches() ? new Marker(m.group(1), m.group(2), "1".equals(m.group(3))) : null;
    }

    private static State state(WebView view) {
        State s = STATES.get(view);
        if (s == null) { s = new State(); STATES.put(view, s); }
        return s;
    }

    private static boolean matches(WebView view, State s, Probe p) {
        return s.committed && s.generation == p.generation && s.commitToken == p.commitToken
            && p.url.equals(s.url) && sameUrl(view, p.url);
    }

    private static boolean sameUrl(WebView view, String url) {
        if (url == null || url.length() == 0) return false;
        try { return url.equals(view.getUrl()); }
        catch (RuntimeException destroyed) { return false; }
    }

    private static boolean onMainThread() {
        return Looper.myLooper() == Looper.getMainLooper();
    }

    private static final class Listener implements InvocationHandler {
        @Override public Object invoke(Object proxy, Method method, Object[] args) throws Throwable {
            String name = method.getName();
            if ("getSupportedFeatures".equals(name)) return new String[] { "WEB_MESSAGE_LISTENER" };
            if ("toString".equals(name)) return "BerryBFCacheRestoreListener";
            if ("hashCode".equals(name)) return Integer.valueOf(System.identityHashCode(this));
            if ("equals".equals(name)) return Boolean.valueOf(args != null && args.length == 1 && proxy == args[0]);
            if (!"onPostMessage".equals(name) || args == null || args.length != 5
                    || !(args[0] instanceof WebView) || !(args[1] instanceof InvocationHandler)
                    || !Boolean.TRUE.equals(args[3])) return null;
            Object data;
            try {
                Class<?> boundary = Class.forName("org.chromium.support_lib_boundary.WebMessageBoundaryInterface", false,
                    RestoreCoordinator.class.getClassLoader());
                Method getData = boundary.getMethod("getData");
                data = ((InvocationHandler) args[1]).invoke(null, getData, new Object[0]);
            } catch (Throwable malformed) {
                if (malformed instanceof Error) throw malformed;
                return null;
            }
            if (MESSAGE.equals(data)) message((WebView) args[0]);
            return null;
        }
    }
}
