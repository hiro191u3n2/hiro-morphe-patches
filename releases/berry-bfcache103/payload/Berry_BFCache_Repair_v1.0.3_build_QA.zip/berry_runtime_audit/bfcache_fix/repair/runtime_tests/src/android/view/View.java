package android.view;
import java.util.ArrayList;
public class View {
    public boolean attached = true;
    public boolean shown = true;
    public int invalidations;
    public final ArrayList<Runnable> posts = new ArrayList<Runnable>();
    public boolean post(Runnable runnable) { posts.add(runnable); return true; }
    public void flushPosts() {
        android.os.Looper.background = false;
        while (!posts.isEmpty()) posts.remove(0).run();
    }
    public boolean isAttachedToWindow() { return attached; }
    public boolean isShown() { return shown; }
    public void postInvalidateOnAnimation() { invalidations++; }
}
