package app.hiro.oneback.patches;

import app.morphe.patcher.patch.BytecodePatchContext;
import app.morphe.patcher.util.proxy.mutableTypes.MutableMethod;
import com.android.tools.smali.dexlib2.Opcode;
import com.android.tools.smali.dexlib2.Opcodes;
import com.android.tools.smali.dexlib2.builder.*;
import com.android.tools.smali.dexlib2.builder.instruction.*;
import com.android.tools.smali.dexlib2.dexbacked.DexBackedDexFile;
import com.android.tools.smali.dexlib2.iface.*;
import com.android.tools.smali.dexlib2.iface.instruction.*;
import com.android.tools.smali.dexlib2.immutable.reference.ImmutableMethodReference;
import java.io.*;
import java.util.*;

public final class Instagram456Patch {
    private static final String RT="Lapp/hiro/oneback/runtime/Instagram456Back;";
    private static final String OBJ="Ljava/lang/Object;", ACT="Landroid/app/Activity;";
    private static final String REELS="LX/06ZV;", HOME="LX/06iE;";
    private static final String MAIN="Lcom/instagram/mainactivity/InstagramMainActivity;";
    private static final String PROFILE="Lcom/instagram/profile/fragment/UserDetailFragment;";

    private Instagram456Patch() {}
    private static void require(boolean ok, String why) {
        if (!ok) throw new IllegalStateException("Instagram 456.0.0.53.78 Back: "+why);
    }
    private static MutableMethod method(BytecodePatchContext context,String owner,String name,String result,String... args) {
        for (Method m:context.mutableClassDefBy(owner).getMethods())
            if (m.getName().equals(name) && m.getReturnType().equals(result) && m.getParameterTypes().equals(Arrays.asList(args)) &&
                (m.getAccessFlags() & 8)==0 && m.getImplementation()!=null) return (MutableMethod)m;
        throw new IllegalStateException("Missing Instagram 456 method "+owner+"->"+name);
    }
    private static BuilderInstruction35c call(String name,String result,int self,String type) {
        return new BuilderInstruction35c(Opcode.INVOKE_STATIC,1,self,0,0,0,0,new ImmutableMethodReference(RT,name,Collections.singletonList(type),result));
    }
    private static boolean ref(Instruction ins,String target) {
        return ins instanceof ReferenceInstruction && ((ReferenceInstruction)ins).getReference().toString().equals(target);
    }
    private static List<Integer> incoming(List<BuilderInstruction> ins,int to) {
        List<Integer> result=new ArrayList<>();
        for(int i=0;i<ins.size();i++) if(ins.get(i) instanceof BuilderOffsetInstruction &&
            ((BuilderOffsetInstruction)ins.get(i)).getTarget().getLocation().getIndex()==to) result.add(i);
        return result;
    }
    /** Replace the instruction at the join so existing native labels enter the new gate. */
    private static void exitGate(MutableMethod m,int at,int self,String expected, List<Integer> edges) {
        MutableMethodImplementation b=m.getImplementation();
        List<BuilderInstruction> ins=b.getInstructions();
        require(b.getRegisterCount()==self+1 && ref(ins.get(at),expected) && incoming(ins,at).equals(edges),m+" layer boundary differs");
        BuilderInstruction nativeOp=ins.get(at);
        if (nativeOp.getOpcode()==Opcode.IGET_OBJECT) {
            TwoRegisterInstruction op=(TwoRegisterInstruction)nativeOp;
            require(op.getRegisterA()==0 && op.getRegisterB()==self,"Reels scratch register changed");
        } else {
            require(nativeOp.getOpcode()==Opcode.INVOKE_VIRTUAL && ((FiveRegisterInstruction)nativeOp).getRegisterC()==self &&
                ((FiveRegisterInstruction)nativeOp).getRegisterCount()==1 && ins.get(at+1).getOpcode()==Opcode.MOVE_RESULT_OBJECT &&
                ((OneRegisterInstruction)ins.get(at+1)).getRegisterA()==0,"Home scratch register changed");
        }
        b.replaceInstruction(at,call("exitRoot","Z",self,OBJ));
        b.addInstruction(at+1,new BuilderInstruction11x(Opcode.MOVE_RESULT,0));
        b.addInstruction(at+2,new BuilderInstruction10x(Opcode.NOP));
        b.addInstruction(at+3,new BuilderInstruction11x(Opcode.RETURN,0));
        b.addInstruction(at+4,nativeOp);
        b.replaceInstruction(at+2,new BuilderInstruction21t(Opcode.IF_EQZ,0,b.newLabelForIndex(at+4)));
    }
    private static void otherPage(MutableMethod m) {
        MutableMethodImplementation b=m.getImplementation();
        List<BuilderInstruction> ins=b.getInstructions();
        String pager="LX/08NU;";
        require(b.getRegisterCount()==5 && ins.get(10).getOpcode()==Opcode.IF_EQZ &&
            ((BuilderOffsetInstruction)ins.get(10)).getTarget().getLocation().getIndex()==16 &&
            ref(ins.get(11),pager+"->A02("+pager+"IZ)Z") &&
            ref(ins.get(16),pager+"->A00("+pager+")Landroidx/fragment/app/Fragment;") &&
            incoming(ins,11).isEmpty(), "Reels page reset differs");
        Label handled=b.newLabelForIndex(26);
        b.addInstruction(11,new BuilderInstruction35c(Opcode.INVOKE_STATIC,1,4,0,0,0,0,
            new ImmutableMethodReference(pager,"A00",Collections.singletonList(pager),"Landroidx/fragment/app/Fragment;")));
        b.addInstruction(12,new BuilderInstruction11x(Opcode.MOVE_RESULT_OBJECT,0));
        b.addInstruction(13,call("backOnOtherPage","Z",0,OBJ));
        b.addInstruction(14,new BuilderInstruction11x(Opcode.MOVE_RESULT,0));
        b.addInstruction(15,new BuilderInstruction21t(Opcode.IF_NEZ,0,handled));
    }
    private static void observe(MutableMethod m,String hook,String type) {
        int self=m.getImplementation().getRegisterCount()-1-m.getParameterTypes().size();
        require(self>=0 && self<16,"Activity register differs");
        m.getImplementation().addInstruction(0,call(hook,"V",self,type));
    }
    private static void profile(MutableMethod m) {
        MutableMethodImplementation b=m.getImplementation();
        List<BuilderInstruction> ins=b.getInstructions();
        require(b.getRegisterCount()==11,"profile registers differ");
        int found=-1;
        for(int i=0;i<ins.size();i++) if(ins.get(i).getOpcode()==Opcode.RETURN) {
            require(found<0 && ((OneRegisterInstruction)ins.get(i)).getRegisterA()==2,"profile return differs");found=i;
        }
        require(found>=0,"missing profile return");
        b.replaceInstruction(found,new BuilderInstruction35c(Opcode.INVOKE_STATIC,2,10,2,0,0,0,
            new ImmutableMethodReference(RT,"profileResult",Arrays.asList(OBJ,"Z"),"Z")));
        b.addInstruction(found+1,new BuilderInstruction11x(Opcode.MOVE_RESULT,2));
        b.addInstruction(found+2,new BuilderInstruction11x(Opcode.RETURN,2));
        observe(m,"observeProfile",OBJ);
    }
    public static boolean applyIfSelected(BytecodePatchContext context) {
        if (!"com.instagram.android".equals(context.getPackageMetadata().getPackageName()) ||
            !"456.0.0.53.78".equals(context.getPackageMetadata().getVersionName())) return false;
        // Limit the newer runtime to this version; other OneBack targets retain the shipped extension.
        try (InputStream stream=Instagram456Patch.class.getResourceAsStream("/extensions/instagram456.mpe")) {
            require(stream!=null,"missing 456 runtime");
            DexBackedDexFile dex=DexBackedDexFile.fromInputStream(Opcodes.getDefault(),new BufferedInputStream(stream));
            for(ClassDef c:dex.getClasses()) {
                require(context.classDefByOrNull(c.getType())==null,"already patched; select the original Instagram file");
                context.getPatchClasses$morphe_patcher().addClass$morphe_patcher(c);
            }
        } catch(IOException error) { throw new IllegalStateException("Cannot load Instagram 456 runtime",error); }
        exitGate(method(context,REELS,"onBackPressed","Z"),54,9,REELS+"->A2K:LX/0U0t;",Arrays.asList(22,36,41));
        exitGate(method(context,HOME,"onBackPressed","Z"),7,10,HOME+"->A0R()LX/06jB;",Arrays.asList(1,5));
        otherPage(method(context,"LX/08NU;","onBackPressed","Z"));
        profile(method(context,PROFILE,"onBackPressed","Z"));
        observe(method(context,MAIN,"A28","V","LX/06y5;"),"observe",ACT);
        for(String name:Arrays.asList("UrlHandlerActivity","UrlHandlerLauncherActivity"))
            observe(method(context,"Lcom/instagram/url/"+name+";","onBackPressed","V"),"observe",ACT);
        return true;
    }
}
