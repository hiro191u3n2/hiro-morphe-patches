#!/usr/bin/env python3
"""Independent semantic audit of a diagnostic patch's input/output APKs."""
import argparse
import gc
import hashlib
import json
import re
import struct
import zipfile
import zlib
from pathlib import Path

from loguru import logger
logger.remove()
from androguard.core.dex import DEX, EncodedValue, EncodedArray, EncodedAnnotation

TARGET = 'Lhiro/berry/PreviewScheduler;->defer(Landroid/view/View; Ljava/lang/Runnable;)Z'
EXPECTED_INPUT = '08dcc9bb7c95152c01a142d8f94e80e10219ee8963577e28c2265318fea52f5f'

def sha(data):
    return hashlib.sha256(data).hexdigest()

def digest(value):
    return sha(json.dumps(value, ensure_ascii=True, sort_keys=True, separators=(',', ':')).encode())

def encoded(value):
    if value is None or isinstance(value, (str, bool, int, float)):
        return value
    if isinstance(value, (tuple, list)):
        return [encoded(x) for x in value]
    if isinstance(value, EncodedValue):
        return [value.get_value_type(), encoded(value.get_value())]
    if isinstance(value, EncodedArray):
        return [encoded(x) for x in value.get_values()]
    if isinstance(value, EncodedAnnotation):
        return [value.CM.get_type(value.get_type_idx()),
                sorted([[e.CM.get_string(e.get_name_idx()), encoded(e.get_value())]
                        for e in value.get_elements()])]
    raise TypeError(type(value).__name__)

def annotations(cls):
    cm = cls.CM
    directory = cls.annotations_directory_item
    if directory is None:
        return None
    def aset(offset):
        if not offset:
            return []
        aset_obj = cm.get_obj_by_offset(offset)
        values = []
        for off in aset_obj.get_annotation_off_item():
            item = off.get_annotation_item()
            values.append([item.get_visibility(), encoded(item.get_annotation())])
        return sorted(values, key=lambda x: json.dumps(x, sort_keys=True))
    fields = [[encoded(cm.get_field(x.get_field_idx())), aset(x.get_annotations_off())]
              for x in directory.get_field_annotations()]
    methods = [[encoded(cm.get_method(x.get_method_idx())), aset(x.get_annotations_off())]
               for x in directory.get_method_annotations()]
    parameters = []
    for x in directory.get_parameter_annotations():
        parameter_sets = cm.get_obj_by_offset(x.get_annotations_off()).get_list()
        parameters.append([encoded(cm.get_method(x.get_method_idx())),
                           [aset(p.get_annotations_off()) for p in parameter_sets]])
    return {'class': aset(directory.get_class_annotations_off()),
            'fields': sorted(fields, key=str), 'methods': sorted(methods, key=str),
            'parameters': sorted(parameters, key=str)}

def body(method):
    code = method.get_code()
    if code is None:
        return None
    handler_list = code.get_handlers()
    handlers = {}
    if handler_list:
        for handler in handler_list.get_list():
            handlers[handler.get_off() - handler_list.get_off()] = {
                'typed': [[method.CM.get_type(pair.get_type_idx()), pair.get_addr()]
                          for pair in handler.get_handlers()],
                'catch_all': handler.get_catch_all_addr() if handler.get_size() <= 0 else None}
    tries = [[item.get_start_addr(), item.get_insn_count(), handlers[item.get_handler_off()]]
             for item in code.get_tries()]
    instructions = [[instruction.get_name(), instruction.get_output()]
                    for instruction in method.get_instructions()]
    return {'registers': code.registers_size, 'incoming': code.ins_size,
            'outgoing': code.outs_size, 'tries': tries, 'instructions': instructions}

def snapshot(apk):
    result = {'class': {}, 'field': {}, 'method': {}, 'method_body': {}, 'method_raw': {},
              'target_body': None, 'dex': {}, 'entries': {}}
    with zipfile.ZipFile(apk) as archive:
        assert archive.testzip() is None
        assert len(set(archive.namelist())) == len(archive.namelist())
        for name in archive.namelist():
            data = archive.read(name)
            result['entries'][name] = sha(data)
            if not re.fullmatch(r'classes\d*\.dex', name):
                continue
            assert data[12:32] == hashlib.sha1(data[32:]).digest(), name
            assert struct.unpack_from('<I', data, 8)[0] == zlib.adler32(data[12:]) & 0xffffffff, name
            dex = DEX(data)
            result['dex'][name] = {'sha256': sha(data), 'size': len(data), 'header_integrity': True}
            for cls in dex.get_classes():
                cname = cls.get_name()
                assert cname not in result['class'], cname
                source_idx = cls.get_source_file_idx()
                result['class'][cname] = digest({
                    'flags': cls.get_access_flags(), 'superclass': cls.get_superclassname(),
                    'interfaces': cls.get_interfaces(),
                    'source': None if source_idx == 0xffffffff else cls.CM.get_string(source_idx),
                    'annotations': annotations(cls)})
                for field in cls.get_fields():
                    identity = cname + '->' + field.get_name() + ':' + field.get_descriptor()
                    assert identity not in result['field'], identity
                    result['field'][identity] = digest([field.get_access_flags(), encoded(field.get_init_value())])
                for method in cls.get_methods():
                    identity = cname + '->' + method.get_name() + method.get_descriptor()
                    assert identity not in result['method'], identity
                    result['method'][identity] = method.get_access_flags()
                    canonical = body(method)
                    result['method_body'][identity] = digest(canonical)
                    result['method_raw'][identity] = sha(b''.join(i.get_raw() for i in method.get_instructions()))
                    if identity == TARGET:
                        result['target_body'] = canonical
            del dex
            gc.collect()
    return result

def compare_dict(old, new):
    return {'added': sorted(new.keys() - old.keys()), 'removed': sorted(old.keys() - new.keys()),
            'changed': sorted(k for k in old.keys() & new.keys() if old[k] != new[k])}

def main():
    parser = argparse.ArgumentParser()
    parser.add_argument('input_apk', type=Path)
    parser.add_argument('output_apk', type=Path)
    parser.add_argument('report', type=Path)
    args = parser.parse_args()
    args.input_apk = args.input_apk.resolve()
    args.output_apk = args.output_apk.resolve()
    assert sha(args.input_apk.read_bytes()) == EXPECTED_INPUT
    print('Reading original APK', flush=True)
    old = snapshot(args.input_apk)
    print('Reading diagnostic APK', flush=True)
    new = snapshot(args.output_apk)
    differences = {k: compare_dict(old[k], new[k]) for k in ('class','field','method','method_body','method_raw','entries')}
    new_body = new['target_body']
    false_only = new_body is not None and new_body['instructions'] == [['const/4', 'v0, 0'], ['return', 'v0']] and new_body['tries'] == []
    semantic_pass = (all(not any(differences[k].values()) for k in ('class','field','method')) and
                     differences['method_body'] == {'added': [], 'removed': [], 'changed': [TARGET]} and false_only)
    signature_entry = re.compile(r'^META-INF/(?:[^/]+\.(?:RSA|DSA|EC|SF)|MANIFEST\.MF)$', re.I)
    resource_changes = {kind: [name for name in names if not re.fullmatch(r'classes\d*\.dex', name) and not signature_entry.match(name)]
                        for kind, names in differences['entries'].items()}
    report = {
        'schema': 'berry-addon-independent-audit-v1',
        'result': 'PASS' if semantic_pass and not any(resource_changes.values()) else 'REVIEW_REQUIRED',
        'input': {'path': str(args.input_apk), 'sha256': sha(args.input_apk.read_bytes())},
        'output': {'path': str(args.output_apk), 'sha256': sha(args.output_apk.read_bytes())},
        'scope': {'classes': len(old['class']), 'fields': len(old['field']), 'methods': len(old['method']), 'dex_count': len(old['dex'])},
        'differences': differences,
        'non_dex_non_signature_entry_changes': resource_changes,
        'target_original': old['target_body'], 'target_diagnostic': new_body,
        'dex_output': new['dex'],
        'checks': {'same_classes_fields_method_declarations_and_annotations': all(not any(differences[k].values()) for k in ('class','field','method')),
                   'only_target_method_instructions_or_registers_or_handlers_changed': differences['method_body'] == {'added': [], 'removed': [], 'changed': [TARGET]},
                   'all_other_method_instruction_bytes_identical': differences['method_raw'] == {'added': [], 'removed': [], 'changed': [TARGET]},
                   'target_is_exact_two_instruction_false_return': false_only,
                   'resources_and_non_signature_non_dex_contents_byte_identical': not any(resource_changes.values())},
        'limitations': ['Physical Android runtime not tested', 'Debug line number data excluded from semantic comparison', 'APK signing block and ZIP layout not compared; unsigned rebuild changes packaging']
    }
    args.report.write_text(json.dumps(report, ensure_ascii=False, indent=2) + '\n')
    print(json.dumps({k: report[k] for k in ('result','scope','checks','non_dex_non_signature_entry_changes')}, ensure_ascii=False), flush=True)

if __name__ == '__main__':
    main()
