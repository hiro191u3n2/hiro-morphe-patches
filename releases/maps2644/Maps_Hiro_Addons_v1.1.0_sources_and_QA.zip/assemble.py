#!/usr/bin/env python3
"""Assemble Maps 26.44 compatibility providers over immutable Hiro373.

All patch and runtime source is built by the per-feature builders first.
Only explicitly reviewed Maps provider packages and extension resources can change.
"""
import argparse, hashlib, json, os, subprocess, zipfile
from pathlib import Path
import zip_helpers as z

BASE_SHA='8a39f41e965d6a3ecd18957e6ada62c05f2f3d7aeef064ae87b2d3865c7db551'
PREFIXES=('app/hiro/maps/','app/hiro/mapsbikes/','app/hiro/mapsstartup/',
          'app/hiro/mapsstrict/','app/hiro/mapsback/','app/hiro/mapsstrict2644/','app/hiro/mapsback2644/')
TOOL_PINS={'classpath.jar':'fe4bc92815bb14976150e4ec83e4985932b46d1d47edec75d37604481572e864',
 'ecj.jar':'74c93172475fee0cd4e6eefb44233516dd40525642da35d009146d97ea598229',
 'd8.jar':'38a9ffaaebbd17d1514e3ecbff5a85b989bb13c551b9e224c7409514eea84ff5'}
MF='META-INF/MANIFEST.MF'

def main():
 p=argparse.ArgumentParser()
 for key in ('base','spec','tools','out'):p.add_argument('--'+key,type=Path,required=True)
 p.add_argument('--timestamp',required=True)
 a=p.parse_args()
 a.out.mkdir(parents=True,exist_ok=True)
 if any(a.out.iterdir()):raise RuntimeError('Use fresh output directory')
 work=a.out/'work';work.mkdir()
 if z.sha(a.base)!=BASE_SHA:raise RuntimeError('Hiro373 baseline differs')
 for name,h in TOOL_PINS.items():
  if z.sha(a.tools/name)!=h:raise RuntimeError('Tool changed: '+name)
 base=z.archive(a.base);headers=z.headers(base[MF]);assert headers['Version']=='1.0.373'
 overlays=json.loads(a.spec.read_text());fresh={};resources={};remove=set();inputs={}
 for spec in overlays:
  candidate=Path(spec['candidate']);data=z.archive(candidate);prefixes=tuple(spec['class_prefixes'])
  assert all(any(p.startswith(allowed) for allowed in PREFIXES) for p in prefixes)
  owned={n:b for n,b in data.items() if n.endswith('.class') and n.startswith(prefixes)}
  assert owned, spec['label']+' has no compiled providers'
  assert not set(owned)&set(fresh),'Feature provider overlap'
  fresh.update(owned)
  remove.update(n for n in base if n.endswith('.class') and n.startswith(prefixes))
  for n in spec['resources']:
   assert n.startswith(('extensions/maps','contracts/maps')),n
   assert n in data and n not in resources,n
   resources[n]=data[n]
  inputs[spec['label']]={'candidate_sha256':z.sha(candidate),'classes':len(owned),'resources':spec['resources']}
 assert len(overlays)==5,'Require all five Maps features'
 for old in [n for n in base if n.endswith('.class') and n.startswith(PREFIXES)]:
  assert old in remove,'Maps provider omitted: '+old
 z.write_zip(work/'fresh.jar',fresh)
 z.write_zip(work/'baseline-jvm.jar',{n:b for n,b in base.items() if n.endswith('.class')})
 (work/'dex').mkdir();(work/'build-tools').mkdir()
 def run(cmd,log):
  r=subprocess.run(list(map(str,cmd)),text=True,capture_output=True,timeout=600)
  (work/log).write_text(r.stdout+r.stderr)
  if r.returncode:raise RuntimeError(log+': '+(r.stdout+r.stderr)[-5000:])
 run(['java','-cp',a.tools/'d8.jar','com.android.tools.r8.D8','--release','--min-api','26',
      '--classpath',a.tools/'classpath.jar','--classpath',work/'baseline-jvm.jar','--output',work/'dex',work/'fresh.jar'],'d8.log')
 assert {x.name for x in (work/'dex').iterdir()}=={'classes.dex'}
 run(['java','-jar',a.tools/'ecj.jar','-source','11','-target','11','-cp',a.tools/'classpath.jar',
      '-d',work/'build-tools',Path(__file__).with_name('MergeMaps.java')],'compile-merger.log')
 (work/'baseline.dex').write_bytes(base['classes.dex'])
 (work/'remove.txt').write_text(''.join('L'+n[:-6]+';\n' for n in sorted(remove)))
 run(['java','-Xmx2g','-cp',os.pathsep.join(map(str,[work/'build-tools',a.tools/'classpath.jar'])),
      'MergeMaps',work/'baseline.dex',work/'dex/classes.dex',work/'combined.dex',work/'single.dex',work/'dex-audit.json',work/'remove.txt'],'merge.log')
 combined={n:b for n,b in base.items() if n not in remove}
 combined.update(fresh);combined.update(resources);combined['classes.dex']=(work/'combined.dex').read_bytes()
 headers.update(Version='1.0.374',Timestamp=a.timestamp,Description='Google Maps26.44 compatibility for all five Hiro Maps add-ons; retain verified26.36 support and unrelated apps.')
 combined[MF]=z.manifest(headers)
 combined_path=a.out/'Hiro_Morphe_Patches_v1.0.374.mpp'
 retained_records=z.write_combined_zip(combined_path,combined,a.base,base,work/'changed.zip')
 single={n:b for n,b in combined.items() if (n.endswith('.class') and n.startswith(PREFIXES)) or n.startswith(('extensions/maps','contracts/maps'))}
 single[MF]=z.manifest(dict(headers,Name='Hiro Google Maps Add-ons',Version='1.1.0'))
 single['classes.dex']=(work/'single.dex').read_bytes()
 single_path=a.out/'Maps_Hiro_Addons_v1.1.0.mpp';z.write_zip(single_path,single)
 unchanged=[n for n in base if n not in remove and n not in resources and n not in (MF,'classes.dex')]
 assert all(combined[n]==base[n] for n in unchanged),'Unrelated archive entry changed'
 assert not any(n.startswith(('app/morphe/patcher/','android/')) for n in fresh),'Compile stubs leaked'
 report={'schema':'maps2644-build-v1','bundle_version':'1.0.374','maps_set_version':'1.1.0','base_sha256':BASE_SHA,
   'parts':inputs,'tool_sha256':TOOL_PINS,'dex_audit':json.loads((work/'dex-audit.json').read_text()),
   'unchanged_archive_entries':len(unchanged),'unchanged_compressed_records':retained_records,
   'compile_stubs_excluded':True,'artifacts':{p.name:{'size':p.stat().st_size,'sha256':z.sha(p)} for p in [combined_path,single_path]}}
 (a.out/'build-report.json').write_text(json.dumps(report,indent=2)+'\n')
 print(json.dumps(report,indent=2))
if __name__=='__main__':main()
