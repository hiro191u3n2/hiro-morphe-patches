# Hiro Google Maps Add-ons 1.1.0 / Hiro Morphe Patches 1.0.374

このソースは Google マップ `26.44.06.1006895251`（versionCode `1068856906`）の次の五つのパッチを追加対応し、既存の `26.36.04.973607363`（`1068763346`）対応を保持します。パッチ画面には各機能が一つずつ表示されます。

- 検索欄の下のカテゴリ行を非表示
- 地図上の自転車マークを非表示
- 起動時に現在地を表示
- 店名検索を厳密にする
- 戻るで終了して履歴から削除

バージョン名だけを許可する変更ではありません。各版で対象の実コード、呼び出し先、命令構造、必要なフィールドを検証します。26.44 用の自転車・店名検索ランタイムを追加し、26.36 用ランタイムと起動時現在地ランタイムは基準 MPP のバイト列を保持します。

## 再ビルド

Python 3、Java **21.0.13** と `tool-hashes.json` に記録した四つの JAR を用意してください。JAR 名は `morphe-dev19.jar`（Morphe Desktop 2.2.0-dev.19 / Patcher 2.4.0-dev.8）、`classpath.jar`（Morphe Desktop 1.19.0-dev.19）、`ecj.jar`（Eclipse compiler 3.46.100.v20260826-1225）、`d8.jar`（D8 9.5.28）です。ビルダーは全 JAR と基準 MPP の SHA-256 を検証し、異なる入力を拒否します。

基準は [Hiro_Morphe_Patches_v1.0.373.mpp](https://hiro-morphe-patches.otoha10.chatgpt.site/Hiro_Morphe_Patches_v1.0.373.mpp) です。入力の名前・SHA-256 は `baseline.json` にも保存しています。APK、JAR、MPP、生成済み class / DEX はこのアーカイブに含めません。

展開したフォルダで次を実行します。`/path/to/tools` には上記四つの JAR を置き、`out` は空の新しいフォルダを指定してください。

```sh
python3 build_modules.py \
  --base /path/to/Hiro_Morphe_Patches_v1.0.373.mpp \
  --tools /path/to/tools \
  --out out \
  --timestamp 2026-11-15T16:09:11
```

公開ファイルは `out/release/Hiro_Morphe_Patches_v1.0.374.mpp` と `out/release/Maps_Hiro_Addons_v1.1.0.mpp` に生成されます。上記時刻・指定入力で、公開 MPP と**バイト単位で一致する再ビルドを確認済み**です。期待 SHA-256 は `verification/published-build.json`、再ビルド結果は `verification/reproduced-build.json` と `verification/reproducibility.json` にあります。中間の機能別 MPP はビルド用の簡略メタデータを使うため、試験時候補 MPP 自体の ZIP ハッシュとは異なりますが、そこに含まれる provider class と拡張リソースは一致します。

`compile_api.py` は既存の Kotlin synthetic コンストラクターを Java コンパイラーに公開する**コンパイル専用**のコピーを生成します。この API コピー、Android / native テスト代替クラスは MPP に梱包しません。`assemble.py` と `MergeMaps.java` は五つの Maps provider のみを置換し、他アプリの 370 クラス、無関係な ZIP エントリー、既存ランタイムを監査します。基準 ZIP の変更不要な圧縮レコードもそのまま保持します。

## 回帰テスト

同じフォルダで、上記ビルドに続けてホスト上のテストを実行できます。

```sh
python3 test_modules.py \
  --tools /path/to/tools \
  --build out \
  --out test-results
```

実 APK の指紋・参照・型の検証も行う場合は、手元にある対象のオリジナル APK を指定します。

```sh
python3 test_modules.py \
  --tools /path/to/tools \
  --build out \
  --out test-results-with-apks \
  --apk2636 /path/to/maps-26.36.apk \
  --apk2644 /path/to/maps-26.44.apk
```

対象 APK の SHA-256 は `verification/published-apk-checks.json` と個別検証記録にあります。全パッチ併用の適用・再構築試験、各機能の変更範囲監査、重複適用や未知コードの拒否、ランタイムのモデルテストを記録しています。`modules/*/src/test*` には APK 変更範囲監査のプログラムも収録しています。

## 検証の範囲

`verification/published-apk-checks.json` が最終公開 MPP に対する併用試験結果です。`verification/*` の個別記録には診断時のファイルパスが残りますが、再ビルドはそれらのパスを使いません。

Android 実機・エミュレーターでの画面操作は未実施です。APK のパッチ適用と再構築の成功、コードの変更範囲、ホスト上の動作検証を、実機での表示確認と区別しています。アップロードされた APK や署名済み改変 APK は公開しません。
