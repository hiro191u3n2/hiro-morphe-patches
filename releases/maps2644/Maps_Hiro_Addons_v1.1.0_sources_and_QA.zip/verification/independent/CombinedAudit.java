import java.io.*;
import java.util.*;
import java.util.zip.*;
import java.security.MessageDigest;
import java.nio.ByteBuffer;
import app.morphe.patcher.util.proxy.mutableTypes.*;
import com.android.tools.smali.dexlib2.*;
import com.android.tools.smali.dexlib2.iface.*;
import com.android.tools.smali.dexlib2.iface.instruction.*;
import com.android.tools.smali.dexlib2.iface.reference.*;
import com.android.tools.smali.dexlib2.immutable.*;
import com.android.tools.smali.dexlib2.dexbacked.DexBackedDexFile;
import com.android.tools.smali.dexlib2.writer.io.MemoryDataStore;
import com.android.tools.smali.dexlib2.writer.pool.DexPool;

/** Independent output scope audit. Does not emulate Android UI or the native renderer. */
public final class CombinedAudit {
 static int checks=0;
 static void check(boolean ok,String msg){checks++;if(!ok)throw new AssertionError(msg);}
 static final Set<String> OWNERS=new TreeSet<>(Arrays.asList("Lafyb;","Lnby;","Lpa;","Lavuw;","Lavuz;","Lbkpn;","Lbksm;","Lblij;","Lcom/google/android/libraries/geo/mapcore/geoxp/jni/NativeMapFactory;","Lcom/google/android/libraries/geo/mapcore/geoxp/jni/providers/MapCoreConfigProvider;"));
 static Map<String,ClassDef> read(String p)throws Exception{
  Map<String,ClassDef> out=new TreeMap<>();
  MultiDexContainer<? extends DexFile>d=DexFileFactory.loadDexContainer(new File(p),Opcodes.getDefault());
  for(String n:d.getDexEntryNames())for(ClassDef c:d.getEntry(n).getDexFile().getClasses())check(out.put(c.getType(),c)==null,"Duplicate class "+c.getType());
  return out;
 }
 static ClassDef normalize(ClassDef c){
  List<Method> m=new ArrayList<>();
  for(Method f:c.getMethods()){
   MethodImplementation b=f.getImplementation();
   if(b!=null)b=new ImmutableMethodImplementation(b.getRegisterCount(),b.getInstructions(),b.getTryBlocks(),Collections.emptyList());
   m.add(new ImmutableMethod(f.getDefiningClass(),f.getName(),f.getParameters(),f.getReturnType(),f.getAccessFlags(),f.getAnnotations(),f.getHiddenApiRestrictions(),b));
  }
  return new ImmutableClassDef(c.getType(),c.getAccessFlags(),c.getSuperclass(),c.getInterfaces(),c.getSourceFile(),c.getAnnotations(),c.getFields(),m);
 }
 static byte[] canonical(ClassDef c)throws Exception{
  MemoryDataStore s=new MemoryDataStore();try{DexPool.writeTo(s,new ImmutableDexFile(Opcodes.forApi(29),Collections.singleton(normalize(c))));return Arrays.copyOf(s.getBuffer(),s.getSize());}finally{s.close();}
 }
 static String descriptor(MethodReference m){StringBuilder s=new StringBuilder(m.getDefiningClass()).append("->").append(m.getName()).append('(');for(CharSequence p:m.getParameterTypes())s.append(p);return s.append(')').append(m.getReturnType()).toString();}
 static Map<String,Method> methods(ClassDef c){Map<String,Method> m=new TreeMap<>();for(Method f:c.getMethods())check(m.put(descriptor(f),f)==null,"Duplicate method "+f);return m;}
 static byte[] methodBytes(Method m)throws Exception{return canonical(new ImmutableClassDef(m.getDefiningClass(),1,"Ljava/lang/Object;",Collections.emptyList(),null,Collections.emptySet(),Collections.emptyList(),Collections.singleton(m)));}
 static Set<String> fields(ClassDef c){Set<String>s=new TreeSet<>();for(Field f:c.getFields())s.add(f.toString()+"#"+f.getAccessFlags()+"#"+f.getInitialValue());return s;}
 static List<Instruction> instructions(Method m){List<Instruction> out=new ArrayList<>();if(m.getImplementation()!=null)for(Instruction i:m.getImplementation().getInstructions())out.add(i);return out;}
 static boolean owned(String d){return d.startsWith("Lapp/hiro/maps");}
 static List<String> hiroCalls(ClassDef c){List<String> out=new ArrayList<>();for(Method m:c.getMethods())for(Instruction i:instructions(m))if(i instanceof ReferenceInstruction){Reference r=((ReferenceInstruction)i).getReference();if(r instanceof MethodReference&&owned(((MethodReference)r).getDefiningClass()))out.add(descriptor(m)+" -> "+descriptor((MethodReference)r));}return out;}
 static boolean allowedMethod(String owner,Method m){
  String n=m.getName();
  if(owner.equals("Lnby;"))return Arrays.asList("onCreate","onNewIntent","onResume","onPause","onStop","onStart","onDestroy","dispatchTouchEvent").contains(n);
  if(owner.equals("Lafyb;")||owner.equals("Lpa;")||owner.endsWith("/MapCoreConfigProvider;"))return n.equals("a");
  if(owner.equals("Lavuw;"))return n.equals("f");
  if(owner.equals("Lavuz;"))return n.equals("O");
  if(owner.endsWith("/NativeMapFactory;"))return n.equals("u");
  return n.equals("b");
 }
 static void verifyHooks(Map<String,ClassDef> after,List<String> actual){
  Set<String> expected=new TreeSet<>();
  String[] life={"onCreate","onNewIntent","onResume","onPause","onStop","onStart","onDestroy","dispatchTouchEvent"};
  String[] args={"Landroid/os/Bundle;","Landroid/content/Intent;","","","","","","Landroid/view/MotionEvent;"};
  for(int i=0;i<life.length;i++)expected.add("Lnby;->"+life[i]+"("+args[i]+")"+(i==7?"Z":"V")+" -> Lapp/hiro/mapsstartup/StartupLocation;->"+(i==7?"onTouch":life[i])+"(Landroid/app/Activity;"+args[i]+")V");
  expected.add("Lpa;->a()Ljava/lang/Object; -> Lapp/hiro/mapsback/NativeBackFallback;->install(Ljava/lang/Object;Laozl;)V");
  expected.add("Lavuw;->f(Lcqmj;Landroid/app/Application;Lawub;)V -> Lapp/hiro/mapsstrict2644/SearchFilter;->filterResponse(Ljava/lang/Object;Ljava/lang/String;Ljava/lang/Object;)Ljava/lang/Object;");
  expected.add("Lavuz;->O(Lavuz;Landroid/app/Application;ZZ)V -> Lapp/hiro/mapsstrict2644/SearchFilter;->reconcileModel(Ljava/lang/Object;Ljava/lang/Object;)V");
  expected.add("Lbkpn;->b(Lcige;Lbkse;ILjava/util/List;Ljava/util/List;Lbkqu;Lbjwq;)Lbkoq; -> Lapp/hiro/mapsbikes/BicycleMarkerFilter;->shouldHide(Ljava/lang/Object;)Z");
  expected.add("Lbksm;->b(Lbksd;Lcom/google/common/collect/ImmutableList;Lchvt;Lbkxb;Lbkse;Lblex;Z)Lbksm; -> Lapp/hiro/mapsbikes/BicycleMarkerFilter;->shouldHideLegacy(Ljava/lang/Object;Ljava/lang/Object;)Z");
  expected.add("Lblij;->b(Ljava/lang/Object;)V -> Lapp/hiro/mapsbikes/BicycleLegendFilter;->filter([B)[B");
  expected.add("Lcom/google/android/libraries/geo/mapcore/geoxp/jni/NativeMapFactory;->u(J[B)V -> Lapp/hiro/mapsbikes/BicycleLegendFilter;->filter([B)[B");
  check(actual.size()==expected.size()&&new TreeSet<>(actual).equals(expected),"Native hooks mismatch: "+actual);
  Method category=methods(after.get("Lafyb;")).get("Lafyb;->a()Landroid/view/View;");
  List<Instruction> row=instructions(category);Instruction zero=row.get(row.size()-2);
  check(zero.getOpcode()==Opcode.CONST_4&&((OneRegisterInstruction)zero).getRegisterA()==1&&((NarrowLiteralInstruction)zero).getNarrowLiteral()==0,"Category final result not cleared");
  int migrated=0,old=0,secure=0;
  for(Method m:after.get("Lcom/google/android/libraries/geo/mapcore/geoxp/jni/providers/MapCoreConfigProvider;").getMethods())for(Instruction i:instructions(m))if(i instanceof ReferenceInstruction){Reference r=((ReferenceInstruction)i).getReference();if(r instanceof StringReference){String t=((StringReference)r).getString();if(t.equals("geoxp_cache_hiro_bikes101"))migrated++;if(t.equals("geoxp_cache"))old++;if(t.equals("geoxp_secure"))secure++;}}
  check(migrated==2&&old==0&&secure==1,"Cache paths changed incorrectly "+migrated+"/"+old+"/"+secure);
  Set<String> stale=new HashSet<>(Arrays.asList("Lnce;","Lamcr;","Lamdp;","Lamdy;","Lamgk;","Lbkmd;","Lbjaw;","Lqi;","Lamet;"));
  List<Method> injected=new ArrayList<>();injected.add(methods(after.get("Lnby;")).get("Lnby;->hiroTryCurrentLocation(Z)I"));for(Method m:after.get("Lapp/hiro/mapsback/NativeBackFallback;").getMethods())injected.add(m);
  for(Method m:injected)for(Instruction i:instructions(m))if(i instanceof ReferenceInstruction){Reference r=((ReferenceInstruction)i).getReference();String owner=r instanceof MethodReference?((MethodReference)r).getDefiningClass():r instanceof FieldReference?((FieldReference)r).getDefiningClass():r instanceof TypeReference?((TypeReference)r).getType():"";check(!stale.contains(owner),"Stale native reference in injected code "+r);}
 }
 static boolean skip(String n){return n.matches("classes(?:[0-9]+)?\\.dex")||n.matches("(?i)META-INF/(?:MANIFEST\\.MF|[^/]+\\.(?:SF|RSA|DSA|EC))");}
 static Map<String,String> zip(String p)throws Exception{
  Map<String,String> out=new TreeMap<>();Set<String> seen=new HashSet<>();try(ZipFile z=new ZipFile(p)){Enumeration<? extends ZipEntry> e=z.entries();while(e.hasMoreElements()){ZipEntry n=e.nextElement();check(seen.add(n.getName()),"Duplicate ZIP entry "+n.getName());if(n.isDirectory()||skip(n.getName()))continue;MessageDigest h=MessageDigest.getInstance("SHA-256");try(InputStream i=z.getInputStream(n)){byte[] b=new byte[65536];int k;while((k=i.read(b))!=-1)h.update(b,0,k);}out.put(n.getName(),HexFormat.of().formatHex(h.digest()));}}return out;
 }
 static Set<String> unchangedDexClasses(String a,String b)throws Exception{
  Set<String> out=new HashSet<>();try(ZipFile x=new ZipFile(a);ZipFile y=new ZipFile(b)){
   Enumeration<? extends ZipEntry> e=x.entries();while(e.hasMoreElements()){ZipEntry n=e.nextElement();if(!n.getName().matches("classes(?:[0-9]+)?\\.dex"))continue;ZipEntry m=y.getEntry(n.getName());if(m==null||n.getSize()!=m.getSize()||n.getCrc()!=m.getCrc())continue;byte[] aa=x.getInputStream(n).readAllBytes(),bb=y.getInputStream(m).readAllBytes();if(Arrays.equals(aa,bb))for(ClassDef c:new DexBackedDexFile(Opcodes.getDefault(),ByteBuffer.wrap(aa)).getClasses())out.add(c.getType());}
  }return out;
 }
 static Map<String,ClassDef> runtime(String mpp)throws Exception{
  Map<String,ClassDef> out=new TreeMap<>();try(ZipFile z=new ZipFile(mpp)){
   for(String name:Arrays.asList("extensions/maps_startup_location.mpe","extensions/maps_hide_bicycle_marks_2644.mpe","extensions/maps_strict_search2644.mpe")){
    ZipEntry e=z.getEntry(name);check(e!=null,"Runtime missing "+name);
    for(ClassDef c:new DexBackedDexFile(Opcodes.getDefault(),ByteBuffer.wrap(z.getInputStream(e).readAllBytes())).getClasses())check(out.put(c.getType(),c)==null,"Runtime collision "+c.getType());
   }
  }return out;
 }
 public static void main(String[] a)throws Exception{
  check(a.length==4,"usage baseline output mpp mode(exact|inventory|parity)");String mode=a[3];
  Map<String,ClassDef> before=read(a[0]),after=read(a[1]);Set<String> intact=unchangedDexClasses(a[0],a[1]);
  check(after.keySet().containsAll(before.keySet()),"Original classes removed");
  Set<String> added=new TreeSet<>(after.keySet());added.removeAll(before.keySet());
  Map<String,ClassDef> runtime=runtime(a[2]);Set<String> expected=new TreeSet<>(runtime.keySet());expected.add("Lapp/hiro/mapsback/NativeBackFallback;");
  if(!mode.equals("parity"))check(added.equals(expected),"Unexpected runtime inventory "+added+" expected "+expected);
  else check(added.isEmpty(),"Parity extra classes");
  for(Map.Entry<String,ClassDef> e:runtime.entrySet())check(Arrays.equals(canonical(e.getValue()),canonical(after.get(e.getKey()))),"Runtime body mismatch "+e.getKey());
  for(String n:after.keySet())check(!n.startsWith("Lapp/hiro/mapsstrict/"),"Legacy strict runtime leaked into 26.44");
  ClassDef callback=after.get("Lapp/hiro/mapsback/NativeBackFallback;");check(callback!=null&&callback.getSuperclass().equals("Lpq;"),"Wrong callback superclass");
  Set<String> changed=new TreeSet<>();List<String> changedMethods=new ArrayList<>(),nativeCalls=new ArrayList<>();int originalMethods=0,originalFields=0;
  for(ClassDef c:before.values()){
   ClassDef out=after.get(c.getType());Map<String,Method> orig=methods(c),post=methods(out);originalMethods+=orig.size();originalFields+=fields(c).size();
   check(post.keySet().containsAll(orig.keySet()),"Original methods removed "+c.getType());
   for(Method m:orig.values()){Method n=post.get(descriptor(m));check(m.getImplementation()==null||n.getImplementation()!=null,"Native body removed "+m);}
   if(!fields(out).containsAll(fields(c)))throw new AssertionError("Original fields changed "+c.getType());
   if(!intact.contains(c.getType())&&!Arrays.equals(canonical(c),canonical(out))){
    changed.add(c.getType());
    if(mode.equals("exact"))check(OWNERS.contains(c.getType()),"Unexpected native change "+c.getType());
    if(mode.equals("parity"))throw new AssertionError("Combined/standalone class mismatch "+c.getType());
    for(Method m:orig.values())if(!Arrays.equals(methodBytes(m),methodBytes(post.get(descriptor(m))))){changedMethods.add(descriptor(m));if(mode.equals("exact"))check(allowedMethod(c.getType(),m),"Unexpected method change "+m);}
   }
   if(!owned(c.getType()))nativeCalls.addAll(hiroCalls(out));
  }
  if(mode.equals("exact"))check(changed.equals(OWNERS),"Not all ten feature owners changed "+changed);
  verifyHooks(after,nativeCalls);
  check(after.get("Lnby;").getInterfaces().contains("Lapp/hiro/mapsstartup/LocationHost;"),"Missing startup interface");
  check(methods(after.get("Lnby;")).containsKey("Lnby;->hiroTryCurrentLocation(Z)I"),"Missing startup bridge");
  Map<String,String> r0=zip(a[0]),r1=zip(a[1]);
  if(mode.equals("exact")||mode.equals("parity"))check(r0.equals(r1),"Resources differ from baseline");
  for(String n:Arrays.asList("AndroidManifest.xml","resources.arsc"))check(r1.containsKey(n),"Missing APK resource "+n);
  System.out.println("PASS mode="+mode+" original_classes="+before.size()+" output_classes="+after.size()+" native_classes_changed="+changed.size()+" original_methods_preserved="+originalMethods+" original_fields_preserved="+originalFields+" added_runtime_classes="+added.size()+" native_hooks="+nativeCalls.size()+" resources="+r1.size()+" checks="+checks);
  System.out.println("CHANGED_CLASSES="+changed);System.out.println("CHANGED_METHODS="+changedMethods);System.out.println("NATIVE_HOOKS="+nativeCalls);System.out.println("RUNTIME_CLASSES="+expected);
 }
}
