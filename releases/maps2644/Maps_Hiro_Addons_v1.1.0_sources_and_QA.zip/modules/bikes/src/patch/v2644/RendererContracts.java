package app.hiro.mapsbikes.patches.v2644;

import java.util.List;
import com.android.tools.smali.dexlib2.Opcode;
import com.android.tools.smali.dexlib2.iface.Method;
import com.android.tools.smali.dexlib2.iface.instruction.*;
import com.android.tools.smali.dexlib2.iface.reference.*;

/** Frozen new-version renderer contracts; both cache-directory branches are isolated. */
public final class RendererContracts {
    private RendererContracts() {}
    public static final String LEGACY =
        "Lbksm;->b(Lbksd;Lcom/google/common/collect/ImmutableList;Lchvt;Lbkxb;Lbkse;Lblex;Z)Lbksm;";
    public static final String NETWORK = "Lblij;->b(Ljava/lang/Object;)V";
    public static final String FACTORY = "Lcom/google/android/libraries/geo/mapcore/geoxp/jni/NativeMapFactory;";
    public static final String OFFLINE = FACTORY + "->u(J[B)V";
    public static final String NETWORK_CALLBACK = FACTORY + "->nativeLoadUrlSuccess(JJ[B)V";
    public static final String OFFLINE_CALLBACK = FACTORY + "->nativeOnOfflineCacheFetchSuccess(JJ[B)V";
    public static final String CACHE_CONFIG =
        "Lcom/google/android/libraries/geo/mapcore/geoxp/jni/providers/MapCoreConfigProvider;->a()Lcdoi;";
    public static final int[] CACHE_INDICES = {458, 473};
    // Keep this namespace stable in future fixes unless a new cache migration
    // is required. The old geoxp_cache is retained; geoxp_secure is untouched.
    public static final String CACHE_DIRECTORY = "geoxp_cache_hiro_bikes101";
    public static final String LEGACY_POINT_CALLER =
        "Lbkom;->p(Lchvu;Lbkqz;ILcom/google/common/collect/ImmutableList;Landroid/content/res/Resources;Lbksd;Lbktm;Lbkso;Lblex;Lbkse;ZZ)Lbkom;";
    public static final String LEGACY_FEATURE_CALLER = "Lbkqr;->k(Lbkqp;Lbkqz;)Lbkqq;";

    private static void require(boolean value, String why) { MapsHideBicycleMarksPatch.require(value, why); }
    private static Method method(MapsHideBicycleMarksPatch.Lookup lookup, String descriptor) {
        return NativeContracts.method(lookup, descriptor);
    }
    private static void shape(MapsHideBicycleMarksPatch.Lookup lookup, String descriptor,
            int flags, int registers, int count, int units, int tries, String current, String sdk22) {
        NativeContracts.shape(method(lookup, descriptor), flags, registers, count, units, tries,
            NativeContracts.hashes(current, sdk22));
    }

    public static void validate(MapsHideBicycleMarksPatch.Lookup lookup) {
        shape(lookup, LEGACY, 9, 18, 65, 100, 0,
            "c86999237a7e670de0aa836a0335f0d7207c7601251fc583648a69266949a60e",
            "c86999237a7e670de0aa836a0335f0d7207c7601251fc583648a69266949a60e");
        shape(lookup, NETWORK, 4177, 6, 17, 34, 0,
            "63fda77f5780618924762e837ed98b5a4b5058fb6966b6aa0df25c5606be3c72",
            "63fda77f5780618924762e837ed98b5a4b5058fb6966b6aa0df25c5606be3c72");
        shape(lookup, OFFLINE, 17, 6, 8, 16, 0,
            "b7aa8001223630d8f00088263414767e972a79078a2d9a2a7dbf225e79c54660",
            "b7aa8001223630d8f00088263414767e972a79078a2d9a2a7dbf225e79c54660");
        shape(lookup, CACHE_CONFIG, 17, 35, 1303, 2639, 4,
            "d4400696392b9fa26a36fbb62abfa7c6285a42b1374faacc52032efa93198744",
            "d4400696392b9fa26a36fbb62abfa7c6285a42b1374faacc52032efa93198744");
        shape(lookup, LEGACY_POINT_CALLER, 9, 39, 276, 509, 0,
            "c33942af2d34f5d19ceb6ab62bd5dae015e68c6ef5e2edf20b1d3c4b349a5663",
            "c33942af2d34f5d19ceb6ab62bd5dae015e68c6ef5e2edf20b1d3c4b349a5663");
        shape(lookup, LEGACY_FEATURE_CALLER, 18, 35, 1082, 2092, 4,
            "5147856525b997c231f46ea3090bfdb1e533ce0511469059cd4e2f2090e35d0b",
            "5147856525b997c231f46ea3090bfdb1e533ce0511469059cd4e2f2090e35d0b");
        shape(lookup, "Lbksd;->j(Lcom/google/common/collect/ImmutableList;Lbkww;)Lbkww;", 25, 13, 130, 255, 0,
            "ff3d1f0df44e3a17bd8bfe871c4a98264f814d1b871e3bdfe096726405526b84",
            "ff3d1f0df44e3a17bd8bfe871c4a98264f814d1b871e3bdfe096726405526b84");
        shape(lookup, "Lchzd;->c(III)V", 20, 4, 91, 242, 0,
            "ba39a075bbd415166cb27651300a1976ebb55d31f195eb0cf47699753e0b8d73",
            "ba39a075bbd415166cb27651300a1976ebb55d31f195eb0cf47699753e0b8d73");
        shape(lookup, "Lchwc;->dynamicMethod(Lcnbt;Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;", 20, 6, 121, 242, 0,
            "354c38d5405d38bc69354a0399015db8f61933f96f19d7d7bab80c0b6e4ae4af",
            "354c38d5405d38bc69354a0399015db8f61933f96f19d7d7bab80c0b6e4ae4af");
        shape(lookup, "Lchvf;->dynamicMethod(Lcnbt;Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;", 20, 6, 80, 160, 0,
            "09f4d3a10e3eb659b9d892f0a9a6b33de86b07719a93992b6e3548d1367da028",
            "09f4d3a10e3eb659b9d892f0a9a6b33de86b07719a93992b6e3548d1367da028");
        shape(lookup, "Lchyo;->dynamicMethod(Lcnbt;Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;", 20, 10, 112, 218, 0,
            "8d350171d589c29f6650fe93215c18884bab7c2469984a46e2f9ce66280562df",
            "8d350171d589c29f6650fe93215c18884bab7c2469984a46e2f9ce66280562df");
        shape(lookup, "Lbkxf;->p(J)Lbkyf;", 131090, 31, 869, 1652, 13,
            "8249c81059212ff655a2c00042dc5b6c2c218fe7b6eedfb6f5d718f2b8e93b37",
            "8249c81059212ff655a2c00042dc5b6c2c218fe7b6eedfb6f5d718f2b8e93b37");
        shape(lookup, "Lbkyh;->i(Lchvk;Lbkyg;)V", 10, 13, 413, 797, 0,
            "ca465673b6fc10ffae91301b2135fb1464d19d6c3d581d00958645e513f5dc31",
            "ca465673b6fc10ffae91301b2135fb1464d19d6c3d581d00958645e513f5dc31");

        NativeContracts.schema(lookup, "Lbkxb;", "692d2f7c58b482c6103fd6252d56d516a95754e424a9fb4ad64e6da514d06744");
        NativeContracts.schema(lookup, "Lbkww;", "8895c9f277393913527887cb88fd46d25f9b77c7ce200215568dcb7cd2ebd53e");
        NativeContracts.schema(lookup, "Lbkwu;", "1a417f350204dde724b2e2ada59feba9ca31ca1b7c10ca91798ee2289b109d5d");
        NativeContracts.schema(lookup, "Lbksd;", "9894ddfe3af46995bdedb4d76c75e4a55c4a36fc4f4c6f1b805944b69228f348");
        NativeContracts.schema(lookup, "Lchuj;", "6e4fa67f2b7e576bc72f4d22794d306d711bf53a7ff08953375bd15e7a6d8c2d");
        NativeContracts.schema(lookup, "Lchzd;", "9b8c71e80c51d2ccefd3edfd204c36e4853e41d600c486830dadec5adb980da1");
        NativeContracts.schema(lookup, "Lchwc;", "cad8086e6cf5e3c26b5306610b6abd402d3a56393e165f72951b16ab85fae23b");
        NativeContracts.schema(lookup, "Lchvf;", "4a9ef87652801995c2480ef36b713574fae8107071597ecb87ef865d7d24b2b1");
        NativeContracts.schema(lookup, "Lchyo;", "55aca9088b327da528112ade0b3ae9bac7298f245aba83bf578e3f3fa8c69d1e");

        nullSafeLegacyCaller(method(lookup, LEGACY_POINT_CALLER));
        nullSafeLegacyCaller(method(lookup, LEGACY_FEATURE_CALLER));
        callback(method(lookup, NETWORK), NETWORK_CALLBACK, 15, new int[] {0, 1, 2, 3, 5});
        callback(method(lookup, OFFLINE), OFFLINE_CALLBACK, 6, new int[] {0, 1, 3, 4, 5});
        List<Instruction> config = NativeContracts.instructions(method(lookup, CACHE_CONFIG));
        int units = 0, cacheNames = 0, secureNames = 0;
        for (int i = 0; i < config.size(); i++) {
            Instruction code = config.get(i);
            if (code instanceof ReferenceInstruction
                    && ((ReferenceInstruction)code).getReference() instanceof StringReference) {
                String text = ((StringReference)((ReferenceInstruction)code).getReference()).getString();
                if (text.equals("geoxp_cache")) {
                    cacheNames++;
                    require((i == CACHE_INDICES[0] || i == CACHE_INDICES[1]) && code.getOpcode() == Opcode.CONST_STRING
                        && ((OneRegisterInstruction)code).getRegisterA() == 8, "Online cache directory load changed");
                }
                if (text.equals("geoxp_secure")) secureNames++;
            }
            units += code.getCodeUnits();
        }
        require(cacheNames == 2 && secureNames == 1, "Online/secure cache separation changed");
    }

    private static void nullSafeLegacyCaller(Method method) {
        List<Instruction> code = NativeContracts.instructions(method);
        int calls = 0;
        for (int i = 0; i < code.size(); i++) {
            Instruction value = code.get(i);
            if (!(value instanceof ReferenceInstruction)) continue;
            Reference reference = ((ReferenceInstruction)value).getReference();
            if (!(reference instanceof MethodReference) || !LEGACY.equals(MapsHideBicycleMarksPatch.descriptor((MethodReference)reference))) continue;
            calls++;
            require(value.getOpcode() == Opcode.INVOKE_STATIC_RANGE && i + 2 < code.size(), "Legacy caller ABI changed");
            Instruction result = code.get(i + 1), branch = code.get(i + 2);
            require(result.getOpcode() == Opcode.MOVE_RESULT_OBJECT
                    && (branch.getOpcode() == Opcode.IF_EQZ || branch.getOpcode() == Opcode.IF_NEZ)
                    && ((OneRegisterInstruction)result).getRegisterA() == ((OneRegisterInstruction)branch).getRegisterA(),
                "Legacy icon caller no longer handles null");
        }
        require(calls == 1, "Legacy icon call count changed");
    }

    private static void callback(Method method, String descriptor, int at, int[] registers) {
        List<Instruction> body = NativeContracts.instructions(method);
        Instruction call = body.get(at);
        require(call.getOpcode() == Opcode.INVOKE_STATIC && call instanceof FiveRegisterInstruction
                && call instanceof ReferenceInstruction
                && ((ReferenceInstruction)call).getReference() instanceof MethodReference
                && descriptor.equals(MapsHideBicycleMarksPatch.descriptor((MethodReference)((ReferenceInstruction)call).getReference())),
            "Native resource completion changed: " + descriptor);
        FiveRegisterInstruction args = (FiveRegisterInstruction)call;
        require(args.getRegisterCount() == 5 && args.getRegisterC() == registers[0]
                && args.getRegisterD() == registers[1] && args.getRegisterE() == registers[2]
                && args.getRegisterF() == registers[3] && args.getRegisterG() == registers[4]
                && at + 1 == body.size() - 1 && body.get(at + 1).getOpcode() == Opcode.RETURN_VOID,
            "Native resource completion registers or return changed: " + descriptor);
    }
}
