package app.hiro.mapsstrict2644.patches;

import java.util.*;
import com.android.tools.smali.dexlib2.iface.ClassDef;
import com.android.tools.smali.dexlib2.iface.Field;
import com.android.tools.smali.dexlib2.iface.Method;
import com.android.tools.smali.dexlib2.iface.instruction.Instruction;

/** Frozen 26.44.06.1006895251 (1068856906) contracts captured from the uploaded
 * original APK with Morphe Patcher 2.4.0-dev.8, after inspecting response ownership,
 * accepted-merge register lifetimes, and native-pin dispatch/consumer flow.
 * Never refresh these allowlists from a target APK at patch time. */
public final class NativeContracts {
    private NativeContracts() {}
    public static final String MERGE = "Lavuz;->O(Lavuz;Landroid/app/Application;ZZ)V";
    private static final String RENDER_DISPATCH = "Lbbpe;->m(Lavoh;)V";
    private static final String RENDER_LAYER = "Lavvk;->c(Lcbei;)V";
    private static final Set<String> RENDER_DISPATCH_HASHES = Collections.singleton("219ee7789e7ca966aab15916942bc2bdacd4e0284ec6fd7b23c5bc90c38e0228");
    private static final Set<String> RENDER_LAYER_HASHES = Collections.singleton("61b8eed62b2d29e0692bb431679e9c228ab2aa98124045f309544e3fc982b583");
    private static final String PARSE = "Lavuz;->ak(Lcqmj;Landroid/app/Application;ILawub;Ljava/lang/String;I)V";
    // Original parser and inspected upstream 2.9.10 Hide ads form: exactly three
    // instructions gate promoted rows on Shapes.HIDE_ADS; model ownership is unchanged.
    private static final Set<String> PARSE_HASHES = Collections.unmodifiableSet(new LinkedHashSet<String>(Arrays.asList(
        "6c130956870ffda0f3b8273d8a3cd27b9bc4ca695f4cf89d414dfd5c5f4295f8",
        "eba13f4b256879841c83ff98aaecec794dca95f6e7a174d0c6bdcfdc896c303d")));
    private static final Set<String> MERGE_HASHES = Collections.singleton("3e977b53f02c8b42aa037ad1550d6d76a9e75c1c07b43586bb973d52614e9ced");

    private static final Set<String> TARGET_HASHES = Collections.singleton("a6b5eda4e2accb30871dff89fe33c6f3308eb4ae4d04cb907c70da4d79cf49fe");
    private static final Set<String> QUERY_GETTER_HASHES = Collections.singleton("0ad0ea5093d7d50a5cbdeadd8f68d97f7e653d49cd68509bbb41859ee0e827c6");

    private static void require(boolean ok, String why) {
        MapsStrictSearchPatch.require(ok, why);
    }
    private static ClassDef type(MapsStrictSearchPatch.Lookup lookup, String descriptor,
                                 String superclass, int flags) {
        ClassDef type = lookup.get(descriptor);
        require(type != null && descriptor.equals(type.getType()), "Missing native class " + descriptor);
        require(superclass.equals(type.getSuperclass()) && type.getAccessFlags() == flags,
            "Native class shape changed " + descriptor);
        return type;
    }
    private static void field(ClassDef owner, String name, String descriptor, int flags) {
        Field found = null;
        for (Field candidate : owner.getFields()) if (name.equals(candidate.getName())) {
            require(found == null, "Ambiguous native field " + owner.getType() + "->" + name);
            found = candidate;
        }
        require(found != null && owner.getType().equals(found.getDefiningClass())
            && descriptor.equals(found.getType()) && found.getAccessFlags() == flags,
            "Native field shape changed " + owner.getType() + "->" + name + ":" + descriptor);
    }
    private static int instructionCount(Method method) {
        require(method.getImplementation() != null, "Missing native method body");
        int count = 0;
        for (Instruction ignored : method.getImplementation().getInstructions()) count++;
        return count;
    }

    public static void validate(MapsStrictSearchPatch.Lookup lookup) {
        require(lookup != null, "Missing native class lookup");
        ClassDef request = type(lookup, "Lavuw;", "Lawts;", 1);
        require(request.getInterfaces().contains("Ljava/io/Serializable;"),
            "Search request serialization contract changed");
        field(request, "l", "Lawxi;", 2);
        field(request, "b", "Lonv;", 1);
        field(request, "g", "Lavuz;", 1);

        ClassDef parameters = type(lookup, "Lcqmf;", "Lcnbu;", 17);
        require(parameters.getInterfaces().contains("Lcncz;"),
            "Search parameter protobuf contract changed");
        field(parameters, "a", "Lcqmf;", 25);
        field(parameters, "e", "Ljava/lang/String;", 1);

        Method getter = MapsStrictSearchPatch.find(request, "Lavuw;->c()Lcqmf;");
        require(getter.getAccessFlags() == 17 && getter.getImplementation() != null
            && getter.getImplementation().getRegisterCount() == 3 && instructionCount(getter) == 10,
            "Request query decoder shape changed");
        require(QUERY_GETTER_HASHES.contains(MapsStrictSearchPatch.fingerprint(getter)),
            "Request query decoder fingerprint changed");
        validateTarget(MapsStrictSearchPatch.find(request, MapsStrictSearchPatch.TARGET));
        validateModel(type(lookup, "Lavuz;", "Lont;", 1));
        ClassDef scopeOwner = type(lookup, "Lont;", "Ljava/lang/Object;", 1025);
        require(scopeOwner.getInterfaces().contains("Ljava/io/Serializable;"), "Search model base contract changed");
        Method writeScope = MapsStrictSearchPatch.find(scopeOwner, "Lont;->e()Lons;");
        require(writeScope.getAccessFlags() == 17 && writeScope.getImplementation() != null
            && writeScope.getImplementation().getRegisterCount() == 2 && instructionCount(writeScope) == 9
            && MapsStrictSearchPatch.fingerprint(writeScope).equals("bc9b51f16f2d98f07804758838ed1f67064f8d483d54e40a7cf9f476f978e01e"),
            "Search model write-lock contract changed");
        ClassDef scope = type(lookup, "Lons;", "Ljava/lang/Object;", 1537);
        require(scope.getInterfaces().contains("Ljava/lang/AutoCloseable;"), "Search model scope is not closeable");
        Method close = MapsStrictSearchPatch.find(scope, "Lons;->close()V");
        require(close.getAccessFlags() == 1025 && close.getImplementation() == null, "Search model scope close contract changed");
        validateRenderer(lookup);
        RuntimeContracts.validate(lookup);
    }

    private static void validateRenderer(MapsStrictSearchPatch.Lookup lookup) {
        renderer(lookup, "Lbbpe;", RENDER_DISPATCH, 200, 415, RENDER_DISPATCH_HASHES);
        renderer(lookup, "Lavvk;", RENDER_LAYER, 190, 378, RENDER_LAYER_HASHES);
    }

    private static void renderer(MapsStrictSearchPatch.Lookup lookup, String owner,
                                 String descriptor, int instructions, int codeUnits,
                                 Set<String> fingerprints) {
        ClassDef type = type(lookup, owner, "Ljava/lang/Object;", 17);
        require(type.getInterfaces().isEmpty(), "Search renderer interfaces changed " + owner);
        Method method = MapsStrictSearchPatch.find(type, descriptor);
        require(method.getAccessFlags() == 17 && method.getImplementation() != null
            && method.getImplementation().getRegisterCount() == 9
            && instructionCount(method) == instructions,
            "Search renderer method shape changed " + descriptor);
        int units = 0;
        for (Instruction instruction : method.getImplementation().getInstructions()) units += instruction.getCodeUnits();
        require(units == codeUnits && fingerprints.contains(MapsStrictSearchPatch.fingerprint(method)),
            "Search renderer method fingerprint changed " + descriptor);
    }

    public static void validateModel(ClassDef model) {
        require(model != null && "Lavuz;".equals(model.getType()) && "Lont;".equals(model.getSuperclass())
            && model.getAccessFlags() == 1, "Search model shape changed");
        field(model, "U", "Lcqmj;", 130);
        field(model, "aj", "Lawxi;", 2);
        field(model, "g", "Ljava/lang/String;", 1);
        for (Field candidate : model.getFields())
            require(!candidate.getName().equals(MapsStrictSearchPatch.MARKER), "Search success marker already installed");
        Method merge = MapsStrictSearchPatch.find(model, MERGE);
        require(merge.getAccessFlags() == 17 && merge.getImplementation() != null
            && merge.getImplementation().getRegisterCount() == 13 && instructionCount(merge) == 289,
            "Search merge method shape changed");
        require(MERGE_HASHES.contains(MapsStrictSearchPatch.fingerprint(merge)), "Search merge method fingerprint changed");
        require(MapsStrictSearchPatch.mergeInsertionIndex(merge) == 268, "Accepted merge boundary changed");
        Method parse = MapsStrictSearchPatch.find(model, PARSE);
        require(parse.getAccessFlags() == 17 && parse.getImplementation() != null
            && parse.getImplementation().getRegisterCount() == 26 && (instructionCount(parse) == 710 || instructionCount(parse) == 713)
            && PARSE_HASHES.contains(MapsStrictSearchPatch.fingerprint(parse)), "Search model response ownership changed");
    }

    public static void validateTarget(Method method) {
        require(method != null && MapsStrictSearchPatch.TARGET.equals(MapsStrictSearchPatch.descriptor(method)),
            "Unexpected search response method");
        require(method.getAccessFlags() == 17 && method.getImplementation() != null
            && method.getImplementation().getRegisterCount() == 13 && instructionCount(method) == 87,
            "Search response method shape changed");
        require(TARGET_HASHES.contains(MapsStrictSearchPatch.fingerprint(method)),
            "Search response method fingerprint changed");
        require(MapsStrictSearchPatch.insertionIndex(method) == 10,
            "Search request/response hook position changed");
    }
}
