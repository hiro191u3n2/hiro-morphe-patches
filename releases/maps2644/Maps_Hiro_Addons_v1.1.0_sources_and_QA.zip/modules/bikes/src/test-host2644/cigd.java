import java.util.ArrayList;
import java.util.List;
public final class cigd { public List<cigc> b = new ArrayList<cigc>(); }
