#!/usr/bin/env python3
"""Build only runtime helper classes and test event ordering with local fakes."""
from pathlib import Path
import hashlib,json,os,shutil,subprocess,zipfile,tempfile
ROOT=Path(__file__).resolve().parent
AUDIT=ROOT.parents[1]
JAVA=AUDIT/'diagnostic/java21/jdk-21.0.13+9-jre/bin/java'
ECJ=AUDIT/'direct_diagnostic/toolchain/ecj-3.46.100.jar'
D8=AUDIT/'direct_diagnostic/toolchain/r8-9.5.28.jar'
MORPHE=AUDIT/'diagnostic/morphe-desktop-1.19.0-dev.19-all.jar'
BUILD=Path(tempfile.mkdtemp(prefix='runtime_build_',dir=ROOT))
STUBS=BUILD/'stubs'
CLASSES=BUILD/'classes'
DEX=BUILD/'dex'
TEST=BUILD/'tests'
for p in (STUBS,CLASSES,DEX,TEST):
 p.mkdir(parents=True)

def compile(sources,output,classpath=None):
 cmd=[str(JAVA),'-jar',str(ECJ),'-source','11','-target','11','-encoding','UTF-8','-d',str(output)]
 if classpath:cmd += ['-cp',str(classpath)]
 subprocess.run(cmd+list(map(str,sources)),check=True)

compile(sorted((ROOT/'runtime_stubs').rglob('*.java')),STUBS)
compile(sorted((ROOT/'runtime_src').rglob('*.java')),CLASSES,STUBS)
stub_jar=ROOT/'runtime_compile_only_stubs.jar'
with zipfile.ZipFile(stub_jar,'w',zipfile.ZIP_DEFLATED) as z:
 for p in sorted(STUBS.rglob('*.class')):z.write(p,p.relative_to(STUBS))
runtime_classes=sorted(CLASSES.rglob('*.class'))
subprocess.run([str(JAVA),'-cp',str(D8),'com.android.tools.r8.D8','--release','--min-api','26',
 '--classpath',str(stub_jar),'--output',str(DEX),*map(str,runtime_classes)],check=True)
extension=ROOT/'extensions/berry_bfcache_restore.mpe';extension.parent.mkdir(exist_ok=True)
shutil.copy2(DEX/'classes.dex',extension)

# The JVM tests compile their own Android fakes; none are included in the MPE.
compile(sorted((ROOT/'runtime_tests/src').rglob('*.java'))+sorted((ROOT/'runtime_src').rglob('*.java')),TEST)
script_dir=ROOT/'runtime_tests/generated'
jvm=subprocess.run([str(JAVA),'-cp',str(TEST),'RestoreCoordinatorTest',str(script_dir)],check=True,capture_output=True,text=True)
node=os.environ.get('CODEX_PRIMARY_RUNTIME_NODE') or shutil.which('node')
if not node:raise RuntimeError('Node runtime unavailable')
js=subprocess.run([str(node),str(ROOT/'runtime_tests/check_script.js'),str(script_dir)],check=True,capture_output=True,text=True)
(ROOT/'runtime_tests/jvm_result.json').write_text(jvm.stdout)
(ROOT/'runtime_tests/js_result.json').write_text(js.stdout)
metadata={'result':'PASS','extension':str(extension),'extension_bytes':extension.stat().st_size,
 'extension_sha256':hashlib.sha256(extension.read_bytes()).hexdigest(),
 'runtime_classes':[str(p.relative_to(CLASSES)) for p in runtime_classes],
 'compile_only_android_stubs_packaged':False,
 'source_sha256':{str(p.relative_to(ROOT)):hashlib.sha256(p.read_bytes()).hexdigest() for p in sorted((ROOT/'runtime_src').rglob('*.java'))},
 'jvm_test':json.loads(jvm.stdout),'javascript_test':json.loads(js.stdout),
 'android_device_tested':False,'renderer_behavior_tested':False}
(ROOT/'RUNTIME_BUILD_QA.json').write_text(json.dumps(metadata,ensure_ascii=False,indent=2)+'\n')
published_classes=ROOT/'runtime_classes'
if published_classes.exists():shutil.rmtree(published_classes)
shutil.copytree(CLASSES,published_classes)
shutil.rmtree(BUILD)
print(json.dumps(metadata,ensure_ascii=False,indent=2))
