package app.morphe.patcher.patch;

/**
 * Compile-time declaration only. NEVER packaged or used at runtime.
 *
 * Morphe retains this exact legacy constructor for existing MPPs, but marks it
 * JVM-synthetic in the newer host jar. Expose it to the Java compiler so our
 * bytecode uses the same descriptor as the user's working Berry v1.3.1 bundle:
 * (Ljava/lang/String;ZLjava/lang/Integer;)V.
 */
public final class AppTarget {
    public AppTarget(String version, boolean experimental, Integer minSdk) {}
}
