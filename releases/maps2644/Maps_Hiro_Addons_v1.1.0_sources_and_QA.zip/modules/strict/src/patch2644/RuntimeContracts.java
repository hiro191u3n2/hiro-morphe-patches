package app.hiro.mapsstrict2644.patches;
import java.nio.charset.StandardCharsets;
import java.security.MessageDigest;
import java.util.*;
import com.android.tools.smali.dexlib2.iface.*;
import com.android.tools.smali.dexlib2.iface.instruction.*;
import com.android.tools.smali.dexlib2.iface.instruction.formats.ArrayPayload;
import com.android.tools.smali.dexlib2.iface.reference.*;
/** Frozen response/protobuf schema and code from both inspected APKs; never learned at patch time. */
public final class RuntimeContracts {
    private RuntimeContracts() {}
    private static final String[][] CLASSES = {
        {"Lcnbu;", "ab036fbffcee15fafb342cb9be7f5e1a8678721a8a8427978a727069122d6ef4", "23aa337dca10a2a2f6cff81964f1960a4c1c43ffbaca23b3d76dabf1a49228ca"},
        {"Lcnbm;", "21be447057500d586aa85529a615cdb7b352bc65fd5bfd9fc7270dad93b1f458", "160930c359d2134d43a07e7023fa7d2d641169634015a0ed0539f09157c18236"},
        {"Lcncl;", "9037479cdc0a36bb9183481cbb5a1afdbe6723d3b49f9331e8cec4bcfe6467e0", "a0b10e64c695419614b3fc6da4ad32ae6f414d5f312112438e03a8b2b48bc04b"},
        {"Lcqmj;", "31f1f0cb3a771b7dda5e8e98146595cb0952b9168c654bc9a69eaba31d95f7c1", "4dbc2f0c72bf6e6b3e1e0bda0d0a67da0048ea55f232fb6b4f88bb2e2667ca2f"},
        {"Lcqjl;", "5606583432516dff9d380e4f0ec985472c8511db88451bb5fc41f99f75eb3136", "83ced32fe4cb81334b38b411b6f183c546fd4bd61cd806a9df0c1899452cfe93"},
        {"Lchag;", "f53ece227b1037a3979cc66312d5e81a065068fabdf4a64851f9896e1df2f3ec", "6739912128109b20af01bc5f0a1c5c298fb7653e28dfe34308519c9f59734e72"},
        {"Lccap;", "5839bd3cb320471a25b0d1fbc3dddaf0a04577044b99e9ec03b5bd79c014559d", "1969f2c8958ba4dc0b462382ff9feba57d483aa243eacc2e71962f4c5ad38ef4"},
        {"Lcjms;", "58143ba86f1eebe3bb6e932e53f83f40e8dfb0ba343b0344e6128c183bc3ccb3", "75f83c7a1878e9a27e3ea123d1b24fdf81d5c9a1f0e437efd701208e3035587c"},
        {"Lcbei;", "e5b9f84b029d8566ba9b4aa40fb6f3deb1e6f051f8a00ad5fd3b141c08a1f253", "254a446ac80b21fe7ed26d4cb53b34c1987979db6aa309a52a0ea1cdd4ec4b96"},
        {"Lcfek;", "9c12fd1632db6e4d32a47b801bc173a19ab55ad4b8ded35ef62e206d6393dc8a", "c41643acebb7fdbc26ebe12b2a0c94ae75f720533b7b75d680781428d4290ab3"},
        {"Lcffs;", "6093cd7590efeded59c863d7d9cc19762b71c054066c022ff8b5495e5afa0dc2", "7e83f3c2c19c90a772b745858c4f2523392c2065040fa9fdfd10caa53eeb1991"},
        {"Lcffr;", "8bd384984fc67b1d861e211d4a7a45005e743215c4b45b7cfb7164f46aa5b4d1", "5cadb331159488317f55a40950e792c8dbead10148ce5c5ade186d17adc2c785"},
        {"Lcfgf;", "dc243a472cb0ea8754da45cc97bd5da130576057674abfbb445775cd91de92e6", "af5ab36104b1de4eb042e53841c2a62f03072c039b67989fc77d4a685525ea1f"},
        {"Lcfge;", "11d676b86e9bb5cdefb3022544930abef5d3d3f1071a74be1d90799e00eb6e65", "8816cacfda731f1e09e1a94037fda06fbc8ed45e5e0d2dd694c26167de63b733"},
        {"Lcfei;", "8c07a3f780159544ddb96913d5283fbc491dd4b886b46d7096febdc809b60046", "2abd1ce3475d1df82507c2ac93dc168625e5209cd80f26c69f835211d50026e3"},
        {"Lcflf;", "19c65b38ec9dd7fca94bec2b8685064600749a1abf0f9f715b4af72c8241b8a6", "48a9d25ba2d77a79fb91fac4913f0ac5218defd4f91b72738a81383e8064667c"},
        {"Lcfle;", "31e41369171e61c517d436eb823b669eb56363c434c7e68051613860d506cdb4", "5c237c2d8fb1ea8211d42feb4bcc4a401aad650e34f1df31718a0b77958fdfa2"},
        {"Lcbej;", "740a26a32bd9c57601a4c0cd83e60acc21f63fa99da0db2381d9b2af6088fdde", "8caecdbada4c4e57daec076f3cbb265eda0bde8f08cbe438b6730163e7c55037"},
        {"Lccma;", "b4bd03470177ed9383ecb0d3b8e0b0129b39f99475eb69ae3ad8d295281242d1", "75ebc9af8181f2b4ba40a06236519bd3af1e991a0d9d1154aa2c2771ebf08840"},
        {"Lckjy;", "4ec3d9c24b85f14a5e7361080c3eb94963ae62a19002d6247d0742e0acc0e333", "ff08ae23da57a937410a0fdeac5b510a398a4e6d7f51afac7846f79d0067591a"},
        {"Lccaj;", "0f7ce7895fb04a31bbfebb3316c995a9ee0805714f6cbcc949c62ccbcf452754", "ebd31001c443369647f3cdd80f4c2f9390655142a835861e51662f4613dacd07"},
        {"Lcbek;", "a590c6a62ebbde783738dbef8144c33512467871d7c1df4036ddd9cecc35c540", "4953c9927ab5a134486b150421268a30da003daacf7ed905be462877db6b3ea4"},
        {"Lcbef;", "cf3a140f4fc50b878a0e089ff221b552c91168d85c4bbf730e25711e6a9f565b", "01823be28c180d0bf4e85706113d296579a3b225da6c7da4b6b7377d5a99807c"},
        {"Lcbeh;", "90a832944c4639223f217b960033cf8e7530449e582059e3789d5e4deea46f49", "f6f27e6a0c10d46f275673030f83194c76237ef6e9ce3db1d755f1e7dd42bd2c"},
        {"Lccmb;", "7b2bf3bfcd8c85694053d63c09bc0db649eb02abe2c501afec6b4832342627ae", "83549b1bfa2868f1406cd0f535100a1c107c8de84adb691abc69532cdad46473"},
    };
    static String descriptor(MethodReference m) { return MapsStrictSearchPatch.descriptor(m); }
    static String hash(String s) {
        try {
            byte[] digest=MessageDigest.getInstance("SHA-256").digest(s.getBytes(StandardCharsets.UTF_8));
            StringBuilder b=new StringBuilder();
            for(byte x:digest)b.append(String.format(Locale.ROOT,"%02x",x&255));
            return b.toString();
        } catch(Exception e) { throw new IllegalStateException("Cannot validate response schema",e); }
    }
    public static void validate(MapsStrictSearchPatch.Lookup lookup) {
        for(String[] expected:CLASSES) {
            ClassDef c=lookup.get(expected[0]);
            MapsStrictSearchPatch.require(c!=null,"Missing response/protobuf class "+expected[0]);
            MapsStrictSearchPatch.require(expected[1].equals(hash(classApi(c))),"Response schema changed "+expected[0]);
            MapsStrictSearchPatch.require(expected[2].equals(hash(classBody(c))),"Response/protobuf code changed "+expected[0]);
        }
    }
  static String ref(Reference r){return r instanceof MethodReference?descriptor((MethodReference)r):r.toString();}
  static String body(Method m) {
    MethodImplementation code=m.getImplementation();if(code==null)return "abstract";
    StringBuilder b=new StringBuilder("registers=").append(code.getRegisterCount()).append('\n');
    int at=0;
    for(Instruction i:code.getInstructions()) {
      b.append(at).append(' ').append(i.getOpcode()).append(' ').append(i.getCodeUnits());
      if(i instanceof RegisterRangeInstruction){RegisterRangeInstruction r=(RegisterRangeInstruction)i;b.append(" range=").append(r.getStartRegister()).append(',').append(r.getRegisterCount());}
      else if(i instanceof FiveRegisterInstruction){FiveRegisterInstruction r=(FiveRegisterInstruction)i;int[] v={r.getRegisterC(),r.getRegisterD(),r.getRegisterE(),r.getRegisterF(),r.getRegisterG()};b.append(" regs=");for(int j=0;j<r.getRegisterCount();j++)b.append(v[j]).append(',');}
      else if(i instanceof ThreeRegisterInstruction){ThreeRegisterInstruction r=(ThreeRegisterInstruction)i;b.append(" regs=").append(r.getRegisterA()).append(',').append(r.getRegisterB()).append(',').append(r.getRegisterC());}
      else if(i instanceof TwoRegisterInstruction){TwoRegisterInstruction r=(TwoRegisterInstruction)i;b.append(" regs=").append(r.getRegisterA()).append(',').append(r.getRegisterB());}
      else if(i instanceof OneRegisterInstruction)b.append(" reg=").append(((OneRegisterInstruction)i).getRegisterA());
      if(i instanceof ReferenceInstruction)b.append(" ref=").append(ref(((ReferenceInstruction)i).getReference()));
      if(i instanceof DualReferenceInstruction)b.append(" ref2=").append(ref(((DualReferenceInstruction)i).getReference2()));
      if(i instanceof WideLiteralInstruction)b.append(" lit=").append(((WideLiteralInstruction)i).getWideLiteral());
      if(i instanceof OffsetInstruction)b.append(" offset=").append(((OffsetInstruction)i).getCodeOffset());
      if(i instanceof SwitchPayload){b.append(" switches=");for(SwitchElement e:((SwitchPayload)i).getSwitchElements())b.append(e.getKey()).append(':').append(e.getOffset()).append(',');}
      if(i instanceof ArrayPayload){ArrayPayload a=(ArrayPayload)i;b.append(" array=").append(a.getElementWidth()).append(':').append(a.getArrayElements());}
      if(i instanceof VerificationErrorInstruction)b.append(" verification=").append(((VerificationErrorInstruction)i).getVerificationError());
      if(i instanceof InlineIndexInstruction)b.append(" inline=").append(((InlineIndexInstruction)i).getInlineIndex());
      if(i instanceof VtableIndexInstruction)b.append(" vtable=").append(((VtableIndexInstruction)i).getVtableIndex());
      if(i instanceof FieldOffsetInstruction)b.append(" fieldoffset=").append(((FieldOffsetInstruction)i).getFieldOffset());
      b.append('\n');at+=i.getCodeUnits();
    }
    for(TryBlock<? extends ExceptionHandler> t:code.getTryBlocks()){
      b.append("try ").append(t.getStartCodeAddress()).append(' ').append(t.getCodeUnitCount());
      for(ExceptionHandler h:t.getExceptionHandlers())b.append(' ').append(h.getExceptionType()).append(':').append(h.getHandlerCodeAddress());
      b.append('\n');
    }
    return b.toString();
  }
  static String classApi(ClassDef c) {
    StringBuilder b=new StringBuilder(c.getType()).append(' ').append(c.getAccessFlags()).append(' ').append(c.getSuperclass()).append(' ').append(c.getInterfaces()).append('\n');
    List<String> fields=new ArrayList<>();for(Field f:c.getFields())fields.add(f.toString()+" "+f.getAccessFlags()+" "+f.getInitialValue());Collections.sort(fields);for(String f:fields)b.append(f).append('\n');
    List<String> methods=new ArrayList<>();for(Method m:c.getMethods())methods.add(descriptor(m)+" "+m.getAccessFlags());Collections.sort(methods);for(String m:methods)b.append(m).append('\n');
    return b.toString();
  }
  static String classBody(ClassDef c) {
    StringBuilder b=new StringBuilder(classApi(c));
    List<Method> ms=new ArrayList<>();for(Method m:c.getMethods())ms.add(m);ms.sort(Comparator.comparing(RuntimeContracts::descriptor));
    for(Method m:ms)b.append(descriptor(m)).append('\n').append(body(m));
    return b.toString();
  }
}
