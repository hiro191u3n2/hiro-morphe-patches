import android.webkit.WebView;
import hiro.berrybfcache.RestoreCoordinator;
import java.lang.reflect.InvocationHandler;
import java.lang.reflect.Method;
import java.nio.file.Files;
import java.nio.file.Path;

public final class RestoreCoordinatorTest {
    private static final String URL = "https://example.test/list";
    private static final String OTHER = "https://example.test/product";
    private static int assertions;
    private static int scenarios;
    public interface Boundary {
        void onPostMessage(WebView view, InvocationHandler message, Object origin, boolean mainFrame, InvocationHandler reply);
        String[] getSupportedFeatures();
    }
    private static final Method POST;
    static {
        try { POST = Boundary.class.getMethod("onPostMessage", WebView.class, InvocationHandler.class, Object.class, boolean.class, InvocationHandler.class); }
        catch (Exception error) { throw new RuntimeException(error); }
    }
    private static final class Counter implements Runnable { int n; public void run() { n++; } }
    private static void check(boolean ok, String message) {
        assertions++; if (!ok) throw new AssertionError(message);
    }
    private static String marker(String doc, int serial, boolean pending) {
        return "\"B1|" + doc + "|" + serial + "|" + (pending ? "1" : "0") + "\"";
    }
    private static void wake(WebView view) throws Throwable { send(view, true, "hiro-bfcache-restored-v1"); }
    private static void send(WebView view, boolean main, final String payload) throws Throwable {
        InvocationHandler data = new InvocationHandler() {
            public Object invoke(Object proxy, Method method, Object[] args) { return payload; }
        };
        RestoreCoordinator.listener().invoke(null, POST, new Object[] {view, data, null, Boolean.valueOf(main), null});
    }
    private static WebView begin(Counter counter) {
        WebView view = new WebView(URL);
        RestoreCoordinator.started(view, URL);
        RestoreCoordinator.committed(view, URL, counter);
        return view;
    }
    public static void main(String[] args) throws Throwable {
        if (args.length > 0) {
            Path directory = Path.of(args[0]); Files.createDirectories(directory);
            Files.writeString(directory.resolve("document_start.js"), RestoreCoordinator.script() + "\n");
            java.lang.reflect.Field field = RestoreCoordinator.class.getDeclaredField("PROBE"); field.setAccessible(true);
            Files.writeString(directory.resolve("probe.js"), (String) field.get(null) + "\n");
        }
        final int[] nativeCalls = {0};
        hiro.berrybfcache.CompletionTarget target = new hiro.berrybfcache.CompletionTarget() {
            public void hiroCompleteBfcache(WebView view, String url) { nativeCalls[0]++; }
        };
        WebView nativeView = new WebView(URL);
        hiro.berrybfcache.NativeCompletion nativeAction = new hiro.berrybfcache.NativeCompletion(target, nativeView, URL);
        nativeAction.run(); nativeView.url = OTHER; nativeAction.run();
        check(nativeCalls[0] == 1, "native completion checks the current URL");
        int weakFields = 0;
        for (java.lang.reflect.Field field : nativeAction.getClass().getDeclaredFields()) {
            if (field.getType() == java.lang.ref.WeakReference.class) weakFields++;
            check(field.getType() != WebView.class && field.getType() != hiro.berrybfcache.CompletionTarget.class,
                "native action does not retain view/client strongly");
        }
        check(weakFields == 2, "both native object references are weak"); scenarios++;

        Counter c = new Counter(); WebView v = begin(c);
        v.answer(0, marker("documenta", 0, false));
        check(c.n == 0 && v.visuals.isEmpty(), "ordinary load must not complete or redraw"); scenarios++;

        c = new Counter(); v = begin(c);
        v.answer(0, marker("documenta", 0, false)); wake(v);
        v.answer(1, marker("documenta", 1, true));
        check(c.n == 1 && v.visuals.size() == 1 && v.invalidations == 0, "commit then pageshow waits for visual callback");
        v.draw(0); check(v.invalidations == 1, "ready frame redrawn"); scenarios++;

        c = new Counter(); v = new WebView(URL); RestoreCoordinator.started(v, URL); wake(v);
        check(v.reads.isEmpty(), "pageshow before commit only leaves document marker");
        RestoreCoordinator.committed(v, URL, c); v.answer(0, marker("documentb", 1, true));
        check(c.n == 1, "pageshow then commit repaired"); scenarios++;

        c = new Counter(); v = begin(c); wake(v);
        v.answer(0, marker("documentc", 0, false));
        check(v.reads.size() == 2, "notification during in-flight false read causes another read");
        v.answer(1, marker("documentc", 1, true)); check(c.n == 1, "in-flight event not lost"); scenarios++;

        wake(v); v.answer(2, marker("documentc", 1, true));
        RestoreCoordinator.committed(v, URL, c); v.answer(3, marker("documentc", 1, true));
        check(c.n == 1 && v.visuals.size() == 1, "duplicate event and commit not completed twice");
        v.draw(0); check(v.invalidations == 1, "duplicate commit preserves pending visual callback"); scenarios++;

        c = new Counter(); v = begin(c); RestoreCoordinator.started(v, OTHER); v.url = OTHER;
        v.answer(0, marker("documentd", 1, true));
        check(c.n == 0 && v.visuals.isEmpty(), "stale script result after navigation ignored"); scenarios++;

        c = new Counter(); v = begin(c); v.answer(0, marker("documente", 1, true));
        RestoreCoordinator.started(v, OTHER); v.url = OTHER; v.draw(0);
        check(c.n == 1 && v.invalidations == 0, "stale visual callback cannot redraw another page"); scenarios++;

        c = new Counter(); v = begin(c); v.answer(0, marker("documentf", 0, false));
        // New cached document can have the same URL. Its message may precede native started.
        wake(v); v.answer(1, marker("documentg", 1, true));
        check(c.n == 0, "message cannot bind a different document to an old commit");
        RestoreCoordinator.started(v, URL); RestoreCoordinator.committed(v, URL, c);
        v.answer(2, marker("documentg", 1, true)); check(c.n == 1, "new commit binds that document"); scenarios++;

        RestoreCoordinator.started(v, OTHER); v.url = OTHER; RestoreCoordinator.committed(v, OTHER, c);
        v.answer(3, marker("documenth", 1, true));
        check(c.n == 2, "same serial from another cached document is a different event"); scenarios++;

        c = new Counter(); v = begin(c); v.answer(0, marker("documenti", 0, false));
        send(v, false, "hiro-bfcache-restored-v1"); send(v, true, "unrelated message");
        check(v.reads.size() == 1 && c.n == 0, "subframe and unrelated messages ignored");
        wake(v); v.answer(1, marker("documenti", 0, false));
        check(c.n == 0, "spoofed notification alone is not proof of a cache restore"); scenarios++;

        c = new Counter(); v = begin(c); v.answer(0, "null");
        check(c.n == 0 && v.visuals.isEmpty(), "missing marker fails closed"); scenarios++;

        c = new Counter(); v = begin(c); v.answer(0, "\"B1|documentj|1|notboolean\"");
        check(c.n == 0, "malformed marker rejected"); scenarios++;

        c = new Counter(); v = begin(c); v.answer(0, marker("documentk", 1, true)); v.attached = false; v.draw(0);
        check(v.invalidations == 0, "detached view not redrawn"); scenarios++;

        c = new Counter(); v = new WebView(URL); android.os.Looper.background = true;
        RestoreCoordinator.started(v, URL); RestoreCoordinator.committed(v, URL, c);
        check(v.reads.isEmpty() && v.posts.size() == 2, "off-main callbacks marshal to view queue");
        v.flushPosts(); v.answer(0, marker("documentl", 1, true));
        check(c.n == 1, "marshalled callbacks keep their order"); scenarios++;

        c = new Counter(); v = new WebView(URL); RestoreCoordinator.started(v, URL);
        RestoreCoordinator.committed(v, OTHER, c);
        check(v.reads.isEmpty(), "wrong URL commit ignored"); scenarios++;

        c = new Counter(); v = begin(c); v.answer(0, marker("documentm", 1, true));
        RestoreCoordinator.started(v, URL); RestoreCoordinator.committed(v, URL, c); v.draw(0);
        check(v.invalidations == 0, "same-URL newer generation rejects old visual callback");
        v.answer(1, marker("documentm", 2, true)); v.draw(1);
        check(c.n == 2 && v.invalidations == 1, "subsequent restore of same document handled once"); scenarios++;

        System.out.println("{\"result\":\"PASS\",\"scenarios\":" + scenarios + ",\"assertions\":" + assertions +
            ",\"scope\":\"JVM callback-order simulation; no Android renderer or device execution\"}");
    }
}
