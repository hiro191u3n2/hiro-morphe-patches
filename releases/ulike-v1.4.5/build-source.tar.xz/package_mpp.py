#!/usr/bin/env python3
"""Reproducible release archive; verify exact predecessor and retained resources."""
import hashlib,json,zipfile,argparse
from pathlib import Path
STAMP=(2026,9,28,5,50,0)
def manifest(integrated):
 name='ひろ Morphe 統合パッチ' if integrated else 'ひろ ULike 高画質・質感美肌・素材通信復旧'
 version='1.0.83' if integrated else '1.4.5'
 text=f'''Manifest-Version: 1.0
Name: {name}
Description: 素材取得に必要な端末登録・設定初期化を復旧。操作履歴送信・プッシュ停止は維持。端末登録の通信は許可。実機での素材取得は未確認。
Version: {version}
Timestamp: 2026-09-28T14:50:00
Source: remote
Author: ひろ
Contact: na
Website: na
License: GPLv3
Patcher-Version: 1.8.0

'''
 lines=[]
 for line in text.splitlines():
  b=line.encode(); prefix=b''
  while len(prefix)+len(b)>72:
   n=72-len(prefix)
   while n and b[n]&0xc0==0x80:n-=1
   lines.append(prefix+b[:n]);b=b[n:];prefix=b' '
  lines.append(prefix+b)
 return b'\r\n'.join(lines)+b'\r\n'
def package(old,out,build,integrated):
 expected='ea03dbad63e1833213e1b272c9e78a0826207d16245667b1e3620bfe51c1f831' if integrated else 'c8c7a705054b5f2850e090c330381c733708434d76923de79f7c262e3834bd2f'
 assert hashlib.sha256(old.read_bytes()).hexdigest()==expected,'Unexpected predecessor'
 changes={}; retained=[]
 with zipfile.ZipFile(old) as z,zipfile.ZipFile(out,'w',zipfile.ZIP_DEFLATED,compresslevel=9) as w:
  assert len(z.namelist())==len(set(z.namelist()))
  for entry in z.namelist():
   prev=data=z.read(entry)
   if entry=='META-INF/MANIFEST.MF':data=manifest(integrated)
   elif entry=='classes.dex':data=(build/('integrated-new.dex' if integrated else 'newdex/classes.dex')).read_bytes()
   elif entry=='app/hiro/ulike/patches/UlikeHqMaxPatch.class':data=(build/'newpatch'/entry).read_bytes()
   elif entry in ['ulike/methods.dex','ulike/methods.tsv']:data=(build/Path(entry).name).read_bytes()
   if prev!=data:changes[entry]=hashlib.sha256(data).hexdigest()
   else:retained.append(entry)
   zi=zipfile.ZipInfo(entry,STAMP);zi.compress_type=zipfile.ZIP_DEFLATED;w.writestr(zi,data)
 expected_changes={'META-INF/MANIFEST.MF','classes.dex','ulike/methods.dex','ulike/methods.tsv'}
 if not integrated:expected_changes.add('app/hiro/ulike/patches/UlikeHqMaxPatch.class')
 assert set(changes)==expected_changes,changes
 with zipfile.ZipFile(out) as z:assert z.testzip() is None
 return dict(file=out.name,bytes=out.stat().st_size,sha256=hashlib.sha256(out.read_bytes()).hexdigest(),changed_entries=changes,retained_entries=retained)
def main():
 p=argparse.ArgumentParser();p.add_argument('--old-standalone',type=Path,required=True);p.add_argument('--old-integrated',type=Path,required=True);p.add_argument('--build',type=Path,default=Path('build'));p.add_argument('--output',type=Path,default=Path('dist'));a=p.parse_args();a.output.mkdir(parents=True,exist_ok=True)
 result=[package(a.old_standalone,a.output/'ULike_HQ_Texture_Online_v1.4.5.mpp',a.build,False),package(a.old_integrated,a.output/'Hiro_Morphe_Patches_v1.0.83.mpp',a.build,True)]
 (a.output/'build-artifacts.json').write_text(json.dumps(result,ensure_ascii=False,indent=2)+'\n');print(json.dumps(result,ensure_ascii=False,indent=2))
if __name__=='__main__':main()
