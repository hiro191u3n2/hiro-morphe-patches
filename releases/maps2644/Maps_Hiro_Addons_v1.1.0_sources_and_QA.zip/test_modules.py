#!/usr/bin/env python3
"""Run host regression fixtures and optional exact-APK structural/guard checks.

This does not run Android UI or substitute for the published full patch matrix.
"""
import argparse, json, os, subprocess, zipfile
from pathlib import Path
ROOT=Path(__file__).resolve().parent

def main():
 p=argparse.ArgumentParser(description=__doc__)
 for key in ('tools','build','out'):p.add_argument('--'+key,type=Path,required=True)
 for key in ('apk2636','apk2644'):p.add_argument('--'+key,type=Path)
 a=p.parse_args()
 for key in vars(a):
  if getattr(a,key) is not None:setattr(a,key,getattr(a,key).resolve())
 if a.out.exists() and any(a.out.iterdir()):raise RuntimeError('Use a fresh test directory')
 a.out.mkdir(parents=True,exist_ok=True);sdk=a.tools/'morphe-dev19.jar';results={}
 def cp(*paths):return os.pathsep.join(map(str,paths))
 def run(cmd,label):
  r=subprocess.run(list(map(str,cmd)),capture_output=True,text=True,timeout=600)
  (a.out/(label+'.log')).write_text(r.stdout+r.stderr)
  if r.returncode:raise RuntimeError(label+' failed:\n'+(r.stdout+r.stderr)[-6000:])
  results[label]=r.stdout.strip()
 def compile(sources,dest,classpath=None):
  dest.mkdir(parents=True,exist_ok=True)
  command=['java','-jar',a.tools/'ecj.jar','-21','-nowarn','-encoding','UTF-8','-d',dest]
  if classpath:command+=['-cp',classpath]
  run(command+list(sources),'compile-'+dest.name)
 def execute(classpath,main,args,label):run(['java','-ea','-Xmx2g','-cp',classpath,main,*args],label)
 # Compile tests independently by feature; intentional native fixture class names overlap.
 auditcp={}
 for name in ('category','back','bikes','startup','strict'):
  src=ROOT/'modules'/name/'src';sources=[]
  for folder in ('test','test2644','test-native'):
   if (src/folder).exists():sources+=sorted((src/folder).glob('*.java'))
  dest=a.out/(name+'-audit')
  compile(sources,dest,cp(a.build/'work'/name/'classes',sdk))
  auditcp[name]=cp(dest,a.build/'work'/name/'classes',sdk,a.build/(name+'.mpp'))
 for name in ('bikes','strict'):
  src=ROOT/'modules'/name/'src'
  for suffix,variant in (('', '2636'),('2644','2644')):
   dest=a.out/(name+'-host'+variant)
   sources=sorted((src/('runtime'+suffix)).rglob('*.java'))+sorted((src/('test-host'+suffix)).rglob('*.java'))
   compile(sources,dest)
   if name=='bikes':mains=['app.hiro.mapsbikes.BicycleMarkerFilterTest','app.hiro.mapsbikes.BicycleLegendFilterTest'] if variant=='2636' else ['app.hiro.mapsbikes.BicycleMarkerFilterTest','app.hiro.mapsbikes.BicycleLegendFilterTest']
   else:mains=['app.hiro.mapsstrict'+('2644' if suffix else '')+'.StrictNameMatcherTest','RuntimeFilterTest']
   for mainclass in mains:execute(str(dest),mainclass,[],name+'-'+variant+'-'+mainclass.rsplit('.',1)[-1])
 src=ROOT/'modules/startup/src';dest=a.out/'startup-host'
 compile([*sorted((src/'runtime').rglob('*.java')),*sorted((src/'test-stubs').rglob('*.java')),*sorted((src/'test-host').rglob('*.java'))],dest)
 execute(str(dest),'app.hiro.mapsstartup.StartupLocationHostTest',[],'startup-host')
 if a.apk2636 and a.apk2644:
  execute(auditcp['category'],'AuditNew',[a.apk2636,a.apk2644],'category-both-guards')
  execute(auditcp['bikes'],'SchemaAudit',[a.apk2636,a.apk2644],'bikes-native-schema')
 if a.apk2644:
  for name,mainclass in [('back','MapsBack2644Audit'),('bikes','MapsBikesAudit2644'),('startup','MapsStartup2644Audit'),('strict','MapsStrict2644Audit')]:
   execute(auditcp[name],mainclass,['guards',a.apk2644],name+'-2644-guards')
  execute(auditcp['strict'],'SchemaAudit',[a.apk2644],'strict-native-schema')
  execute(auditcp['startup'],'MapsStartup2644BridgeVmTest',[a.apk2644],'startup-native-bridge')
  execute(auditcp['startup'],'MapsStartup2644ColdLaunchAudit',[a.apk2644],'startup-native-cold-launch')
 (a.out/'results.json').write_text(json.dumps(results,ensure_ascii=False,indent=2)+'\n')
 print('PASS host/structural regression suite; Android UI not executed')
if __name__=='__main__':main()
