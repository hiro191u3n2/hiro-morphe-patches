import java.io.*;
import java.util.*;
import com.android.tools.smali.dexlib2.*;
import com.android.tools.smali.dexlib2.iface.*;
import com.android.tools.smali.dexlib2.iface.instruction.*;
import com.android.tools.smali.dexlib2.iface.reference.*;
public class SchemaAudit {
 static int checks;
 static void check(boolean yes,String why){checks++; if(!yes)throw new AssertionError(why);}
 static Map<String,ClassDef> load(String path,Set<String> wanted)throws Exception{
  Map<String,ClassDef> out=new HashMap<>();
  MultiDexContainer<? extends DexFile> dex=DexFileFactory.loadDexContainer(new File(path),Opcodes.getDefault());
  for(String name:dex.getDexEntryNames())for(ClassDef c:dex.getEntry(name).getDexFile().getClasses())if(wanted.contains(c.getType()))out.put(c.getType(),c);
  return out;
 }
 static Method method(ClassDef c,String name){for(Method m:c.getMethods())if(m.getName().equals(name))return m;throw new AssertionError("Missing method "+c+" "+name);}
 static void field(Map<String,ClassDef> cs,String type,String name,String expect){
  ClassDef c=cs.get(type); check(c!=null,"Missing "+type); check((c.getAccessFlags()&1)==1,"Not public class "+type);
  for(Field f:c.getFields())if(f.getName().equals(name)){check(f.getType().equals(expect),"Type "+f);check((f.getAccessFlags()&9)==1,"Public instance "+f);return;}
  throw new AssertionError("Missing field "+type+name);
 }
 static List<String> strings(Method m){List<String> out=new ArrayList<>(); for(Instruction i:m.getImplementation().getInstructions())if(i instanceof ReferenceInstruction){Reference r=((ReferenceInstruction)i).getReference(); if(r instanceof StringReference)out.add(((StringReference)r).getString());}return out;}
 static Map<Integer,String> rootSwitch(Method m){
  Map<Integer,Instruction> at=new TreeMap<>(); int pos=0; for(Instruction i:m.getImplementation().getInstructions()){at.put(pos,i);pos+=i.getCodeUnits();}
  Instruction sw=at.get(0); check(sw.getOpcode()==Opcode.PACKED_SWITCH,"Root parser switch");
  SwitchPayload payload=(SwitchPayload)at.get(((OffsetInstruction)sw).getCodeOffset());
  Map<Integer,String> out=new TreeMap<>();
  for(SwitchElement e:payload.getSwitchElements()){
   int dest=e.getOffset(); StringBuilder value=new StringBuilder(); Set<Integer> visited=new HashSet<>();
   while(visited.add(dest)){
    Instruction i=at.get(dest);check(i!=null,"Root switch target");
    if(i.getOpcode()==Opcode.RETURN_VOID)break;
    if(i.getOpcode()==Opcode.GOTO||i.getOpcode()==Opcode.GOTO_16||i.getOpcode()==Opcode.GOTO_32){dest+=((OffsetInstruction)i).getCodeOffset();continue;}
    if(i instanceof ReferenceInstruction){Reference r=((ReferenceInstruction)i).getReference(); if(r instanceof FieldReference)value.append("field=").append(((FieldReference)r).getName()).append(';'); else if(r instanceof MethodReference)value.append("call=").append(((MethodReference)r).getName()).append(';');}
    if(i instanceof WideLiteralInstruction)value.append("scalar=").append(((WideLiteralInstruction)i).getWideLiteral()).append(';');
    dest+=i.getCodeUnits();
   }
   out.put(e.getKey(),value.toString());
  }
  return out;
 }
 public static void main(String[] args)throws Exception{
  String[][] pairs={{"Lcift;","Lcige;"},{"Lcifq;","Lcigb;"},{"Lcifs;","Lcigd;"},{"Lcifr;","Lcigc;"},{"Lcier;","Lcifb;"},{"Lchue;","Lchuj;"},{"Lchvx;","Lchwc;"},{"Lchuz;","Lchvf;"},{"Lchyj;","Lchyo;"}};
  Set<String> wanted=new HashSet<>(Arrays.asList("Lchyy;","Lchzd;","Lbksd;","Lbkww;","Lbkwu;","Lbkxb;","Lcncl;"));for(String[] p:pairs)Collections.addAll(wanted,p);
  Map<String,ClassDef> old=load(args[0],wanted), now=load(args[1],wanted);
  for(String[] pair:pairs){List<String> a=strings(method(old.get(pair[0]),"dynamicMethod")),b=strings(method(now.get(pair[1]),"dynamicMethod"));check(a.equals(b),"Proto info/field order "+Arrays.toString(pair));System.out.println("MATCH protobuf message-info and ordered field-name strings: "+pair[0]+" => "+pair[1]+" strings="+a.size());}
  field(now,"Lcige;","c","I");field(now,"Lcige;","f","Lcncl;");
  field(now,"Lcigb;","c","I");field(now,"Lcigb;","d","Ljava/lang/Object;");
  field(now,"Lcigd;","b","Lcncl;");field(now,"Lcigc;","c","Lcifb;");
  field(now,"Lcifb;","b","I");field(now,"Lcifb;","c","Ljava/lang/Object;");
  check(now.get("Lcncl;").getInterfaces().contains("Ljava/util/List;"),"Proto list interface");
  field(now,"Lbkxb;","t","Lbkww;");field(now,"Lbkww;","b","Ljava/lang/String;");field(now,"Lbkww;","c","Lcom/google/common/collect/ImmutableList;");field(now,"Lbkwu;","b","Ljava/lang/String;");
  Method resolver=method(now.get("Lbksd;"),"j");check((resolver.getAccessFlags()&9)==9,"Resolver public static");check(resolver.getReturnType().equals("Lbkww;"),"Resolver return");check(resolver.getParameterTypes().toString().equals("[Lcom/google/common/collect/ImmutableList;, Lbkww;]"),"Resolver params");
  field(now,"Lchuj;","b","I");field(now,"Lchuj;","c","I");field(now,"Lchuj;","d","Lcnaq;");field(now,"Lchuj;","e","I");field(now,"Lchuj;","f","Ljava/lang/String;");
  Map<Integer,String> a=rootSwitch(method(old.get("Lchyy;"),"c")),b=rootSwitch(method(now.get("Lchzd;"),"c"));check(a.equals(b),"CompactLegend field routing");
  for(int id:new int[]{3,9,10,11,12})System.out.println("MATCH CompactLegend field "+id+": "+b.get(id));
  System.out.println("PASS actual APK reflection/protobuf contracts: checks="+checks+"; host fixtures do not establish Android UI behavior");
 }
}
