package app.hiro.mapsback.patches;

import java.io.ByteArrayInputStream;
import java.io.InputStream;
import java.security.MessageDigest;
import java.util.*;
import java.util.function.Supplier;
import kotlin.Pair;
import kotlin.Unit;
import kotlin.jvm.functions.Function1;
import app.morphe.patcher.patch.*;
import app.morphe.patcher.util.proxy.mutableTypes.*;
import com.android.tools.smali.dexlib2.*;
import com.android.tools.smali.dexlib2.builder.*;
import com.android.tools.smali.dexlib2.builder.instruction.*;
import com.android.tools.smali.dexlib2.iface.*;
import com.android.tools.smali.dexlib2.iface.instruction.*;
import com.android.tools.smali.dexlib2.iface.reference.*;
import com.android.tools.smali.dexlib2.immutable.*;
import com.android.tools.smali.dexlib2.immutable.reference.*;
import com.android.tools.smali.dexlib2.writer.io.MemoryDataStore;
import com.android.tools.smali.dexlib2.writer.pool.DexPool;

/**
 * Adds the first (lowest-priority) enabled handler to Maps' own back dispatcher.
 * Later native handlers stay ahead of it because Lamvi.h uses deque.addFirst.
 * Unlike only changing Activity.onBackPressed, this keeps native API 33+ back
 * dispatch enabled at the map root, where Android otherwise backgrounds the task.
 * No listener, lifecycle method, manifest option or process state is replaced.
 */
public final class MapsBackExit2644 {
    private MapsBackExit2644() {}
    public static final String NAME = "戻るで終了して履歴から削除";
    public static final String VERSION = "26.44.06.1006895251";
    public static final String CODE = "1068856906";
    public static final String OWNER = "Lpa;";
    public static final String TARGET = OWNER;
    public static final String TARGET_METHOD = "Lpa;->a()Ljava/lang/Object;";
    public static final String MAIN = "Lcom/google/android/maps/MapsActivity;";
    public static final String CALLBACK = "Lapp/hiro/mapsback/NativeBackFallback;";
    public static final String ACTIVITY = "Landroid/app/Activity;";
    public static final String DISPATCHER = "Laozl;";
    public static final String NATIVE_CALLBACK = "Lpq;";
    public static final String INSTALL = CALLBACK + "->install(Ljava/lang/Object;Laozl;)V";
    public static final String ANCHOR = "Laozl;-><init>(Ljava/lang/Runnable;)V";
    public static final Set<String> PACKAGES = Collections.unmodifiableSet(new LinkedHashSet<String>(Arrays.asList(
            "org.ungoogled.android.apps.maps.microg", "com.google.android.apps.maps")));

    public static final String[] CONTRACTS = {
        TARGET_METHOD,
        "Lnby;->onBackPressed()V",
        "Lpe;->oq()Laozl;",
        ANCHOR,
        "Laozl;->az()Lpt;",
        "Laozl;->aA(Lpq;)V",
        "Laozl;->aC()V",
        "Laozl;->aD(Landroid/window/OnBackInvokedDispatcher;)V",
        "Lpt;-><init>(Laozl;)V",
        "Lpq;-><init>(Z)V",
        "Lpq;->g(Lgez;)Lpp;",
        "Lpp;-><init>(Lpq;Lgez;)V",
        "Lpp;->b()V",
        "Lamvi;->h(Lilx;)V",
        "Limb;->a(I)Lilx;",
        "Lima;->b()V",
        "Limf;-><init>(Landroid/window/OnBackInvokedDispatcher;I)V",
        "Limf;->c(Z)V",
        "Limf;->e(Z)V",
        "Lpu;->a(Lgsd;Lgrt;)V",
        "Lpe;->D(Laozl;)V",
        "Lilx;-><init>(Lgez;Z)V",
        "Lilx;->h()Z"
    };
    // Verified 26.44.06 input only; fixed raw and mutable DEX fingerprints, never learned at patch time.
    public static final String[][] HASHES = {
        {"1ce6c9c8399b6b990244895be3bbd899ec6654c8106cbed212da40e415e494fa"}, // 0 Lpa;->a()Ljava/lang/Object;
        {"2adf973dcf272c7ed27604068f956e47f799540f85be6930772dbb3987e1faac"}, // 1 Lnby;->onBackPressed()V
        {"554a0871fa0cba304ecfccacd8e8a44d89b654055f7ec4ffd07dcfe407753ecb"}, // 2 Lpe;->oq()Laozl;
        {"f512dd508c984e7414cef06e3be0817c3361eef9dd7622e00686fcc7a8ec5735"}, // 3 Laozl;-><init>(Ljava/lang/Runnable;)V
        {"0c8503945901b0e721d739df53e78873e87d17163e900faaecdfa77fcd974de4"}, // 4 Laozl;->az()Lpt;
        {"a518bbd748a6d4d0a43502f63d8985d19ece5a7c4044109ad17b61bdf238cbb2"}, // 5 Laozl;->aA(Lpq;)V
        {"b81aea4e008455a421c85bb8e6a923044ec5b66094650c2776f75a0974c6defb"}, // 6 Laozl;->aC()V
        {"053e22b6005afc0d188918e6c56d6c2aa041c30360a0236d0346a699aaf05fcb"}, // 7 Laozl;->aD(Landroid/window/OnBackInvokedDispatcher;)V
        {"1aa68e7d6e37530276ad0526da009abe29b1cdffa291576c29a67da31267466d"}, // 8 Lpt;-><init>(Laozl;)V
        {"78ac727813e1cdbed0c7643b451e6950c011d9822386a56a7d04ff1f6161d32f"}, // 9 Lpq;-><init>(Z)V
        {"12b2ac40411be6b1bee38177ffd78d65a9ad1e89c6313ec0510ce5d659bb65df"}, // 10 Lpq;->g(Lgez;)Lpp;
        {"fb90b10de0c336ebd89a39ff89ed66e0d423fa106372521d048aed1efca23863"}, // 11 Lpp;-><init>(Lpq;Lgez;)V
        {"593a63aa5df56fa3149bdbd77830395e2bdfa73f6d027722a71acec3fa93e7c2"}, // 12 Lpp;->b()V
        {"0bef17ec7724cadfb118321c2f5f818e7a1258242b38f25f817d802fc54a1ebd"}, // 13 Lamvi;->h(Lilx;)V
        {"387483810791b09fa374199633f9ce503d2b20bc004f6784446afaa0d7279805"}, // 14 Limb;->a(I)Lilx;
        {"e78c1941e2238cf1f7aeefe54d1a65d9daec772f94e2adf146af87088b78c70c"}, // 15 Lima;->b()V
        {"205caec7429955028a67b06a18b811dce8639416f564ab6bb445cfe8831c266f"}, // 16 Limf;-><init>(Landroid/window/OnBackInvokedDispatcher;I)V
        {"50ad4d5a4029532ece89d99d7e4bd666f4d8c1d6ad9cf227c072ea56cf570346"}, // 17 Limf;->c(Z)V
        {"70b8c509e99119097212dfd82550a4bc05d188babace0a767eb12d193f1cfcbc"}, // 18 Limf;->e(Z)V
        {"b489011f4738a30e6ca0447e32fa8e0e2580cde07054ba5c569f822f4bbc893c"}, // 19 Lpu;->a(Lgsd;Lgrt;)V
        {"7e52c5b4ae31e2f9537988753a6dc8008840dc7026732e42e84e105756a374a7"}, // 20 Lpe;->D(Laozl;)V
        {"37b970e83bc3dad5b28f367652017cb1c904d8bc10e54a676b3caa86412a8456"}, // 21 Lilx;-><init>(Lgez;Z)V
        {"3f59d937a88a1e8ee894e192b1d8eaf35683bd25f71d3beb2b36b65811da8be5"}, // 22 Lilx;->h()Z
    };

    public interface Lookup { ClassDef get(String type); }

    public static Set<Pair<String,Set<String>>> compatibility() {
        Set<Pair<String,Set<String>>> result = new LinkedHashSet<Pair<String,Set<String>>>();
        for (String p : PACKAGES) result.add(new Pair<String,Set<String>>(p, Collections.singleton(VERSION)));
        return Collections.unmodifiableSet(result);
    }

    public static void require(boolean condition, String message) {
        if (!condition) throw new IllegalStateException("Maps back exit: " + message);
    }
    public static void validatePackage(String p, String v, String code) {
        require(PACKAGES.contains(p) && VERSION.equals(v) && CODE.equals(code),
                "Requires verified Maps 26.44.06.1006895251 (1068856906)");
    }
    public static String descriptor(MethodReference m) {
        StringBuilder s = new StringBuilder(m.getDefiningClass()).append("->").append(m.getName()).append('(');
        for (CharSequence p : m.getParameterTypes()) s.append(p);
        return s.append(')').append(m.getReturnType()).toString();
    }
    public static String owner(String d) { return d.substring(0, d.indexOf("->")); }
    public static Method find(ClassDef c, String d) {
        require(c != null, "Missing class for " + d);
        Method result = null;
        for (Method m : c.getMethods()) if (d.equals(descriptor(m))) {
            require(result == null, "Ambiguous method " + d); result = m;
        }
        require(result != null, "Missing method " + d); return result;
    }
    public static String fingerprint(Method m) {
        try {
            MethodImplementation b = m.getImplementation();
            require(b != null, "Missing body " + descriptor(m));
            ImmutableMethodImplementation normalized = new ImmutableMethodImplementation(b.getRegisterCount(),
                    b.getInstructions(), b.getTryBlocks(), Collections.emptyList());
            ImmutableMethod method = new ImmutableMethod(m.getDefiningClass(), m.getName(), m.getParameters(), m.getReturnType(),
                    m.getAccessFlags(), m.getAnnotations(), m.getHiddenApiRestrictions(), normalized);
            ImmutableClassDef wrapper = new ImmutableClassDef(m.getDefiningClass(), 1, "Ljava/lang/Object;", Collections.emptyList(),
                    null, Collections.emptySet(), Collections.emptyList(), Collections.singleton(method));
            MemoryDataStore out = new MemoryDataStore();
            try {
                DexPool.writeTo(out, new ImmutableDexFile(Opcodes.forApi(29), Collections.singleton(wrapper)));
                byte[] hash = MessageDigest.getInstance("SHA-256").digest(Arrays.copyOf(out.getBuffer(), out.getSize()));
                StringBuilder result = new StringBuilder();
                for (byte v : hash) result.append(String.format(Locale.ROOT, "%02x", v & 255));
                return result.toString();
            } finally { out.close(); }
        } catch (Exception e) { throw new IllegalStateException("Cannot fingerprint Maps native method", e); }
    }
    public static void validateContract(Method m, int i) {
        require(i >= 0 && i < CONTRACTS.length && HASHES.length == CONTRACTS.length, "Invalid contract table");
        require(CONTRACTS[i].equals(descriptor(m)) && m.getImplementation() != null, "Native declaration changed " + i);
        require(Arrays.asList(HASHES[i]).contains(fingerprint(m)), "Unverified, modified or already patched native body " + CONTRACTS[i]);
    }
    private static void hierarchy(Lookup l, String type, String parent, boolean publicClass) {
        ClassDef c = l.get(type);
        require(c != null && parent.equals(c.getSuperclass()), "Class hierarchy changed " + type);
        if (publicClass) require((c.getAccessFlags() & 1) == 1, "Native class no longer public " + type);
    }
    public static void validateNative(Lookup l) {
        require(l.get(CALLBACK) == null, "Back-exit patch already installed; use an APK without this patch");
        String[] chain = {MAIN, "Lnby;", "Lncm;", "Lnxh;", "Layxf;", "Laykm;", "Leh;", "Lbm;", "Lpe;", "Lcy;", ACTIVITY};
        for (int i = 0; i + 1 < chain.length; i++) hierarchy(l, chain[i], chain[i+1], true);
        hierarchy(l, OWNER, "Ljava/lang/Object;", true);
        hierarchy(l, DISPATCHER, "Ljava/lang/Object;", true);
        hierarchy(l, NATIVE_CALLBACK, "Ljava/lang/Object;", true);
        hierarchy(l, "Lpt;", "Lima;", true);
        hierarchy(l, "Lpp;", "Lilx;", true);
        hierarchy(l, "Limf;", "Lima;", true);
        require((l.get(NATIVE_CALLBACK).getAccessFlags() & (AccessFlags.FINAL.getValue() | AccessFlags.INTERFACE.getValue())) == 0,
                "Native back callback cannot be subclassed");
        for (int i = 0; i < CONTRACTS.length; i++) validateContract(find(l.get(owner(CONTRACTS[i])), CONTRACTS[i]), i);
        require(find(l.get(NATIVE_CALLBACK), "Lpq;->b()V").getAccessFlags() == 1025, "Native back callback virtual contract changed");
        injectionIndex(find(l.get(OWNER), TARGET_METHOD));
    }

    /** The factory has 13 locals and p0=v13 contains the Activity at this constructor. */
    public static int injectionIndex(Method m) {
        require(TARGET_METHOD.equals(descriptor(m)) && m.getAccessFlags() == 17 && m.getImplementation() != null
                && m.getImplementation().getRegisterCount() == 14, "Dispatcher factory declaration changed");
        int index = 0, result = -1;
        for (Instruction in : m.getImplementation().getInstructions()) {
            if (in instanceof ReferenceInstruction) {
                Reference r = ((ReferenceInstruction)in).getReference();
                if (r instanceof MethodReference && ANCHOR.equals(descriptor((MethodReference)r))) {
                    require(result < 0 && in.getOpcode() == Opcode.INVOKE_DIRECT && in instanceof FiveRegisterInstruction,
                            "Dispatcher constructor is absent or ambiguous");
                    FiveRegisterInstruction v = (FiveRegisterInstruction)in;
                    require(v.getRegisterCount() == 2 && v.getRegisterC() == 0 && v.getRegisterD() == 1,
                            "Dispatcher constructor registers changed");
                    result = index + 1;
                }
            }
            index++;
        }
        require(result > 0, "Dispatcher factory constructor missing"); return result;
    }
    public static void apply(MutableClass c) {
        MutableMethod m = (MutableMethod)find(c, TARGET_METHOD);
        validateContract(m, 0);
        int at = injectionIndex(m);
        MutableMethodImplementation body = m.getImplementation();
        body.addInstruction(at, new BuilderInstruction35c(Opcode.INVOKE_STATIC, 2, 13, 0, 0, 0, 0,
                new ImmutableMethodReference(CALLBACK, "install", Arrays.asList("Ljava/lang/Object;", DISPATCHER), "V")));
        body.addInstruction(at + 1, new BuilderInstruction10x(Opcode.NOP));
    }

    private static ImmutableMethod method(String name, List<String> args, String result, int flags, MethodImplementation code) {
        List<ImmutableMethodParameter> parameters = new ArrayList<ImmutableMethodParameter>();
        for (String a : args) parameters.add(new ImmutableMethodParameter(a, Collections.emptySet(), null));
        return new ImmutableMethod(CALLBACK, name, parameters, result, flags, Collections.emptySet(), Collections.emptySet(), code);
    }
    private static BuilderInstruction35c invoke(Opcode opcode, String owner, String name, List<String> args, String result, int... registers) {
        int[] r = new int[5]; require(registers.length <= 5, "Too many invocation registers");
        for (int i=0; i<registers.length; i++) { require(registers[i] >= 0 && registers[i] <= 15, "Invocation register overflow"); r[i] = registers[i]; }
        return new BuilderInstruction35c(opcode, registers.length, r[0], r[1], r[2], r[3], r[4],
                new ImmutableMethodReference(owner, name, args, result));
    }

    /** Exactly one generated native subclass; no dependency on a separately compiled runtime. */
    public static ImmutableClassDef callback() {
        ImmutableFieldReference activity = new ImmutableFieldReference(CALLBACK, "activity", ACTIVITY);
        MethodImplementationBuilder ctor = new MethodImplementationBuilder(3);
        ctor.addInstruction(new BuilderInstruction11n(Opcode.CONST_4, 0, 1));
        ctor.addInstruction(invoke(Opcode.INVOKE_DIRECT, NATIVE_CALLBACK, "<init>", Collections.singletonList("Z"), "V", 1, 0));
        ctor.addInstruction(new BuilderInstruction22c(Opcode.IPUT_OBJECT, 2, 1, activity));
        ctor.addInstruction(new BuilderInstruction10x(Opcode.RETURN_VOID));

        MethodImplementationBuilder back = new MethodImplementationBuilder(2);
        back.addInstruction(new BuilderInstruction22c(Opcode.IGET_OBJECT, 0, 1, activity));
        back.addInstruction(invoke(Opcode.INVOKE_VIRTUAL, ACTIVITY, "finishAndRemoveTask", Collections.emptyList(), "V", 0));
        back.addInstruction(new BuilderInstruction10x(Opcode.RETURN_VOID));

        MethodImplementationBuilder install = new MethodImplementationBuilder(3);
        install.addInstruction(new BuilderInstruction22c(Opcode.INSTANCE_OF, 0, 1, new ImmutableTypeReference(MAIN)));
        install.addInstruction(new BuilderInstruction21t(Opcode.IF_EQZ, 0, install.getLabel("done")));
        install.addInstruction(new BuilderInstruction21c(Opcode.CHECK_CAST, 1, new ImmutableTypeReference(ACTIVITY)));
        install.addInstruction(new BuilderInstruction21c(Opcode.NEW_INSTANCE, 0, new ImmutableTypeReference(CALLBACK)));
        install.addInstruction(invoke(Opcode.INVOKE_DIRECT, CALLBACK, "<init>", Collections.singletonList(ACTIVITY), "V", 0, 1));
        install.addInstruction(invoke(Opcode.INVOKE_VIRTUAL, DISPATCHER, "aA", Collections.singletonList(NATIVE_CALLBACK), "V", 2, 0));
        install.addLabel("done");
        install.addInstruction(new BuilderInstruction10x(Opcode.RETURN_VOID));

        List<ImmutableMethod> methods = Arrays.asList(
                method("<init>", Collections.singletonList(ACTIVITY), "V", 65537, ctor.getMethodImplementation()),
                method("b", Collections.emptyList(), "V", 17, back.getMethodImplementation()),
                method("install", Arrays.asList("Ljava/lang/Object;", DISPATCHER), "V", 9, install.getMethodImplementation()));
        ImmutableField field = new ImmutableField(CALLBACK, "activity", ACTIVITY, 18, null, Collections.emptySet(), Collections.emptySet());
        return new ImmutableClassDef(CALLBACK, 17, NATIVE_CALLBACK, Collections.emptyList(), null, Collections.emptySet(),
                Collections.singleton(field), methods);
    }
    public static byte[] extensionDex() {
        try {
            MemoryDataStore out = new MemoryDataStore();
            try {
                DexPool.writeTo(out, new ImmutableDexFile(Opcodes.forApi(28), Collections.singleton(callback())));
                return Arrays.copyOf(out.getBuffer(), out.getSize());
            } finally { out.close(); }
        } catch (Exception e) { throw new IllegalStateException("Cannot generate Maps native back extension", e); }
    }
}
