#!/usr/bin/env python3
"""Exact-host application checks. All output APKs are unsigned QA fixtures."""
from pathlib import Path
import hashlib,json,os,subprocess,sys,zipfile

ROOT=Path(__file__).resolve().parent
AUDIT=ROOT.parents[1]
JAVA=AUDIT/'diagnostic/java21/jdk-21.0.13+9-jre/bin/java'
HOST=AUDIT/'manager240dev4/patcher-host.jar'
MANAGER=AUDIT/'manager240dev4/morphe-manager-2.4.0-dev.4.apk'
ECJ=AUDIT/'direct_diagnostic/toolchain/ecj-3.46.100.jar'
ORIGINAL=AUDIT/'Berry_original383740_base.apk'
CURRENT=AUDIT.parent/'upload/Berry_Browser-v3.83.93.1-Hiro_Morphe_Patches-v1.0.328.apk'
BUNDLE=ROOT/'Berry_BFCache_Repair_v1.0.3.mpp'
NAMES=['ダブルタップから指を離さず片手ズーム','プレビュー作成を後回しにして表示中タブを優先',
       'ロックフリーMessageQueueを有効化','共有先ブラウザの表示を個別に切替','バックフォワードキャッシュの復帰処理を補正']
QA_NAME='QA only: apply BFCache repair to known modified input'

def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()

def qa_bundle():
    work=ROOT/'qa_harness';work.mkdir(exist_ok=True)
    src=work/'QaOnly.java'
    src.write_text('''import app.morphe.patcher.patch.*;
import app.hiro.berrybfcache.patches.BfCacheRepairPatch;
import kotlin.Unit;
public final class QaOnly {
 public static final BytecodePatch PATCH = PatchKt.bytecodePatch("'''+QA_NAME+'''", "Local JVM test wrapper; never a user deliverable", false, builder -> {
  builder.extendWith(() -> QaOnly.class.getClassLoader().getResourceAsStream(BfCacheRepairPatch.EXTENSION));
  builder.execute(context -> { BfCacheRepairPatch.applyRepair(context); return Unit.INSTANCE; });
  return Unit.INSTANCE;
 });
}
''')
    classes=work/'classes';classes.mkdir(exist_ok=True)
    cp=os.pathsep.join(map(str,[HOST,ROOT/'patch/classes',ROOT/'patch/original_classes']))
    proc=subprocess.run([str(JAVA),'-jar',str(ECJ),'-source','11','-target','11','-cp',cp,'-d',str(classes),str(src)],capture_output=True,text=True)
    (work/'compile.log').write_text(proc.stdout+proc.stderr)
    assert proc.returncode==0,proc.stderr
    out=work/'QA_ONLY_never_deliver.mpp'
    with zipfile.ZipFile(BUNDLE) as z,zipfile.ZipFile(out,'w',zipfile.ZIP_DEFLATED) as w:
        for n in z.namelist():w.writestr(n,z.read(n))
        for p in classes.rglob('*.class'):w.write(p,str(p.relative_to(classes)))
    return out

def run(label,apk,bundle,names,expected_success=True):
    work=ROOT/'validation'/label;work.mkdir(parents=True,exist_ok=True)
    output=work/'validation_unsigned.apk'
    assert not output.exists(),'Use a fresh run label to avoid stale output'
    req={'packageName':'jp.ejimax.berrybrowser','inputFile':str(apk),'outputFile':str(output),
         'mergedApkFile':str(work/'merged.apk'),'temporaryDir':str(work/'temp'),'workspaceDir':str(work/'workspace'),
         'bundles':[{'uid':10000,'patchesFile':str(bundle),'patches':names,'options':{}}],
         'stripUnusedNativeLibs':False,
         'device':{'supportedAbis':['arm64-v8a'],'localeTags':['ja-JP'],'densityDpi':480}}
    request=work/'request.json';request.write_text(json.dumps(req,ensure_ascii=False,indent=2))
    commands=work/'commands.jsonl';commands.write_text(json.dumps({'type':'run','requestFile':str(request)})+'\n')
    eventsfile=work/'events.jsonl'
    command=[str(JAVA),'-Xmx2g','-cp',str(HOST)+os.pathsep+str(MANAGER),
             'app.morphe.manager.patcher.host.HostMainKt',str(commands),str(eventsfile)]
    proc=subprocess.run(command,capture_output=True,text=True)
    (work/'stdout.log').write_text(proc.stdout);(work/'stderr.log').write_text(proc.stderr)
    events=[json.loads(l) for l in eventsfile.read_text().splitlines()]
    finished=[e for e in events if e.get('type')=='finished']
    applied=[e.get('name') for e in events if e.get('type')=='patch']
    success=bool(proc.returncode==0 and finished and finished[-1].get('failure') is None and output.exists())
    report={'label':label,'success':success,'exit_code':proc.returncode,'finished':finished,'applied':applied,
            'input_sha256':sha(apk),'bundle_sha256':sha(bundle),'output_sha256':sha(output) if output.exists() else None,
            'manager_version':'2.4.0-dev.4','patcher_version':'2.2.0-dev.2',
            'host_sha256':sha(HOST),'android_device_tested':False,'signed_or_installed':False}
    (work/'QA_apply.json').write_text(json.dumps(report,ensure_ascii=False,indent=2)+'\n')
    print(json.dumps({'label':label,'success':success,'applied':applied,'output':str(output) if output.exists() else None},ensure_ascii=False),flush=True)
    if success!=expected_success:
        print(eventsfile.read_text()[-10000:]);raise SystemExit(1)
    if expected_success:assert len(applied)==len(names)
    else:assert not output.exists()
    return report

if __name__=='__main__':
    mode=sys.argv[1]
    if mode=='original':run('original383740',ORIGINAL,BUNDLE,NAMES)
    elif mode=='current':run('modified383931_same_repair_only',CURRENT,qa_bundle(),[QA_NAME])
    else:raise SystemExit('expected original or current')
