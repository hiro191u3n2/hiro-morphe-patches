#!/usr/bin/env python3
"""Build the five Maps add-ons from source, then assemble over immutable Hiro373."""
import argparse, hashlib, json, os, subprocess, sys
from pathlib import Path
import zip_helpers as z
from assemble import BASE_SHA, TOOL_PINS
ROOT=Path(__file__).resolve().parent
SDK_SHA=''
CONFIG={
 'category':{'prefixes':['app/hiro/maps/patches/'],'resources':[]},
 'back':{'prefixes':['app/hiro/mapsback/patches/'],'resources':[]},
 'bikes':{'prefixes':['app/hiro/mapsbikes/patches/'],'resources':['extensions/maps_hide_bicycle_marks.mpe','contracts/maps_hide_bicycle_marks_v1.0.0.dex'],'runtime':'extensions/maps_hide_bicycle_marks_2644.mpe','runtime_api':'23'},
 'startup':{'prefixes':['app/hiro/mapsstartup/patches/'],'resources':['extensions/maps_startup_location.mpe']},
 'strict':{'prefixes':['app/hiro/mapsstrict/patches/','app/hiro/mapsstrict2644/patches/'],'resources':['extensions/maps_strict_search.mpe','contracts/maps_strict_search_v1.0.0.dex'],'runtime':'extensions/maps_strict_search2644.mpe','runtime_api':'29'},
}
def main():
 p=argparse.ArgumentParser(description=__doc__)
 for key in ('base','tools','out'):p.add_argument('--'+key,type=Path,required=True)
 p.add_argument('--timestamp',required=True,help='ISO timestamp for output manifests')
 p.add_argument('--skip-assemble',action='store_true')
 a=p.parse_args();a.base=a.base.resolve();a.tools=a.tools.resolve();a.out=a.out.resolve()
 z.require(z.sha(a.base)==BASE_SHA,'Hiro373 baseline hash differs')
 for n,h in TOOL_PINS.items():z.require(z.sha(a.tools/n)==h,'Tool mismatch: '+n)
 pins=json.loads((ROOT/'tool-hashes.json').read_text())
 sdk=a.tools/'morphe-dev19.jar';z.require(z.sha(sdk)==pins['morphe-dev19.jar'],'Exact Patcher 2.4.0-dev.8 is required')
 z.require(not a.out.exists() or not any(a.out.iterdir()),'Use a fresh output directory')
 a.out.mkdir(parents=True,exist_ok=True);work=a.out/'work';work.mkdir()
 def run(cmd,log):
  result=subprocess.run(list(map(str,cmd)),capture_output=True,text=True,timeout=600)
  log.parent.mkdir(parents=True,exist_ok=True);log.write_text(result.stdout+result.stderr)
  z.require(result.returncode==0,str(log)+' failed:\n'+(result.stdout+result.stderr)[-8000:])
 def cp(*paths):return os.pathsep.join(map(str,paths))
 def class_files(folder):return {f.relative_to(folder).as_posix():f.read_bytes() for f in folder.rglob('*.class')}
 run(['java','--version'],work/'java-version.txt')
 z.require('21.0.13' in (work/'java-version.txt').read_text(),'Reproduce with Java 21.0.13')
 run([sys.executable,ROOT/'compile_api.py',sdk,work/'compile-api'],work/'compile-api.log')
 base=z.archive(a.base);spec=[];report={'baseline_sha256':BASE_SHA,'modules':{}}
 ecj=['java','-jar',a.tools/'ecj.jar','-8','-nowarn','-encoding','UTF-8']
 for name,config in CONFIG.items():
  src=ROOT/'modules'/name/'src';m=work/name;m.mkdir();classes=m/'classes';classes.mkdir()
  sources=sorted((src/'patch').rglob('*.java'))
  if (src/'patch2644').exists():sources+=sorted((src/'patch2644').rglob('*.java'))
  run([*ecj,'-cp',cp(work/'compile-api',sdk),'-d',classes,*sources],m/'compile-provider.log')
  fresh=class_files(classes)
  z.require(fresh and all(n.startswith(tuple(config['prefixes'])) for n in fresh),'Foreign or compile-only class in '+name)
  z.write_zip(m/'provider.jar',fresh);(m/'dex').mkdir()
  run(['java','-Xmx1g','-cp',a.tools/'d8.jar','com.android.tools.r8.D8','--release','--min-api','26','--classpath',sdk,'--output',m/'dex',m/'provider.jar'],m/'provider-d8.log')
  data={n:base[n] for n in config['resources']};data.update(fresh);data['classes.dex']=(m/'dex/classes.dex').read_bytes()
  new_resources=[]
  if 'runtime' in config:
   runtime=m/'runtime';runtime.mkdir();runtime_cp=a.tools/'classpath.jar'
   if name=='strict':
    api=m/'runtime-api';api.mkdir()
    run([*ecj,'-d',api,src/'test-host/android/util/Log.java'],m/'compile-runtime-api.log');runtime_cp=api
   run([*ecj,'-cp',runtime_cp,'-d',runtime,*sorted((src/'runtime2644').rglob('*.java'))],m/'compile-runtime.log')
   runtime_classes=class_files(runtime);z.require(all(n.startswith('app/hiro/') for n in runtime_classes),'Runtime API stubs leaked')
   z.write_zip(m/'runtime.jar',runtime_classes);(m/'runtime-dex').mkdir()
   lib=['--lib',a.tools/'classpath.jar'] if name=='bikes' else []
   run(['java','-Xmx1g','-cp',a.tools/'d8.jar','com.android.tools.r8.D8','--release','--min-api',config['runtime_api'],*lib,'--classpath',sdk,'--output',m/'runtime-dex',m/'runtime.jar'],m/'runtime-d8.log')
   data[config['runtime']]=(m/'runtime-dex/classes.dex').read_bytes();new_resources=[config['runtime']]
  data['META-INF/MANIFEST.MF']=z.manifest({'Manifest-Version':'1.0','Name':'Hiro Maps '+name,'Version':'1.1.0','Timestamp':a.timestamp,'Patcher-Version':'2.4.0-dev.8'})
  candidate=a.out/(name+'.mpp');z.write_zip(candidate,data)
  spec.append({'label':name,'candidate':str(candidate),'class_prefixes':config['prefixes'],'resources':new_resources})
  report['modules'][name]={'candidate_sha256':z.sha(candidate),'provider_classes':{n:hashlib.sha256(b).hexdigest() for n,b in sorted(fresh.items())},'resources':{n:hashlib.sha256(data[n]).hexdigest() for n in config['resources']+new_resources}}
 spec_path=a.out/'spec.json';spec_path.write_text(json.dumps(spec,indent=2)+'\n')
 (a.out/'modules-build.json').write_text(json.dumps(report,indent=2)+'\n')
 if not a.skip_assemble:
  run([sys.executable,ROOT/'assemble.py','--base',a.base,'--spec',spec_path,'--tools',a.tools,'--out',a.out/'release','--timestamp',a.timestamp],a.out/'assemble.log')
 print(a.out)
if __name__=='__main__':main()
