#!/usr/bin/env python3
"""Package reviewed sources and QA, excluding APKs and local QA executable bundles."""
from pathlib import Path
import hashlib
import json
import zipfile

ROOT = Path(__file__).resolve().parent
AUDIT = ROOT.parents[1]
WORKSPACE = AUDIT.parent

def read(name):
    return json.loads((ROOT / name).read_text())

build = read('patch/build_report.json')
runtime = read('RUNTIME_BUILD_QA.json')
guard = read('GUARD_QA.json')
old = read('INDEPENDENT_repair_audit_383740.json')
current = read('INDEPENDENT_repair_audit_383931.json')
assert all(x['result'] == 'PASS' for x in [runtime, old, current])
assert guard['pass']
assert read('validation/original383740/QA_apply.json')['success']
assert read('validation/modified383931_same_repair_only/QA_apply.json')['success']
assert hashlib.sha256((ROOT / 'Berry_BFCache_Repair_v1.0.3.mpp').read_bytes()).hexdigest() == build['sha256']
summary = {
    'status': 'VALIDATED_REPAIR_CANDIDATE_DEVICE_CONFIRMATION_REQUIRED',
    'source_name': 'Berry Browser BFCache復帰補正',
    'source_version': '1.0.3',
    'bundle_sha256': build['sha256'],
    'normal_input': 'unmodified jp.ejimax.berrybrowser 3.83.93.1',
    'patches_selected': 5,
    'original_four_providers_and_extensions': 'byte-identical to production v1.3.1',
    'full_bundle_host_apply_actual_original_3_83_74': 'PASS',
    'same_repair_host_apply_actual_modified_3_83_93_1': 'PASS via QA-only wrapper',
    'full_bundle_host_apply_actual_original_3_83_93_1': 'NOT_TESTED_INPUT_UNAVAILABLE',
    'jvm_state_tests': runtime['jvm_test'],
    'embedded_script_tests': runtime['javascript_test'],
    'modified_body_and_reapply_rejection': 'PASS, no APK output',
    'independent_apk_diff': {
        '3.83.74': old['checks'],
        '3.83.93.1': current['checks'],
    },
    'confirmed_defect': 'Native loading state is not completed on BFCache restore; normal onPageFinished is absent',
    'partial_rendering_root_cause_proven': False,
    'physical_device_tested': False,
    'rendering_symptom_fixed_on_device': 'UNCONFIRMED',
    'published': False,
}
(ROOT / 'QA_SUMMARY_v1.0.3.json').write_text(json.dumps(summary, ensure_ascii=False, indent=2) + '\n')

selected = set()
for pattern in ['*.py', '*.txt', '*.json', '*.mpp', 'extensions/*.mpe',
                'patch/src/**/*.java', 'patch/tools/*.java', 'patch/*.py', 'patch/*.json',
                'patch/*contracts.txt', 'runtime_src/**/*.java', 'runtime_stubs/**/*.java',
                'runtime_tests/src/**/*.java', 'runtime_tests/*.js', 'runtime_tests/*.json',
                'runtime_tests/generated/*.js', 'qa_harness/QaOnly.java',
                'validation/*/QA_apply.json', 'validation/*/events.jsonl',
                'validation/*/stdout.log', 'validation/*/stderr.log']:
    selected.update(p for p in ROOT.glob(pattern) if p.is_file())
selected.add(AUDIT / 'Berry_Browser_v1.3.1.mpp')
selected.add(AUDIT / 'direct_diagnostic/compile_stubs/app/morphe/patcher/patch/AppTarget.java')
selected.add(AUDIT / 'current383931/audit_addon_output.py')
for name in ['research_sources/bfcache_official_evidence.json',
             'analysis_app/BFCache_app_path_audit.json',
             'analysis_app/repair_proposal_review.json',
             'analysis_lifecycle/lifecycle_audit.json']:
    selected.add(ROOT.parent / name)
assert all(p.exists() for p in selected)
assert not any(p.suffix == '.apk' or 'QA_ONLY' in p.name or 'guard_fixtures' in p.parts for p in selected)
manifest = {str(p.relative_to(WORKSPACE)): hashlib.sha256(p.read_bytes()).hexdigest() for p in sorted(selected)}
archive = ROOT / 'Berry_BFCache_Repair_v1.0.3_build_QA.zip'
with zipfile.ZipFile(archive, 'w', zipfile.ZIP_DEFLATED) as z:
    for p in sorted(selected):
        z.write(p, str(p.relative_to(WORKSPACE)))
    z.writestr('SOURCE_ARCHIVE_SHA256.json', json.dumps(manifest, ensure_ascii=False, indent=2) + '\n')
with zipfile.ZipFile(archive) as z:
    assert z.testzip() is None
    assert all(hashlib.sha256(z.read(name)).hexdigest() == digest for name, digest in manifest.items())
print(json.dumps({'archive': str(archive), 'bytes': archive.stat().st_size,
                  'entries': len(manifest) + 1, 'sha256': hashlib.sha256(archive.read_bytes()).hexdigest()}, ensure_ascii=False))
