import java.util.ArrayList;
import java.util.List;
public final class cige { public int c = 2; public List<cigb> f = new ArrayList<cigb>(); public String unrelatedPlaceName; }
