from pathlib import Path
import zipfile,struct,sys
src=Path(sys.argv[1]); dst=Path(sys.argv[2])/'app/morphe/patcher/patch/BytecodePatch.class';dst.parent.mkdir(parents=True,exist_ok=True)
b=bytearray(zipfile.ZipFile(src).read('app/morphe/patcher/patch/BytecodePatch.class'));u2=lambda p:struct.unpack_from('>H',b,p)[0];u4=lambda p:struct.unpack_from('>I',b,p)[0]
n=u2(8);p=10;i=1;utf={}
while i<n:
 t=b[p];p+=1
 if t==1: l=u2(p);utf[i]=bytes(b[p+2:p+2+l]).decode('utf-8','replace');p+=2+l
 elif t in (3,4):p+=4
 elif t in (5,6):p+=8;i+=1
 elif t in (7,8,16,19,20):p+=2
 elif t in (9,10,11,12,17,18):p+=4
 elif t==15:p+=3
 else:raise ValueError(t)
 i+=1
p+=6;p+=2+2*u2(p)
for section in range(2):
 count=u2(p);p+=2
 for _ in range(count):
  flags=u2(p);name=utf[u2(p+2)];desc=utf[u2(p+4)];ac=u2(p+6)
  if section==1 and name=='<init>' and 'Ljava/util/Set;Ljava/util/Set;Ljava/util/Set;Ljava/util/function/Supplier;' in desc:
   struct.pack_into('>H',b,p,flags&~0x1000);print('exposecompileonly',desc)
  p+=8
  for __ in range(ac):p+=6+u4(p+2)
dst.write_bytes(b)
