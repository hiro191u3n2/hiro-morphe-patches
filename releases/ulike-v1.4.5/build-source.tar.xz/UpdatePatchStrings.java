import java.nio.file.*;
import org.objectweb.asm.*;
/** Changes only human-readable release text, leaving the patch loader intact. */
public final class UpdatePatchStrings {
 public static void main(String[] a)throws Exception {
  String description="v1.4.5：素材通信の前提となる端末登録・設定初期化を復旧。初期化用の8種類の処理だけを通し、操作履歴・ページ閲覧・広告ID更新等は除外します。解析ログ送信・プッシュ・AppsFlyer停止は維持。端末登録・設定取得に伴う通信は許可されます。24.5MP切替、HEIF専用DCIM/Camera保存、高画質・質感美肌、原本保管、3:4位置と黒背景は維持。未改造ULike 5.6.2（740）へ再パッチ・再インストールが必要です。実機での素材取得成功は未確認です。";
  ClassReader r=new ClassReader(Files.readAllBytes(Path.of(a[0])));ClassWriter w=new ClassWriter(0);int[] n={0};
  r.accept(new ClassVisitor(Opcodes.ASM9,w){
   @Override public MethodVisitor visitMethod(int access,String name,String desc,String sig,String[] exceptions){
    return new MethodVisitor(Opcodes.ASM9,super.visitMethod(access,name,desc,sig,exceptions)){
     @Override public void visitLdcInsn(Object value){if(value instanceof String s&&s.startsWith("v1.4.4：")){value=description;n[0]++;}super.visitLdcInsn(value);}
    };
   }
  },0);
  if(n[0]!=1)throw new IllegalStateException("Expected exactly one version description, got "+n[0]);
  Path p=Path.of(a[1]);Files.createDirectories(p.getParent());Files.write(p,w.toByteArray());
 }
}
