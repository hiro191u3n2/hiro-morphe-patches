public final class cigb { public int c = 4; public Object d; }
