public final class bkwu { public String b; public int d; }
