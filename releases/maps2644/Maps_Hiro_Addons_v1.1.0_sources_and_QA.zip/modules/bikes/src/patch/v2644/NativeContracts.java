package app.hiro.mapsbikes.patches.v2644;

import java.security.MessageDigest;
import java.util.*;
import com.android.tools.smali.dexlib2.Opcode;
import com.android.tools.smali.dexlib2.iface.*;
import com.android.tools.smali.dexlib2.iface.instruction.*;
import com.android.tools.smali.dexlib2.iface.reference.*;

/** Frozen Maps 26.44 contracts, reviewed against the uploaded original APK. */
public final class NativeContracts {
    private NativeContracts() {}
    public static final String SHARED_CALLER =
        "Lcom/google/android/libraries/geo/mapcore/internal/label/jni/SharedLabelerJni;->nativeUpdatePlacedLabels([B)V";
    public static final String CLIENT_CALLER = "Lbkjv;->run()V";
    public static final String ICON_DECODER = "Lbkww;->a(Lcigd;)Lbkww;";

    private static final Set<String> TARGET_HASHES = hashes("ba9e3e1c3c3e107995333e03d658b7a5e53ae386d0c5ebece1c1c80dfa839236");
    private static final Set<String> SHARED_HASHES = hashes("129d82d3475794775458fed517cb8ba57e2e32abb3c326f53df49063c9e3c426");
    private static final Set<String> CLIENT_HASHES = hashes("371a751949b9638a69bad41b8d1b1acaa31ff446b3cbf82e3a3ebb24f4321a94");
    private static final Set<String> DECODER_HASHES = hashes("78cb48ef23ce0274faa433e4ec3a02b9dab553e68d84284a76a9cbda4c6f8d76");

    static Set<String> hashes(String... values) {
        return Collections.unmodifiableSet(new LinkedHashSet<String>(Arrays.asList(values)));
    }
    private static void require(boolean ok, String why) { MapsHideBicycleMarksPatch.require(ok, why); }

    /** Includes every field's name, descriptor and flags plus the class hierarchy. */
    public static String schemaFingerprint(ClassDef type) {
        try {
            require(type != null, "Missing native schema");
            List<String> interfaces = new ArrayList<String>(type.getInterfaces());
            Collections.sort(interfaces);
            List<String> fields = new ArrayList<String>();
            for (Field field : type.getFields())
                fields.add(field.getName() + ":" + field.getType() + ":" + field.getAccessFlags());
            Collections.sort(fields);
            StringBuilder value = new StringBuilder(type.getType()).append('|').append(type.getAccessFlags())
                .append('|').append(type.getSuperclass()).append('|').append(interfaces).append('\n');
            for (String field : fields) value.append(field).append('\n');
            byte[] digest = MessageDigest.getInstance("SHA-256").digest(value.toString().getBytes("UTF-8"));
            StringBuilder result = new StringBuilder();
            for (byte item : digest) result.append(String.format(Locale.ROOT, "%02x", item & 255));
            return result.toString();
        } catch (Exception e) { throw new IllegalStateException("Cannot fingerprint placed-label schema", e); }
    }
    static void schema(MapsHideBicycleMarksPatch.Lookup lookup, String type, String expected) {
        ClassDef found = lookup.get(type);
        require(found != null && expected.equals(schemaFingerprint(found)), "Placed-label schema changed " + type);
    }
    static Method method(MapsHideBicycleMarksPatch.Lookup lookup, String descriptor) {
        return MapsHideBicycleMarksPatch.find(lookup.get(MapsHideBicycleMarksPatch.owner(descriptor)), descriptor);
    }
    static List<Instruction> instructions(Method method) {
        require(method.getImplementation() != null, "Missing native body " + MapsHideBicycleMarksPatch.descriptor(method));
        List<Instruction> result = new ArrayList<Instruction>();
        for (Instruction instruction : method.getImplementation().getInstructions()) result.add(instruction);
        return result;
    }
    static void shape(Method method, int flags, int registers, int count, int units, int tries,
                              Set<String> fingerprints) {
        List<Instruction> body = instructions(method);
        int actualUnits = 0;
        for (Instruction instruction : body) actualUnits += instruction.getCodeUnits();
        require(method.getAccessFlags() == flags && method.getImplementation().getRegisterCount() == registers
            && body.size() == count && actualUnits == units && method.getImplementation().getTryBlocks().size() == tries,
            "Native method layout changed " + MapsHideBicycleMarksPatch.descriptor(method));
        require(fingerprints.contains(MapsHideBicycleMarksPatch.fingerprint(method)),
            "Native method fingerprint changed " + MapsHideBicycleMarksPatch.descriptor(method));
    }
    private static void safeNullCalls(Method caller, int expectedCalls) {
        List<Instruction> body = instructions(caller);
        int calls = 0;
        for (int at = 0; at < body.size(); at++) {
            Instruction instruction = body.get(at);
            if (!(instruction instanceof ReferenceInstruction)) continue;
            Reference reference = ((ReferenceInstruction)instruction).getReference();
            if (!(reference instanceof MethodReference)
                || !MapsHideBicycleMarksPatch.TARGET.equals(MapsHideBicycleMarksPatch.descriptor((MethodReference)reference))) continue;
            calls++;
            require(instruction.getOpcode() == Opcode.INVOKE_VIRTUAL_RANGE, "Factory caller invocation changed");
            require(at + 2 < body.size() && body.get(at + 1).getOpcode() == Opcode.MOVE_RESULT_OBJECT,
                "Factory caller result changed");
            int register = ((OneRegisterInstruction)body.get(at + 1)).getRegisterA();
            int guard = at + 2;
            if (body.get(guard).getOpcode() == Opcode.CHECK_CAST) {
                require(((OneRegisterInstruction)body.get(guard)).getRegisterA() == register,
                    "Factory caller result cast changed");
                guard++;
            }
            require(guard < body.size() && (body.get(guard).getOpcode() == Opcode.IF_EQZ
                || body.get(guard).getOpcode() == Opcode.IF_NEZ)
                && ((OneRegisterInstruction)body.get(guard)).getRegisterA() == register,
                "Factory caller no longer handles null");
        }
        require(calls == expectedCalls, "Factory call count changed " + MapsHideBicycleMarksPatch.descriptor(caller));
    }

    public static void validate(MapsHideBicycleMarksPatch.Lookup lookup) {
        require(lookup != null, "Missing native lookup");
        ClassDef owner = lookup.get(MapsHideBicycleMarksPatch.OWNER);
        require(owner != null && owner.getAccessFlags() == 17 && "Ljava/lang/Object;".equals(owner.getSuperclass())
            && owner.getInterfaces().isEmpty(), "Placed-label factory class changed");
        validateTarget(MapsHideBicycleMarksPatch.find(owner, MapsHideBicycleMarksPatch.TARGET));
        schema(lookup, "Lcige;", "a541dea2ccdf04bfe18b136753608f9fcd56f31e45c9ae245d4a427271d885e9");
        schema(lookup, "Lcigb;", "0009985d1ddc31542cf507d80b9e8d6a193a9c4be9db0a67b84c2539ff5c3503");
        schema(lookup, "Lcigd;", "8840adc30a66634e48e3133453b4dd10c3cd21bb43bccae4353669acfbf1ad82");
        schema(lookup, "Lcigc;", "a15664d3109cfb61d57fe24924d17be5de6568ef9af20a93fa872a63ebac742b");
        schema(lookup, "Lcifb;", "b96d82549f51db9a2e8b4b42ba77acf18b35fcbfa56bf5ffb208d930226bd503");
        Method shared = method(lookup, SHARED_CALLER);
        shape(shared, 2, 28, 592, 1152, 20, SHARED_HASHES);
        safeNullCalls(shared, 2);
        Method client = method(lookup, CLIENT_CALLER);
        shape(client, 17, 18, 807, 1644, 13, CLIENT_HASHES);
        safeNullCalls(client, 1);
        shape(method(lookup, ICON_DECODER), 9, 15, 151, 290, 0, DECODER_HASHES);
    }
    public static void validateTarget(Method method) {
        require(method != null && MapsHideBicycleMarksPatch.TARGET.equals(MapsHideBicycleMarksPatch.descriptor(method)),
            "Unexpected placed-label factory method");
        shape(method, 17, 35, 430, 809, 0, TARGET_HASHES);
        List<Instruction> body = instructions(method);
        for (int index = 0; index < 3; index++) {
            Instruction instruction = body.get(index);
            require(instruction.getOpcode() == Opcode.MOVE_OBJECT_FROM16
                && ((TwoRegisterInstruction)instruction).getRegisterA() == index
                && ((TwoRegisterInstruction)instruction).getRegisterB() == 27 + index,
                "Placed-label entry parameter registers changed");
        }
    }
}
