package app.morphe.patcher.patch;
import java.util.Set;import java.util.function.Supplier;import kotlin.jvm.functions.Function1;
public class BytecodePatch {public BytecodePatch(String a,String b,boolean c,Set d,Set e,Set f,Supplier g,Function1 h,Function1 i){}}
