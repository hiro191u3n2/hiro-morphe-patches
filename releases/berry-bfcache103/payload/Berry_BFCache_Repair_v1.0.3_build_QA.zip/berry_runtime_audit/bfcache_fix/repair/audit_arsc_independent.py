from pathlib import Path
import sys,json,zipfile,hashlib
ROOT=Path('/workspace/scratch/69dbfd2eb346/berry_runtime_audit')
sys.path.insert(0,str(ROOT/'python-deps'))
from loguru import logger
logger.remove()
from androguard.core.axml import ARSCParser,TYPE_STRING
OUT=ROOT/'bfcache_fix/repair'

def snap(path):
 with zipfile.ZipFile(path) as z:a=ARSCParser(z.read('resources.arsc'))
 a._analyse();r={}
 def val(v):return [v.data_type, v.get_data_value() if v.data_type==TYPE_STRING else v.data]
 for rid,configs in a.resource_values.items():
  for conf,e in configs.items():
   key=hex(rid)+'|'+str(conf._get_tuple())
   value=[e.get_value(),e.flags&7]
   if e.is_complex():value+=['complex',e.item.id_parent,sorted([[k,val(v)] for k,v in e.item.items],key=lambda x:x[0])]
   elif e.is_compact():value+=['simple',[e.datatype,e.parent.stringpool_main.getString(e.data) if e.datatype==TYPE_STRING else e.data]]
   else:value+=['simple',val(e.key)]
   r[key]=value
 return r

a=snap(ROOT/'original_diagnostic101/production/validation_unsigned.apk');b=snap(OUT/'validation/original383740/validation_unsigned.apk')
report={'baseline_entries':len(a),'output_entries':len(b),'added':{k:b[k] for k in b.keys()-a.keys()},'removed':{k:a[k] for k in a.keys()-b.keys()},'changed':{k:[a[k],b[k]] for k in a.keys()&b.keys() if a[k]!=b[k]}}
report['result']='PASS_SEMANTIC' if not any(report[k] for k in ['added','removed','changed']) else 'REVIEW_REQUIRED'
(OUT/'INDEPENDENT_repair_audit_arsc383740.json').write_text(json.dumps(report,ensure_ascii=False,indent=2)+'\n')
print(json.dumps(report,ensure_ascii=False,indent=2)[:10000])
