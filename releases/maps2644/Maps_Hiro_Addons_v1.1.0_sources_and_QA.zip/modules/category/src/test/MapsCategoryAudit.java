import java.io.*;
import java.util.*;
import java.util.zip.*;
import app.hiro.maps.patches.MapsCategoryRowPatch;
import app.morphe.patcher.util.proxy.mutableTypes.MutableClass;
import app.morphe.patcher.util.proxy.mutableTypes.MutableMethod;
import com.android.tools.smali.dexlib2.*;
import com.android.tools.smali.dexlib2.builder.*;
import com.android.tools.smali.dexlib2.builder.instruction.*;
import com.android.tools.smali.dexlib2.iface.*;
import com.android.tools.smali.dexlib2.iface.instruction.*;
import com.android.tools.smali.dexlib2.iface.reference.*;
import com.android.tools.smali.dexlib2.immutable.*;
import com.android.tools.smali.dexlib2.writer.io.MemoryDataStore;
import com.android.tools.smali.dexlib2.writer.pool.DexPool;

/** Scope and compatibility audit; this is not a physical Android UI test. */
public final class MapsCategoryAudit {
    private static final String LOADER = "Lapp/hiro/maps/patches/";
    private static final String PATCH = LOADER + "MapsCategoryRowPatch;";
    private static String OWNER, WRAPPER, RESULT;
    private static Set<String> DIRECT, WRAPPERS;
    private static final String TARGET = "a()Landroid/view/View;";
    private static int assertions;
    private static void check(boolean ok, String message) {
        assertions++; if (!ok) throw new AssertionError(message);
    }
    private static Map<String,ClassDef> read(String path) throws Exception {
        Map<String,ClassDef> classes = new TreeMap<>();
        MultiDexContainer<? extends DexFile> dex = DexFileFactory.loadDexContainer(new File(path), Opcodes.getDefault());
        for (String name : dex.getDexEntryNames()) for (ClassDef c : dex.getEntry(name).getDexFile().getClasses())
            check(classes.put(c.getType(), c) == null, "duplicate class " + c.getType());
        return classes;
    }
    private static String signature(MethodReference m) {
        StringBuilder s = new StringBuilder(m.getName()).append('(');
        for (CharSequence p : m.getParameterTypes()) s.append(p);
        return s.append(')').append(m.getReturnType()).toString();
    }
    private static Method method(ClassDef c, String sig) {
        check(c != null, "class missing"); Method result = null;
        for (Method m : c.getMethods()) if (sig.equals(signature(m))) {
            check(result == null, "duplicate method " + sig); result = m;
        }
        check(result != null, "method missing " + c.getType() + sig); return result;
    }
    private static byte[] canonical(ClassDef c) throws Exception {
        MemoryDataStore store = new MemoryDataStore();
        try {
            DexPool.writeTo(store, new ImmutableDexFile(Opcodes.getDefault(), Collections.singleton(c)));
            return Arrays.copyOf(store.getBuffer(), store.getSize());
        } finally { store.close(); }
    }
    private static byte[] canonical(Method m) throws Exception {
        return canonical(new ImmutableClassDef(m.getDefiningClass(), 1, "Ljava/lang/Object;", Collections.emptyList(),
            null, Collections.emptySet(), Collections.emptyList(), Collections.singleton(m)));
    }
    private static Method copy(Method m, MethodImplementation body) {
        return new ImmutableMethod(m.getDefiningClass(), m.getName(), m.getParameters(), m.getReturnType(),
            m.getAccessFlags(), m.getAnnotations(), m.getHiddenApiRestrictions(), body);
    }
    private static List<Instruction> instructions(Method m) {
        List<Instruction> list = new ArrayList<>();
        if (m.getImplementation() != null) for (Instruction i : m.getImplementation().getInstructions()) list.add(i);
        return list;
    }
    private static MethodReference called(Instruction i) {
        if (!(i instanceof ReferenceInstruction)) return null;
        Reference r = ((ReferenceInstruction)i).getReference();
        return r instanceof MethodReference ? (MethodReference)r : null;
    }
    private static void rejected(Runnable action, String message) {
        boolean rejected = false;
        try { action.run(); } catch (IllegalStateException expected) { rejected = true; }
        check(rejected, message);
    }
    /** Remove the one allowed new instruction, then prove the complete getter is unchanged. */
    private static void auditGetter(Method before, Method after) throws Exception {
        check(before.getAccessFlags() == after.getAccessFlags(), "getter flags changed");
        List<Instruction> old = instructions(before), changed = instructions(after);
        check(changed.size() == old.size() + 1, "expected exactly one additional instruction");
        int insertion = changed.size() - 2;
        Instruction injected = changed.get(insertion);
        check(injected.getOpcode() == Opcode.CONST_4 && injected instanceof OneRegisterInstruction
            && ((OneRegisterInstruction)injected).getRegisterA() == 1
            && ((NarrowLiteralInstruction)injected).getNarrowLiteral() == 0,
            "new instruction must replace returned view with null");
        check(changed.get(insertion + 1).getOpcode() == Opcode.RETURN_OBJECT
            && ((OneRegisterInstruction)changed.get(insertion + 1)).getRegisterA() == 1,
            "null must be returned immediately");
        check(old.get(old.size() - 2).getOpcode() == Opcode.MOVE_RESULT_OBJECT, "original final result missing");
        MethodReference result = called(old.get(old.size() - 3));
        check(result != null && RESULT.equals(result.getDefiningClass()) && TARGET.equals(signature(result)),
            "native view result getter anchor differs");
        MutableMethodImplementation restored = new MutableMethodImplementation(after.getImplementation());
        restored.removeInstruction(insertion);
        Method normalizedBefore = copy(before, new MutableMethodImplementation(before.getImplementation()));
        check(Arrays.equals(canonical(normalizedBefore), canonical(copy(after, restored))),
            "native getter differs beyond the single null override");
    }
    private static void auditCallers(Map<String,ClassDef> classes) {
        Set<String> direct = new TreeSet<>(), wrappers = new TreeSet<>();
        for (ClassDef c : classes.values()) for (Method m : c.getMethods()) {
            List<Instruction> ins = instructions(m);
            for (int n = 0; n < ins.size(); n++) {
                MethodReference ref = called(ins.get(n));
                if (ref == null || !TARGET.equals(signature(ref))) continue;
                boolean getter = OWNER.equals(ref.getDefiningClass()), wrapper = WRAPPER.equals(ref.getDefiningClass());
                if (!getter && !wrapper) continue;
                (getter ? direct : wrappers).add(c.getType());
                check(n + 2 < ins.size() && ins.get(n + 1).getOpcode() == Opcode.MOVE_RESULT_OBJECT,
                    "row getter result shape changed: " + c.getType());
                int reg = ((OneRegisterInstruction)ins.get(n + 1)).getRegisterA();
                if (getter && WRAPPER.equals(c.getType())) {
                    check(ins.get(n + 2).getOpcode() == Opcode.RETURN_OBJECT
                        && ((OneRegisterInstruction)ins.get(n + 2)).getRegisterA() == reg, "wrapper no longer forwards optional view");
                } else {
                    // Two Kotlin callers jump over an alternate null assignment before the check.
                    int next = n + 2;
                    if (ins.get(next) instanceof OffsetInstruction && (ins.get(next).getOpcode() == Opcode.GOTO
                        || ins.get(next).getOpcode() == Opcode.GOTO_16 || ins.get(next).getOpcode() == Opcode.GOTO_32)) {
                        int dest = address(ins, next) + ((OffsetInstruction)ins.get(next)).getCodeOffset();
                        next = indexAt(ins, dest);
                    }
                    check(next >= 0 && ins.get(next).getOpcode() == Opcode.IF_EQZ
                        && ((OneRegisterInstruction)ins.get(next)).getRegisterA() == reg,
                        "caller does not accept null row: " + c.getType() + signature(m));
                }
            }
        }
        check(direct.equals(DIRECT), "unexpected direct row consumer");
        check(wrappers.equals(WRAPPERS),
            "unexpected forwarded row consumer");
    }
    private static int address(List<Instruction> ins, int index) {
        int pc = 0; for (int i = 0; i < index; i++) pc += ins.get(i).getCodeUnits(); return pc;
    }
    private static int indexAt(List<Instruction> ins, int wanted) {
        int pc = 0; for (int i = 0; i < ins.size(); i++) { if (pc == wanted) return i; pc += ins.get(i).getCodeUnits(); } return -1;
    }
    private static boolean dexOrSignature(String name) {
        return name.matches("classes(?:[0-9]+)?\\.dex") || name.matches("(?i)META-INF/(?:MANIFEST\\.MF|[^/]+\\.(?:SF|RSA|DSA|EC))");
    }
    private static int auditResources(String original, String patched) throws Exception {
        int count = 0;
        try (ZipFile old = new ZipFile(original); ZipFile out = new ZipFile(patched)) {
            Set<String> expected = new TreeSet<>(), actual = new TreeSet<>();
            Enumeration<? extends ZipEntry> entries = old.entries();
            while (entries.hasMoreElements()) {
                ZipEntry e = entries.nextElement(); if (e.isDirectory() || dexOrSignature(e.getName())) continue;
                expected.add(e.getName()); ZipEntry after = out.getEntry(e.getName());
                check(after != null && e.getSize() == after.getSize(), "resource missing/resized: " + e.getName());
                try (InputStream a = old.getInputStream(e); InputStream b = out.getInputStream(after)) {
                    byte[] aa = new byte[65536], bb = new byte[65536];
                    while (true) {
                        int ac = a.readNBytes(aa, 0, aa.length), bc = b.readNBytes(bb, 0, bb.length);
                        check(ac == bc && Arrays.equals(Arrays.copyOf(aa, ac), Arrays.copyOf(bb, bc)), "resource bytes changed: " + e.getName());
                        if (ac == 0) break;
                    }
                }
                count++;
            }
            entries = out.entries(); while (entries.hasMoreElements()) {
                ZipEntry e = entries.nextElement(); if (!e.isDirectory() && !dexOrSignature(e.getName())) actual.add(e.getName());
            }
            check(actual.equals(expected), "unexpected added non-DEX entries");
        }
        return count;
    }
    private static void auditApp(String original, String patched) throws Exception {
        Map<String,ClassDef> old = read(original), out = read(patched);
        check(old.keySet().equals(out.keySet()), "APK class inventory changed");
        auditCallers(old); int preserved = 0;
        for (ClassDef before : old.values()) {
            ClassDef after = out.get(before.getType());
            if (!OWNER.equals(before.getType())) {
                check(Arrays.equals(canonical(before), canonical(after)), "unrelated class changed: " + before.getType()); preserved++;
            } else {
                Method originalGetter = method(before, TARGET), patchedGetter = method(after, TARGET);
                auditGetter(originalGetter, patchedGetter);
                // Morphe materializes all methods in this one mutable class, normalizing debug locations.
                List<Method> expectedMethods = new ArrayList<>();
                for (Method m : before.getMethods()) expectedMethods.add(TARGET.equals(signature(m)) ? patchedGetter
                    : copy(m, m.getImplementation() == null ? null : new MutableMethodImplementation(m.getImplementation())));
                ClassDef expected = new ImmutableClassDef(before.getType(), before.getAccessFlags(), before.getSuperclass(),
                    before.getInterfaces(), before.getSourceFile(), before.getAnnotations(), before.getFields(), expectedMethods);
                check(Arrays.equals(canonical(expected), canonical(after)), "target class changed outside getter");
            }
        }
        int resources = auditResources(original, patched);
        System.out.println("PASS APK audit: unchanged classes=" + preserved + "; modified getters=1; added instructions=1; unchanged resources="
            + resources + "; null-safe consumers=5 plus forwarding wrapper; assertions=" + assertions + "; physical Android UI not tested.");
    }
    public static void main(String[] args) throws Exception {
        if(args.length != 3) throw new IllegalArgumentException("2636|2644 ORIGINAL PATCHED");
        if("2636".equals(args[0])) {
            OWNER="Lafhc;"; WRAPPER="Lafhk;"; RESULT="Lbzok;";
            DIRECT=new TreeSet<>(Arrays.asList("Lafgr;","Lafhk;"));
            WRAPPERS=new TreeSet<>(Arrays.asList("Laqjx;","Laeos;","Lafyi;","Lajwr;"));
        } else if("2644".equals(args[0])) {
            OWNER="Lafyb;"; WRAPPER="Lafyh;"; RESULT="Lbvgo;";
            DIRECT=new TreeSet<>(Arrays.asList("Lafxp;","Lafyh;"));
            WRAPPERS=new TreeSet<>(Arrays.asList("Lafbq;","Lagpo;","Lakqb;","Larcf;"));
        } else throw new IllegalArgumentException("Unknown version");
        auditApp(args[1],args[2]);
    }
}
