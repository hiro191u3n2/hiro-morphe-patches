.class public Lcom/ss/android/common/applog/AppLog;
.super Ljava/lang/Object;

.method public enqueue(Lcom/ss/android/common/applog/AppLog$ActionQueueItem;)V
    .locals 3

    # Restore only bootstrap/configuration actions. Drop event/telemetry actions.
    if-eqz p1, :hiro_drop
    iget-object v0, p1, Lcom/ss/android/common/applog/AppLog$ActionQueueItem;->type:Lcom/ss/android/common/applog/AppLog$ActionQueueType;
    sget-object v1, Lcom/ss/android/common/applog/AppLog$ActionQueueType;->CONFIG_UPDATE:Lcom/ss/android/common/applog/AppLog$ActionQueueType;
    if-eq v0, v1, :hiro_allowed
    sget-object v1, Lcom/ss/android/common/applog/AppLog$ActionQueueType;->DEVICE_ID_UPDATE:Lcom/ss/android/common/applog/AppLog$ActionQueueType;
    if-eq v0, v1, :hiro_allowed
    sget-object v1, Lcom/ss/android/common/applog/AppLog$ActionQueueType;->UA_UPDATE:Lcom/ss/android/common/applog/AppLog$ActionQueueType;
    if-eq v0, v1, :hiro_allowed
    sget-object v1, Lcom/ss/android/common/applog/AppLog$ActionQueueType;->CUSTOMER_HEADER_UPDATE:Lcom/ss/android/common/applog/AppLog$ActionQueueType;
    if-eq v0, v1, :hiro_allowed
    sget-object v1, Lcom/ss/android/common/applog/AppLog$ActionQueueType;->UPDATE_APP_LANGUAGE_REGION:Lcom/ss/android/common/applog/AppLog$ActionQueueType;
    if-eq v0, v1, :hiro_allowed
    sget-object v1, Lcom/ss/android/common/applog/AppLog$ActionQueueType;->UPDATE_DEVICE_INFO:Lcom/ss/android/common/applog/AppLog$ActionQueueType;
    if-eq v0, v1, :hiro_allowed
    sget-object v1, Lcom/ss/android/common/applog/AppLog$ActionQueueType;->CLEAR_WHEN_SWITCH_CHILD_MODE:Lcom/ss/android/common/applog/AppLog$ActionQueueType;
    if-eq v0, v1, :hiro_allowed
    sget-object v1, Lcom/ss/android/common/applog/AppLog$ActionQueueType;->RESET_WHEN_SWITCH_CHILD_MODE:Lcom/ss/android/common/applog/AppLog$ActionQueueType;
    if-eq v0, v1, :hiro_allowed
    :hiro_drop
    return-void
    :hiro_allowed

    if-nez p1, :cond_0

    return-void

    .line 1
    :cond_0
    iget-object v0, p0, Lcom/ss/android/common/applog/AppLog;->mQueue:Ljava/util/LinkedList;

    monitor-enter v0

    .line 2
    :try_start_0
    sget-boolean v1, Lcom/ss/android/common/applog/AppLog;->sStopped:Z

    if-eqz v1, :cond_1

    .line 3
    sget-object v1, Li/f/d/a/b$c;->f_stop:Li/f/d/a/b$c;

    invoke-direct {p0, p1, v1}, Lcom/ss/android/common/applog/AppLog;->monitorActionQueue(Lcom/ss/android/common/applog/AppLog$ActionQueueItem;Li/f/d/a/b$c;)V

    .line 4
    monitor-exit v0

    return-void

    .line 5
    :cond_1
    iget-object v1, p0, Lcom/ss/android/common/applog/AppLog;->mQueue:Ljava/util/LinkedList;

    invoke-virtual {v1}, Ljava/util/LinkedList;->size()I

    move-result v1

    const/16 v2, 0x7d0

    if-lt v1, v2, :cond_2

    .line 6
    iget-object v1, p0, Lcom/ss/android/common/applog/AppLog;->mQueue:Ljava/util/LinkedList;

    invoke-virtual {v1}, Ljava/util/LinkedList;->poll()Ljava/lang/Object;

    move-result-object v1

    check-cast v1, Lcom/ss/android/common/applog/AppLog$ActionQueueItem;

    .line 7
    sget-object v2, Li/f/d/a/b$c;->f_overflow:Li/f/d/a/b$c;

    invoke-direct {p0, v1, v2}, Lcom/ss/android/common/applog/AppLog;->monitorActionQueue(Lcom/ss/android/common/applog/AppLog$ActionQueueItem;Li/f/d/a/b$c;)V

    .line 8
    :cond_2
    iget-object v1, p0, Lcom/ss/android/common/applog/AppLog;->mQueue:Ljava/util/LinkedList;

    invoke-virtual {v1, p1}, Ljava/util/LinkedList;->add(Ljava/lang/Object;)Z

    .line 9
    iget-object p1, p0, Lcom/ss/android/common/applog/AppLog;->mQueue:Ljava/util/LinkedList;

    invoke-virtual {p1}, Ljava/lang/Object;->notify()V

    .line 10
    monitor-exit v0

    return-void

    :catchall_0
    move-exception p1

    monitor-exit v0
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    throw p1
.end method
