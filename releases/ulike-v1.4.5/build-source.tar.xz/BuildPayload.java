import java.nio.file.*;
import java.util.*;
import com.android.tools.smali.smali.*;
import com.android.tools.smali.dexlib2.*;
import com.android.tools.smali.dexlib2.iface.*;
import com.android.tools.smali.dexlib2.immutable.*;
import com.android.tools.smali.dexlib2.formatter.DexFormatter;
import com.android.tools.smali.dexlib2.writer.pool.DexPool;
import com.android.tools.smali.dexlib2.writer.io.FileDataStore;
import app.hiro.ulike.patches.MethodContract;
/** Replaces exactly two payload methods; leaves all other contracts and bytecode intact. */
public final class BuildPayload {
 static String id(Method m){return DexFormatter.INSTANCE.getMethodDescriptor(m);}
 static void require(boolean b,String s){if(!b)throw new IllegalStateException(s);}
 public static void main(String[] a)throws Exception {
  if(a.length!=3)throw new IllegalArgumentException("old-patch source-dir build-dir");
  Path old=Path.of(a[0]),src=Path.of(a[1]),out=Path.of(a[2]);Files.createDirectories(out);
  SmaliOptions opts=new SmaliOptions();opts.apiLevel=26;opts.jobs=1;opts.outputDexFile=out.resolve("replacement.dex").toString();
  require(Smali.assemble(opts,src.resolve("smali").toString()),"Smali failed");
  var replacement=DexFileFactory.loadDexFile(opts.outputDexFile,Opcodes.forApi(26));
  var previous=DexFileFactory.loadDexFile(old.resolve("ulike/methods.dex").toFile(),Opcodes.forApi(26));
  TreeMap<String,Method> newer=new TreeMap<>();for(ClassDef c:replacement.getClasses())for(Method m:c.getMethods())newer.put(id(m),m);
  require(newer.size()==2,"Exactly two changes required");
  String run="Lcom/ss/android/common/applog/AppLog$ActionReaper;->run()V";
  String queue="Lcom/ss/android/common/applog/AppLog;->enqueue(Lcom/ss/android/common/applog/AppLog$ActionQueueItem;)V";
  require(newer.keySet().equals(Set.of(run,queue)),"Unexpected targets");
  List<String> tsv=new ArrayList<>();int changes=0;
  for(String line:Files.readAllLines(old.resolve("ulike/methods.tsv"))) {
   String[] s=line.split("\t");require(s.length==3,"Invalid contract");
   if(newer.containsKey(s[0])){s[2]=MethodContract.sha256(newer.get(s[0]));if(s[0].equals(run))require(s[1].equals(s[2]),"ActionReaper must be original exact method");changes++;}
   tsv.add(String.join("\t",s));
  }
  require(changes==2,"Missing contract");Files.write(out.resolve("methods.tsv"),tsv);
  DexPool pool=new DexPool(previous.getOpcodes());int edited=0;
  for(ClassDef c:previous.getClasses()){
   List<Method> methods=new ArrayList<>();
   for(Method m:c.getMethods()){
    Method n=newer.get(id(m));if(n==null){methods.add(m);continue;}
    methods.add(new ImmutableMethod(m.getDefiningClass(),m.getName(),m.getParameters(),m.getReturnType(),m.getAccessFlags(),m.getAnnotations(),m.getHiddenApiRestrictions(),n.getImplementation()));edited++;
   }
   pool.internClass(new ImmutableClassDef(c.getType(),c.getAccessFlags(),c.getSuperclass(),c.getInterfaces(),c.getSourceFile(),c.getAnnotations(),c.getFields(),methods));
  }
  require(edited==2,"Missing payload method");
  FileDataStore store=new FileDataStore(out.resolve("methods.dex").toFile());try{pool.writeTo(store);}finally{store.close();}
  var check=DexFileFactory.loadDexFile(out.resolve("methods.dex").toFile(),Opcodes.forApi(26));
  Map<String,String> hashes=new TreeMap<>();for(ClassDef c:check.getClasses())for(Method m:c.getMethods())hashes.put(id(m),MethodContract.sha256(m));
  for(String line:tsv){String[] s=line.split("\t");require(s[2].equals(hashes.remove(s[0])),"Written payload mismatch: "+s[0]);}
  require(hashes.isEmpty(),"Unexpected methods");System.out.println("Verified "+tsv.size()+" method contracts; exactly two changed.");
 }
}
