# Maps back-exit 26.44 port

Provider: `app.hiro.mapsback.patches.MapsBackExitPatch`. There is one visible patch; the two exact APK versions dispatch through the pre-mutation guard. Legacy native hash allowlists and runtime bytecode stay unchanged. `MapsBackExit2644` contains the independently verified current contract and no visible patch.

The context-free extension supplier initially provides the legacy callback. On 26.44, after its 23 native contracts pass, `portCallback` checks that the generated callback was not altered, then rewrites its superclass and all three methods to the exact current callback. The output contains only one callback and no unresolved legacy native base.

| Contract | 26.36 | 26.44 |
| --- | --- | --- |
| Maps back override | `Lnce.onBackPressed` | `Lnby.onBackPressed` |
| Dispatcher getter | `Lpw.nQ` | `Lpe.oq` |
| Lazy dispatcher factory | `Lps.a`, Activity v12 | `Lpa.a`, Activity v13 |
| Dispatcher | `Lamet` | `Laozl` |
| Native callback base | `Lqi` | `Lpq` |
| Callback registration | `Lamet.at` | `Laozl.aA` |
| Native handler | `Lqh : Lijz` | `Lpp : Lilx` |
| Registration engine | `Lamee.h` | `Lamvi.h` |
| First enabled selection | `Likd.a` | `Limb.a` |
| Android back bridge | `Likh` | `Limf` |

The factory installs the fallback immediately after constructing the dispatcher and before Android API33 setup. Both versions register with native deque `addFirst`, so later native handlers keep priority. Host instruction tests execute the real generated DEX and APK methods: detail/dialog callbacks win, disabled handlers are skipped, and only the root callback calls `Activity.finishAndRemoveTask`.

## Verification

Both original APKs pass package/version/code validation, all 23 fingerprints, deliberate contract corruption rejection, duplicate application rejection without partial mutation, callback verification and 9 behavior scenarios. Both single-patch APKs build under Patcher2.4.0-dev.8. Full APK scope audits preserve all non-target native classes and non-DEX/signature resources. On-device Android UI/Recents behavior is not claimed.

Build uses ECJ Java8 with the compile-only `BytecodePatch` legacy-constructor visibility shim first on the compiler classpath, then the exact Patcher2.4.0-dev.8 jar. The shim is not included. D8 compiles only the provider classes. `MapsBackAudit` targets26.36 and `MapsBack2644Audit` targets26.44; supported commands are `fingerprints APK`, `guards APK`, `audit ORIGINAL PATCHED`.

Root combined assembly replaces the entire `app/hiro/mapsback/patches/` JVM class prefix with the candidate MPP entries and regenerates provider DEX. There are no external resources to merge. Do not reuse the historical `build.py` for this port; it documents the prior pinned26.36-only release.
