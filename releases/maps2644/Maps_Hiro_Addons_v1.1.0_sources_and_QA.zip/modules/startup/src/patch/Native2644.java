package app.hiro.mapsstartup.patches;

import java.io.InputStream;
import java.security.MessageDigest;
import java.util.*;
import java.util.function.Supplier;
import kotlin.Pair;
import kotlin.Unit;
import kotlin.jvm.functions.Function1;
import app.morphe.patcher.extensions.InstructionExtensions;
import app.morphe.patcher.patch.*;
import app.morphe.patcher.util.proxy.mutableTypes.*;
import com.android.tools.smali.dexlib2.*;
import com.android.tools.smali.dexlib2.builder.*;
import com.android.tools.smali.dexlib2.builder.instruction.*;
import com.android.tools.smali.dexlib2.iface.*;
import com.android.tools.smali.dexlib2.iface.reference.*;
import com.android.tools.smali.dexlib2.immutable.*;
import com.android.tools.smali.dexlib2.immutable.reference.*;
import com.android.tools.smali.dexlib2.writer.io.MemoryDataStore;
import com.android.tools.smali.dexlib2.writer.pool.DexPool;

/** Startup-only coordination of the verified, idempotent native recenter operation. */
public final class Native2644 {
    private Native2644() {}
    public static final String NAME = "起動時に現在地を表示";
    public static final String VERSION = "26.44.06.1006895251";
    public static final String CODE = "1068856906";
    public static final String OWNER = "Lnby;";
    public static final String MAIN = "Lcom/google/android/maps/MapsActivity;";
    public static final String LAYOUT = "Lcom/google/android/apps/gmm/base/layout/MainLayout;";
    public static final String RUNTIME = "Lapp/hiro/mapsstartup/StartupLocation;";
    public static final String HOST = "Lapp/hiro/mapsstartup/LocationHost;";
    public static final String BRIDGE = "hiroTryCurrentLocation";
    public static final String EXTENSION = "/extensions/maps_startup_location.mpe";
    public static final Set<String> PACKAGES = Collections.unmodifiableSet(new LinkedHashSet<String>(Arrays.asList(
        "org.ungoogled.android.apps.maps.microg", "com.google.android.apps.maps")));

    // One non-clobbering invoke plus one alignment NOP at each entry.
    // Four code units preserve every existing switch/array payload's alignment.
    public static final String[] HOOK_NAMES = {
        "onCreate", "onNewIntent", "onResume", "onPause", "onStop", "onStart", "onDestroy", "dispatchTouchEvent"
    };
    public static final String[] HELPER_NAMES = {
        "onCreate", "onNewIntent", "onResume", "onPause", "onStop", "onStart", "onDestroy", "onTouch"
    };
    public static final String[] HOOK_ARGUMENTS = {
        "Landroid/os/Bundle;", "Landroid/content/Intent;", "", "", "", "", "", "Landroid/view/MotionEvent;"
    };
    public static final int[] HOOK_FLAGS = {17, 20, 20, 20, 20, 20, 20, 17};

    /** Complete contracts include fix copying, direct camera control and camera acknowledgement. */
    public static final String[] CONTRACTS = {
        "Lnby;->onCreate(Landroid/os/Bundle;)V",
        "Lnby;->onNewIntent(Landroid/content/Intent;)V",
        "Lnby;->onResume()V",
        "Lnby;->onPause()V",
        "Lnby;->onStop()V",
        "Lnby;->onStart()V",
        "Lnby;->onDestroy()V",
        "Lnby;->dispatchTouchEvent(Landroid/view/MotionEvent;)Z",
        "Lamtt;->f()V",
        "Lamtt;->g()V",
        "Lamtt;->h()Z",
        "Laiti;->K()Z",
        "Lamus;->b()Lbkzw;",
        "Lamvb;->I(Lbjpk;)Z",
        "Lamxk;->e()Z",
        "Lamvb;->h()Lamxi;",
        "Lamxi;-><clinit>()V",
        "Lbkzw;-><clinit>()V",
        "Lamtr;->a(Lamum;)V",
        "Lcom/google/android/maps/MapsActivity;-><init>()V",
        "Loyw;-><init>(Landroid/app/Activity;Lorg;Laylx;Layue;Lajcc;Lbgdx;Lbhfu;Lbevw;Ljava/util/concurrent/Executor;Lbwgj;Lcqvj;Lnxn;Lcqvj;)V",
        "Lamus;->l(Lbkct;Z)V",
        "Lamus;->j(Lbkzw;Lbkct;Z)V",
        "Lamus;->a()Lbkcr;",
        "Lamvb;->b()F",
        "Lbjpk;-><init>()V",
        "Lbjpk;->v()Lbjpd;",
        "Lbjpd;->v(Lbjpd;Lbjpd;D)Z",
        "Lbjpb;->c(Lbjpd;Lbjpd;)D",
        "Lbkct;-><init>(Lbjci;FFFLbkcr;Lbkcs;)V",
        "Lbkcs;-><clinit>()V"
    };
    // Verified stock 26.44 plus upstream 2.9.10 Shapes/RefreshRate hook variants.
    // Debug positions excluded. No fingerprint is learned at patch time.
    public static final String[][] HASHES = {
        {"6938702ae0781395de656ba62ba77692069005ed2fe6325e17f1f67feb3d872d"},
        {"f4bcd6697430b12975e5e59dc887b89df00a98a1cb3d91ac51ffa3f9671b524b", "8adab500e327fd75e8d1316a037d39b0e99064361a636feb7ee2b02670cb6d78"},
        {"331bd1861af3adf7abb8acdce507d52061dfcb8423390b23649ab048fc411e42"},
        {"ee0b9bb80210ed4c76efc0c845ad546f61e54987f30c10f525952f22888a698c"},
        {"63bf202d206e67e8e8f87248d3dd0d54422d07740fcd738a8fcbf146802912f8"},
        {"ee3beb4d43d44da8eb1c98872284dbc3d1acb37aa46f182fca908972fb70b615", "c73cb83687780ce386e6aa83a88ec45d773f8cb80aeb5390fccb7ba282cbedec"},
        {"1be72c34321b7cdd079fe89dd6fff6b38f5d0c97a6ebe94a5a3f996e46447c7a"},
        {"0af7efd32de8ecd4c01c066bbbd34a36bd03a45b4f9e81653a1450815713624e"},
        {"b9d2743bf95ca6aacee11424c467b9502509b00267ad7cddd8ae69663f4a3087"},
        {"9cb1ac788691a530749d232a787116804ab13346e8e0f9c96c692f7a69389fa1"},
        {"57fe4ef7f64bc9320cad92fa30aea2815cfec8a63710b05bc494a544bfdf1504"},
        {"e141fc896e08d62820243351d1037bcca7102d1488c67b72845a71a9f441eacd"},
        {"44e3b5eb68d87df2d973523d76c0d0cf7c9d6fdaba4fd0e74cbdc626aaec79c9"},
        {"7609866da228543ddb0eb597ef040ebea06cf60da8ce60a08675409e46a7c5dd"},
        {"f4a796695d4d65d95c0df7b5dfa0d1686ea1948fa9615c08aced14e9c7205160"},
        {"ae5c0991cec175d8cb67353064f66138591749445abca339580a9b8b1d031bae"},
        {"4cab4b605d945020e39b8231c803cd50ddc88cf7e11be554bdfd46e9ef7b276b"},
        {"dd4a61f1a892f8e9aab5b412486a1e5ffa9ad62213e0af2770e2d01430db2f1a"},
        {"b9ab30bb6b740196cc9ab54cffac25ebf0c7c1c235b1c05a25a4aa1f989a5bf1"},
        {"56ae8a0c64c8680906c2bc6df19d5294977c0d936b182f60425750d7396ffe79"},
        {"43062fecc832c7ba149661106eccb69a0536965acecd73400260980e64a48a7e"},
        {"76a2d9864f42292d5b0dd9632ca792d47aab99a05639a78f9cc3360f55d21119"},
        {"be8dc327d40492a8563ffa3f2cafed058e955663bdd5172864915aa853ecc448"},
        {"68dd48eb99c7a32395ba1ca28b518890916e850a367fb2c900d0ce786af8ce11"},
        {"fe6874ad4ade77d06ef6a021255db2e9e34afb3085f36386fb0710bfc7b24556"},
        {"71aafe520587535e872b1b3299b38841fb4f1200d9042b6d53c229a9ccdd9f3e"},
        {"26027c89f598de55a06f6c2b6eb5894e917a59291042f7b8c2effef1722158fa"},
        {"255d2c88e612f8c25c904d94f33a3d05ed679ecad55362795345daf7b180fa30"},
        {"8dacce03d20b5642b985151dce7952353dfefe841a82e715f846bf40f8bc985c"},
        {"67cb249f64ea73686b74a35e43fabe8aea15f27ed6531bda6927632db297ccf7"},
        {"28c075026d7b2ea27afb9cce4cdb00105bbcd61fa20062f2ffeb61aa077261c0"}
    };

    public interface Lookup { ClassDef get(String owner); }
    public static void require(boolean value, String reason) {
        if (!value) throw new IllegalStateException("Maps startup location: " + reason);
    }
    public static String descriptor(MethodReference m) {
        StringBuilder result = new StringBuilder(m.getDefiningClass()).append("->").append(m.getName()).append('(');
        for (CharSequence p : m.getParameterTypes()) result.append(p);
        return result.append(')').append(m.getReturnType()).toString();
    }
    public static String owner(String descriptor) { return descriptor.substring(0, descriptor.indexOf("->")); }
    public static Method find(ClassDef c, String descriptor) {
        require(c != null, "Missing class for " + descriptor);
        Method result = null;
        for (Method m : c.getMethods()) if (descriptor.equals(descriptor(m))) {
            require(result == null, "Duplicate method " + descriptor); result = m;
        }
        require(result != null, "Missing method " + descriptor); return result;
    }
    public static String fingerprint(Method m) {
        try {
            MethodImplementation b = m.getImplementation();
            require(b != null, "Missing body " + descriptor(m));
            ImmutableMethodImplementation normalized = new ImmutableMethodImplementation(b.getRegisterCount(),
                b.getInstructions(), b.getTryBlocks(), Collections.emptyList());
            ImmutableMethod method = new ImmutableMethod(m.getDefiningClass(), m.getName(), m.getParameters(), m.getReturnType(),
                m.getAccessFlags(), m.getAnnotations(), m.getHiddenApiRestrictions(), normalized);
            ImmutableClassDef wrapper = new ImmutableClassDef(m.getDefiningClass(), 1, "Ljava/lang/Object;", Collections.emptyList(),
                null, Collections.emptySet(), Collections.emptyList(), Collections.singleton(method));
            MemoryDataStore store = new MemoryDataStore();
            try {
                DexPool.writeTo(store, new ImmutableDexFile(Opcodes.forApi(29), Collections.singleton(wrapper)));
                byte[] hash = MessageDigest.getInstance("SHA-256").digest(Arrays.copyOf(store.getBuffer(), store.getSize()));
                StringBuilder result = new StringBuilder();
                for (byte item : hash) result.append(String.format(Locale.ROOT, "%02x", item & 255));
                return result.toString();
            } finally { store.close(); }
        } catch (Exception error) { throw new IllegalStateException("Cannot fingerprint Maps native method", error); }
    }
    public static void validateContract(Method m, int contract) {
        require(CONTRACTS[contract].equals(descriptor(m)) && m.getImplementation() != null, "Native declaration changed " + contract);
        if (contract < HOOK_NAMES.length) require(m.getAccessFlags() == HOOK_FLAGS[contract], "Lifecycle flags changed " + contract);
        require(Arrays.asList(HASHES[contract]).contains(fingerprint(m)), "Unverified, modified or already patched native body " + CONTRACTS[contract]);
    }
    private static void field(Lookup l, String owner, String name, String type, int access) {
        ClassDef c = l.get(owner); require(c != null, "Missing field owner " + owner);
        int matches = 0;
        for (Field f : c.getFields()) if (name.equals(f.getName()) && type.equals(f.getType())) {
            require(f.getAccessFlags() == access, "Field access changed " + owner + "->" + name); matches++;
        }
        require(matches == 1, "Field missing or ambiguous " + owner + "->" + name);
    }
    public static void validateNative(Lookup l) {
        ClassDef main = l.get(MAIN), activity = l.get(OWNER);
        require(main != null && OWNER.equals(main.getSuperclass()), "Launcher hierarchy changed");
        require(activity != null && "Lncm;".equals(activity.getSuperclass()), "Activity hierarchy changed");
        require(l.get("Lamtt;") != null && "Laiti;".equals(l.get("Lamtt;").getSuperclass()), "Location controller hierarchy changed");
        require(!activity.getInterfaces().contains(HOST), "Location host already installed");
        for (Method m : activity.getMethods()) require(!BRIDGE.equals(m.getName()), "Native bridge already installed");
        for (int n = 0; n < CONTRACTS.length; n++) validateContract(find(l.get(owner(CONTRACTS[n])), CONTRACTS[n]), n);
        field(l, OWNER, "bx", LAYOUT, 4);
        field(l, LAYOUT, "i", "Lcqvj;", 1);
        field(l, "Lamtt;", "n", "Lamus;", 17);
        field(l, "Lamus;", "d", "Lamvn;", 17);
        field(l, "Lamus;", "f", "Z", 1);
        field(l, "Lamus;", "g", "Lbjny;", 1);
        field(l, "Lamus;", "k", "Lamuv;", 1);
        field(l, "Lamus;", "l", "Lamuw;", 1);
        field(l, "Lamus;", "p", "Lbjwv;", 1);
        field(l, "Lamxi;", "a", "Lamxi;", 16409);
        field(l, "Lamxi;", "l", "Lamxi;", 16409);
        field(l, "Lamxi;", "m", "Lamxi;", 16409);
        field(l, "Lbkzw;", "b", "Lbkzw;", 16409);
        field(l, "Lbkzw;", "c", "Lbkzw;", 16409);
        field(l, "Lbkcs;", "a", "Lbkcs;", 16409);
        field(l, "Lbkcs;", "b", "Lbkcs;", 16409);
        field(l, "Lbjwx;", "a", "Lbjpd;", 17);
        field(l, "Lbjwx;", "h", "F", 17);
        field(l, "Lbjwx;", "e", "F", 17);
        field(l, "Lbjwx;", "d", "F", 17);
        Method provider = find(l.get("Lcqvj;"), "Lcqvj;->a()Ljava/lang/Object;");
        Method mode = find(l.get("Lamvn;"), "Lamvn;->h()Lamxi;");
        require(provider.getAccessFlags() == 1025 && mode.getAccessFlags() == 1025,
                "Provider or map-mode interface changed");
        for (String signature : Arrays.asList("Lamvn;->I(Lbjpk;)Z", "Lamvn;->b()F", "Lbjwv;->c()Lbjwx;"))
            require(find(l.get(owner(signature)), signature).getAccessFlags() == 1025,
                    "Native camera interface changed " + signature);
    }
    public static int hookIndex(Method m) {
        String d = descriptor(m);
        for (int n = 0; n < HOOK_NAMES.length; n++) if (CONTRACTS[n].equals(d)) return n;
        return -1;
    }
    public static void applyHook(MutableMethod m, int n) {
        validateContract(m, n);
        MutableMethodImplementation body = m.getImplementation();
        List<String> parameters = new ArrayList<String>();
        parameters.add("Landroid/app/Activity;");
        if (!HOOK_ARGUMENTS[n].isEmpty()) parameters.add(HOOK_ARGUMENTS[n]);
        int count = parameters.size(), start = body.getRegisterCount() - count;
        require(start >= 0, "Invalid lifecycle registers");
        ImmutableMethodReference target = new ImmutableMethodReference(RUNTIME, HELPER_NAMES[n], parameters, "V");
        body.addInstruction(0, new BuilderInstruction3rc(Opcode.INVOKE_STATIC_RANGE, start, count, target));
        body.addInstruction(1, new BuilderInstruction10x(Opcode.NOP));
    }
    public static String bridgeCode() {
        // 0 = wait; 1 = camera acknowledged; 2 = issued; -1 = route/nav cancel.
        // p1=false is strictly a read-only acknowledgement poll. The native f/g
        // permission callback path is deliberately absent: it can later toggle
        // tracking/compass and cannot be withdrawn after user interaction.
        // A nearby cached fix is acknowledged only while native follow is active,
        // so a later fresh fix still updates the map after startup completes.
        return "iget-object v0, p0, Lnby;->bx:" + LAYOUT + "\n" +
            "if-eqz v0, :wait\n" +
            "iget-object v0, v0, " + LAYOUT + "->i:Lcqvj;\n" +
            "if-eqz v0, :wait\n" +
            "invoke-interface {v0}, Lcqvj;->a()Ljava/lang/Object;\n" +
            "move-result-object v0\n" +
            "instance-of v1, v0, Lamtt;\n" +
            "if-eqz v1, :wait\n" +
            "check-cast v0, Lamtt;\n" +
            "invoke-virtual {v0}, Laiti;->K()Z\n" +
            "move-result v1\n" +
            "if-eqz v1, :wait\n" +
            "iget-object v0, v0, Lamtt;->n:Lamus;\n" +
            "if-eqz v0, :wait\n" +
            "iget-object v1, v0, Lamus;->d:Lamvn;\n" +
            "if-eqz v1, :wait\n" +
            "invoke-interface {v1}, Lamvn;->h()Lamxi;\n" +
            "move-result-object v2\n" +
            "if-eqz v2, :wait\n" +
            "sget-object v3, Lamxi;->l:Lamxi;\n" +
            "if-eq v2, v3, :wait\n" +
            "sget-object v3, Lamxi;->a:Lamxi;\n" +
            "if-eq v2, v3, :map\n" +
            "sget-object v3, Lamxi;->m:Lamxi;\n" +
            "if-ne v2, v3, :cancel\n" +
            ":map\n" +
            "iget-object v2, v0, Lamus;->g:Lbjny;\n" +
            "if-eqz v2, :wait\n" +
            "iget-boolean v2, v0, Lamus;->f:Z\n" +
            "if-eqz v2, :old_camera\n" +
            "iget-object v2, v0, Lamus;->l:Lamuw;\n" +
            "goto :camera_ready\n" +
            ":old_camera\n" +
            "iget-object v2, v0, Lamus;->k:Lamuv;\n" +
            ":camera_ready\n" +
            "if-eqz v2, :wait\n" +
            "iget-object v2, v0, Lamus;->p:Lbjwv;\n" +
            "if-eqz v2, :wait\n" +
            "new-instance v3, Lbjpk;\n" +
            "invoke-direct {v3}, Lbjpk;-><init>()V\n" +
            "invoke-interface {v1, v3}, Lamvn;->I(Lbjpk;)Z\n" +
            "move-result v4\n" +
            "if-eqz v4, :wait\n" +
            "invoke-interface {v2}, Lbjwv;->c()Lbjwx;\n" +
            "move-result-object v2\n" +
            "if-eqz v2, :wait\n" +
            "invoke-virtual {v0}, Lamus;->b()Lbkzw;\n" +
            "move-result-object v10\n" +
            "if-eqz v10, :wait\n" +
            "invoke-virtual {v3}, Lbjpk;->v()Lbjpd;\n" +
            "move-result-object v3\n" +
            "iget-object v4, v2, Lbjwx;->a:Lbjpd;\n" +
            "const-wide v5, 0x4049000000000000L\n" +
            "invoke-static {v3, v4, v5, v6}, Lbjpd;->v(Lbjpd;Lbjpd;D)Z\n" +
            "move-result v3\n" +
            "iget v7, v2, Lbjwx;->h:F\n" +
            "const/high16 v4, 0x41500000\n" +
            "cmpl-float v4, v7, v4\n" +
            "if-ltz v4, :need_move\n" +
            "if-eqz v3, :need_move\n" +
            "sget-object v3, Lbkzw;->b:Lbkzw;\n" +
            "if-eq v10, v3, :confirmed\n" +
            "sget-object v3, Lbkzw;->c:Lbkzw;\n" +
            "if-ne v10, v3, :need_move\n" +
            ":confirmed\n" +
            "const/4 v3, 0x1\n" +
            "return v3\n" +
            ":need_move\n" +
            "if-eqz p1, :wait\n" +
            "if-gez v4, :zoom_ready\n" +
            "const/high16 v7, 0x41700000\n" +
            ":zoom_ready\n" +
            "iget v8, v2, Lbjwx;->e:F\n" +
            "iget v9, v2, Lbjwx;->d:F\n" +
            "sget-object v11, Lbkcs;->a:Lbkcs;\n" +
            "sget-object v4, Lbkzw;->c:Lbkzw;\n" +
            "if-ne v10, v4, :bearing_ready\n" +
            "sget-object v11, Lbkcs;->b:Lbkcs;\n" +
            "invoke-interface {v1}, Lamvn;->b()F\n" +
            "move-result v4\n" +
            "sub-float/2addr v9, v4\n" +
            ":bearing_ready\n" +
            "invoke-virtual {v0}, Lamus;->a()Lbkcr;\n" +
            "move-result-object v10\n" +
            "const/4 v6, 0x0\n" +
            "new-instance v5, Lbkct;\n" +
            "invoke-direct/range {v5 .. v11}, Lbkct;-><init>(Lbjci;FFFLbkcr;Lbkcs;)V\n" +
            "const/4 v3, 0x0\n" +
            "invoke-virtual {v0, v5, v3}, Lamus;->l(Lbkct;Z)V\n" +
            "const/4 v3, 0x2\n" +
            "return v3\n" +
            ":cancel\n" +
            "const/4 v3, -0x1\n" +
            "return v3\n" +
            ":wait\n" +
            "const/4 v3, 0x0\n" +
            "return v3";
    }
    public static MutableMethod bridge() {
        MutableMethod m = new MutableMethod(new ImmutableMethod(OWNER, BRIDGE,
            Collections.singletonList(new ImmutableMethodParameter("Z", Collections.emptySet(), "issue")), "I", 17,
            Collections.emptySet(), Collections.emptySet(), new ImmutableMethodImplementation(14,
                Collections.emptyList(), Collections.emptyList(), Collections.emptyList())));
        InstructionExtensions.INSTANCE.addInstructions(m, 0, bridgeCode());
        return m;
    }
    public static void apply(MutableClass activity) {
        require(activity != null && OWNER.equals(activity.getType()) && !activity.getInterfaces().contains(HOST), "Location host already applied or wrong target");
        for (Method m : activity.getMethods()) require(!BRIDGE.equals(m.getName()), "Location bridge already applied");
        List<MutableMethod> hooks = new ArrayList<MutableMethod>();
        // Complete all validation before mutating the first method.
        for (int n = 0; n < HOOK_NAMES.length; n++) {
            Method found = find(activity, CONTRACTS[n]); validateContract(found, n); hooks.add((MutableMethod)found);
        }
        for (int n = 0; n < hooks.size(); n++) applyHook(hooks.get(n), n);
        activity.getInterfaces().add(HOST);
        require(activity.getMethods().add(bridge()), "Failed adding native bridge");
    }
}
