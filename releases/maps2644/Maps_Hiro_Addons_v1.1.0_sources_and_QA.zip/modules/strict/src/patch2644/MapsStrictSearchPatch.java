package app.hiro.mapsstrict2644.patches;

import java.io.InputStream;
import java.security.MessageDigest;
import java.util.*;
import java.util.function.Supplier;
import kotlin.Pair;
import kotlin.Unit;
import kotlin.jvm.functions.Function1;
import app.morphe.patcher.patch.*;
import app.morphe.patcher.util.proxy.mutableTypes.*;
import com.android.tools.smali.dexlib2.*;
import com.android.tools.smali.dexlib2.builder.instruction.*;
import com.android.tools.smali.dexlib2.iface.*;
import com.android.tools.smali.dexlib2.iface.instruction.*;
import com.android.tools.smali.dexlib2.iface.reference.*;
import com.android.tools.smali.dexlib2.immutable.*;
import com.android.tools.smali.dexlib2.immutable.reference.*;
import com.android.tools.smali.dexlib2.writer.io.MemoryDataStore;
import com.android.tools.smali.dexlib2.writer.pool.DexPool;

/** Search filtering at the request-owned response boundary, before map/list model creation. */
public final class MapsStrictSearchPatch {
    private MapsStrictSearchPatch() {}
    public static final String NAME = "店名検索を厳密にする";
    public static final String VERSION = "26.44.06.1006895251";
    public static final String CODE = "1068856906";
    public static final String OWNER = "Lavuw;";
    public static final String MODEL = "Lavuz;";
    public static final String MARKER = "hiroStrictSearchResponse";
    public static final int MARKER_FLAGS = 4226; // private transient synthetic; excluded from serialization.
    public static final String TARGET = OWNER + "->f(Lcqmj;Landroid/app/Application;Lawub;)V";
    public static final String RUNTIME = "Lapp/hiro/mapsstrict2644/SearchFilter;";
    public static final String FILTER = RUNTIME + "->filterResponse(Ljava/lang/Object;Ljava/lang/String;Ljava/lang/Object;)Ljava/lang/Object;";
    public static final String RECONCILE = RUNTIME + "->reconcileModel(Ljava/lang/Object;Ljava/lang/Object;)V";
    public static final String EXTENSION = "/extensions/maps_strict_search2644.mpe";
    public static final Set<String> PACKAGES = Collections.unmodifiableSet(new LinkedHashSet<String>(Arrays.asList(
        "org.ungoogled.android.apps.maps.microg", "com.google.android.apps.maps")));

    public interface Lookup { ClassDef get(String type); }
    public static void validateContext(final BytecodePatchContext c) {
        validatePackage(c.getPackageMetadata().getPackageName(),c.getPackageMetadata().getVersionName(),c.getPackageMetadata().getVersionCode());
        validateNative(new Lookup(){public ClassDef get(String type){return c.classDefByOrNull(type);}});
    }
    public static void execute(final BytecodePatchContext c) {
        apply(c.mutableClassDefBy(OWNER),c.mutableClassDefBy(MODEL));
        try (InputStream raw=MapsStrictSearchPatch.class.getResourceAsStream(EXTENSION)) {
            require(raw!=null,"Missing verified 26.44 strict-search extension");
            DexFile dex=com.android.tools.smali.dexlib2.dexbacked.DexBackedDexFile.fromInputStream(Opcodes.getDefault(),new java.io.BufferedInputStream(raw));
            int count=0;
            for(ClassDef type:dex.getClasses()) {
                require(type.getType().startsWith("Lapp/hiro/mapsstrict2644/"),"Unexpected runtime namespace");
                require(c.classDefByOrNull(type.getType())==null,"Strict-search runtime already installed");
                c.getPatchClasses$morphe_patcher().addClass$morphe_patcher(new MutableClass(type));
                count++;
            }
            require(count>0,"Empty strict-search runtime");
        } catch(Exception e) { throw new IllegalStateException("Cannot load verified 26.44 strict-search runtime",e); }
        require((find(c.classDefBy(RUNTIME),FILTER).getAccessFlags()&9)==9,"Runtime filter is not public static");
        require((find(c.classDefBy(RUNTIME),RECONCILE).getAccessFlags()&9)==9,"Runtime reconciliation is not public static");
    }

    public static void require(boolean ok, String why) {
        if (!ok) throw new IllegalStateException("Maps strict search: " + why);
    }
    public static void validatePackage(String p, String v, String code) {
        require(PACKAGES.contains(p) && VERSION.equals(v) && CODE.equals(code),
            "Requires verified Maps 26.44.06.1006895251 (1068856906)");
    }
    public static String descriptor(MethodReference m) {
        StringBuilder b = new StringBuilder(m.getDefiningClass()).append("->").append(m.getName()).append('(');
        for (CharSequence p : m.getParameterTypes()) b.append(p);
        return b.append(')').append(m.getReturnType()).toString();
    }
    public static String owner(String descriptor) { return descriptor.substring(0, descriptor.indexOf("->")); }
    public static Method find(ClassDef c, String d) {
        require(c != null, "Missing class for " + d);
        Method found = null;
        for (Method m : c.getMethods()) if (d.equals(descriptor(m))) {
            require(found == null, "Duplicate method " + d); found = m;
        }
        require(found != null, "Missing method " + d); return found;
    }
    public static String fingerprint(Method m) {
        try {
            MethodImplementation b = m.getImplementation();
            require(b != null, "Missing native body " + descriptor(m));
            ImmutableMethodImplementation normalized = new ImmutableMethodImplementation(b.getRegisterCount(),
                b.getInstructions(), b.getTryBlocks(), Collections.emptyList());
            ImmutableMethod method = new ImmutableMethod(m.getDefiningClass(), m.getName(), m.getParameters(), m.getReturnType(),
                m.getAccessFlags(), m.getAnnotations(), m.getHiddenApiRestrictions(), normalized);
            ImmutableClassDef wrapper = new ImmutableClassDef(m.getDefiningClass(), 1, "Ljava/lang/Object;",
                Collections.emptyList(), null, Collections.emptySet(), Collections.emptyList(), Collections.singleton(method));
            MemoryDataStore store = new MemoryDataStore();
            try {
                DexPool.writeTo(store, new ImmutableDexFile(Opcodes.forApi(29), Collections.singleton(wrapper)));
                byte[] digest = MessageDigest.getInstance("SHA-256").digest(Arrays.copyOf(store.getBuffer(), store.getSize()));
                StringBuilder result = new StringBuilder();
                for (byte value : digest) result.append(String.format(Locale.ROOT, "%02x", value & 255));
                return result.toString();
            } finally { store.close(); }
        } catch (Exception e) { throw new IllegalStateException("Cannot fingerprint native search contract", e); }
    }
    public static void validateNative(Lookup lookup) { NativeContracts.validate(lookup); }
    public static int insertionIndex(Method method) {
        require(method.getImplementation() != null && method.getImplementation().getRegisterCount() == 13,
            "Search response register layout changed");
        int index = 0, found = -1;
        for (Instruction ins : method.getImplementation().getInstructions()) {
            if (ins.getOpcode() == Opcode.CHECK_CAST && ((OneRegisterInstruction)ins).getRegisterA() == 0
                && ((ReferenceInstruction)ins).getReference().toString().equals("Lcqmf;")) {
                require(found == -1, "Ambiguous search parameters"); found = index + 1;
            }
            index++;
        }
        require(found >= 0, "Missing search parameter decode"); return found;
    }
    public static void apply(MutableClass type, MutableClass model) {
        MutableMethod method = (MutableMethod)find(type, TARGET);
        NativeContracts.validateTarget(method);
        NativeContracts.validateModel(model);
        applyRequest(type);
        applyModel(model);
    }
    public static void applyRequest(MutableClass type) {
        MutableMethod method = (MutableMethod)find(type, TARGET);
        NativeContracts.validateTarget(method);
        int at = insertionIndex(method);
        // v0 retains the native request parameters; v1/v2 are dead until their
        // next original assignments; v10 is exactly this request's response.
        method.getImplementation().addInstruction(at++, new BuilderInstruction22c(Opcode.IGET_OBJECT, 1, 0,
            new ImmutableFieldReference("Lcqmf;", "e", "Ljava/lang/String;")));
        method.getImplementation().addInstruction(at++, new BuilderInstruction22c(Opcode.IGET_OBJECT, 2, 9,
            new ImmutableFieldReference(OWNER, "g", MODEL)));
        method.getImplementation().addInstruction(at++, new BuilderInstruction35c(Opcode.INVOKE_STATIC, 3, 10, 1, 2, 0, 0,
            new ImmutableMethodReference(RUNTIME, "filterResponse", Arrays.asList("Ljava/lang/Object;", "Ljava/lang/String;", "Ljava/lang/Object;"), "Ljava/lang/Object;")));
        method.getImplementation().addInstruction(at++, new BuilderInstruction11x(Opcode.MOVE_RESULT_OBJECT, 10));
        method.getImplementation().addInstruction(at, new BuilderInstruction21c(Opcode.CHECK_CAST, 10,
            new ImmutableTypeReference("Lcqmj;")));
    }
    public static int mergeInsertionIndex(Method method) {
        int index = 0, found = -1;
        for (Instruction ins : method.getImplementation().getInstructions()) {
            if (ins.getOpcode() == Opcode.IGET_OBJECT && ((TwoRegisterInstruction)ins).getRegisterA() == 9
                && ((TwoRegisterInstruction)ins).getRegisterB() == 9
                && ((ReferenceInstruction)ins).getReference().toString().equals(MODEL + "->G:Lawxi;")) {
                require(found == -1, "Ambiguous merge completion boundary"); found = index;
            }
            index++;
        }
        require(found >= 0, "Missing accepted merge completion boundary"); return found;
    }
    public static void applyModel(MutableClass model) {
        NativeContracts.validateModel(model);
        MutableMethod merge = (MutableMethod)find(model, NativeContracts.MERGE);
        int at = mergeInsertionIndex(merge);
        model.getFields().add(new MutableField(new ImmutableField(MODEL, MARKER, "Ljava/lang/Object;",
            MARKER_FLAGS, null, Collections.emptySet(), Collections.emptySet())));
        // Only accepted merges reach this point. Both native locks are held,
        // and v9 still refers to the incoming result rather than its G field.
        merge.getImplementation().addInstruction(at, new BuilderInstruction35c(Opcode.INVOKE_STATIC, 2, 8, 9, 0, 0, 0,
            new ImmutableMethodReference(RUNTIME, "reconcileModel", Arrays.asList("Ljava/lang/Object;", "Ljava/lang/Object;"), "V")));
    }
}
