import java.nio.file.*;
import java.util.*;
import com.android.tools.smali.dexlib2.*;
import com.android.tools.smali.dexlib2.iface.*;
import com.android.tools.smali.dexlib2.writer.pool.DexPool;
import com.android.tools.smali.dexlib2.writer.io.FileDataStore;
/** Preserve every non-ULike class and replace only the ULike patch namespace. */
public final class MergePatchDex {
 public static void main(String[] a)throws Exception{
  var old=DexFileFactory.loadDexFile(a[0],Opcodes.forApi(26));var newer=DexFileFactory.loadDexFile(a[1],Opcodes.forApi(26));
  String prefix="Lapp/hiro/ulike/patches/";TreeMap<String,ClassDef> all=new TreeMap<>();Set<String> before=new TreeSet<>(),after=new TreeSet<>();
  for(ClassDef c:old.getClasses())if(c.getType().startsWith(prefix))before.add(c.getType());else all.put(c.getType(),c);
  for(ClassDef c:newer.getClasses()){if(!c.getType().startsWith(prefix)||all.put(c.getType(),c)!=null)throw new IllegalStateException(c.getType());after.add(c.getType());}
  if(!before.equals(after))throw new IllegalStateException("Namespace mismatch");
  DexPool out=new DexPool(old.getOpcodes());for(ClassDef c:all.values())out.internClass(c);FileDataStore f=new FileDataStore(new java.io.File(a[2]));try{out.writeTo(f);}finally{f.close();}
  var check=DexFileFactory.loadDexFile(a[2],Opcodes.forApi(26));Map<String,ClassDef> read=new TreeMap<>();for(ClassDef c:check.getClasses())read.put(c.getType(),c);
  for(var e:all.entrySet())if(!com.android.tools.smali.dexlib2.immutable.ImmutableClassDef.of(e.getValue()).equals(com.android.tools.smali.dexlib2.immutable.ImmutableClassDef.of(read.get(e.getKey()))))throw new IllegalStateException("Class mismatch");
  System.out.println("Merged "+all.size()+" classes; replaced "+after.size()+" ULike classes.");
 }
}
