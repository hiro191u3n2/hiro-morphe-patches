public final class cigc { public cifb c; }
