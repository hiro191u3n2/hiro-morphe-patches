import com.google.common.collect.ImmutableList;
public final class bkww {
    public String b;
    public ImmutableList<bkwu> c;
}
