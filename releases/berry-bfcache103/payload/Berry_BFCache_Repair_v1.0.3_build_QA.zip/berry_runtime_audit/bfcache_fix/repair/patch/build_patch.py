#!/usr/bin/env python3
"""Build the five-patch MPP without modifying the original four JVM providers/extensions."""
from pathlib import Path
import hashlib, json, os, shutil, subprocess, sys, zipfile
ROOT=Path(__file__).resolve().parent
AUDIT=ROOT.parents[2]
JAVA=AUDIT/'diagnostic/java21/jdk-21.0.13+9-jre/bin/java'
HOST=AUDIT/'diagnostic/morphe-desktop-1.19.0-dev.19-all.jar'
ECJ=AUDIT/'direct_diagnostic/toolchain/ecj-3.46.100.jar'
D8=AUDIT/'direct_diagnostic/toolchain/r8-9.5.28.jar'
BASE=AUDIT/'Berry_Browser_v1.3.1.mpp'
EXT=ROOT.parent/'extensions/berry_bfcache_restore.mpe'
for name in ['classes','dex','original_classes','stub_classes']:
 p=ROOT/name
 if p.exists(): shutil.rmtree(p)
 p.mkdir(parents=True)
with zipfile.ZipFile(BASE) as z:
 for n in z.namelist():
  if n.endswith('.class'):
   p=ROOT/'original_classes'/n;p.parent.mkdir(parents=True,exist_ok=True);p.write_bytes(z.read(n))
stub=AUDIT/'direct_diagnostic/compile_stubs/app/morphe/patcher/patch/AppTarget.java'
subprocess.run([str(JAVA),'-jar',str(ECJ),'-source','11','-target','11','-encoding','UTF-8','-d',str(ROOT/'stub_classes'),str(stub)],check=True)
cp=os.pathsep.join(map(str,[ROOT/'stub_classes',ROOT/'original_classes',HOST]))
subprocess.run([str(JAVA),'-jar',str(ECJ),'-source','11','-target','11','-encoding','UTF-8','-cp',cp,'-d',str(ROOT/'classes'),*map(str,sorted((ROOT/'src').rglob('*.java')))],check=True)
compiled=sorted((ROOT/'classes').rglob('*.class'))
assert all(str(p.relative_to(ROOT/'classes')).startswith('app/hiro/berrybfcache/') for p in compiled)
if '--compile-only' in sys.argv: sys.exit(0)
assert EXT.exists(),EXT
all_classes=sorted((ROOT/'original_classes').rglob('*.class'))+compiled
subprocess.run([str(JAVA),'-cp',str(D8),'com.android.tools.r8.D8','--release','--min-api','26','--classpath',str(HOST),'--output',str(ROOT/'dex'),*map(str,all_classes)],check=True)
fields={'Manifest-Version':'1.0','Name':'Berry Browser BFCache復帰補正','Description':'Original four Berry patches plus guarded BFCache restoration repair. Device verification required.','Version':'1.0.3','Timestamp':'2026-11-02T00:00:00','Source':'local','Author':'ひろ','Contact':'na','Website':'na','License':'GPLv3','Patcher-Version':'2.2.0-dev.2'}
def manifest_line(k,v):
 line=f'{k}: {v}'.encode('utf-8');parts=[]
 while len(line)>70:
  n=70
  while (line[n] & 0xc0)==0x80:n-=1
  parts.append(line[:n]);line=b' '+line[n:]
 parts.append(line)
 return b'\r\n'.join(parts)+b'\r\n'
manifest=b''.join(manifest_line(k,v) for k,v in fields.items())+b'\r\n'
assert all(len(l)<=72 for l in manifest.splitlines())
out=ROOT.parent/'Berry_BFCache_Repair_v1.0.3.mpp'
with zipfile.ZipFile(BASE) as base, zipfile.ZipFile(out,'w',zipfile.ZIP_DEFLATED) as z:
 for n in base.namelist():
  if n not in ['META-INF/MANIFEST.MF','classes.dex']:z.writestr(n,base.read(n))
 z.writestr('META-INF/MANIFEST.MF',manifest)
 for p in compiled:z.write(p,str(p.relative_to(ROOT/'classes')))
 z.write(ROOT/'dex/classes.dex','classes.dex');z.write(EXT,'extensions/berry_bfcache_restore.mpe')
with zipfile.ZipFile(BASE) as base,zipfile.ZipFile(out) as z:
 assert z.testzip() is None
 unchanged=[n for n in base.namelist() if n not in ['META-INF/MANIFEST.MF','classes.dex']]
 assert all(base.read(n)==z.read(n) for n in unchanged)
 assert not any(n.startswith('app/morphe/') for n in z.namelist())
 assert len([n for n in z.namelist() if n.startswith('classes') and n.endswith('.dex')])==1
 report={'file':str(out),'sha256':hashlib.sha256(out.read_bytes()).hexdigest(),'bytes':out.stat().st_size,'base_sha256':hashlib.sha256(BASE.read_bytes()).hexdigest(),'original_entries_unchanged':unchanged,'new_class_count':len(compiled),'extension_sha256':hashlib.sha256(EXT.read_bytes()).hexdigest()}
(ROOT/'build_report.json').write_text(json.dumps(report,ensure_ascii=False,indent=2)+'\n')
print(json.dumps(report,ensure_ascii=False))
