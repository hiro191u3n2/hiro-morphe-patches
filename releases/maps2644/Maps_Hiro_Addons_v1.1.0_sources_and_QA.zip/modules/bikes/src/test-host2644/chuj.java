public final class chuj { public int b; public int c; public String f; }
