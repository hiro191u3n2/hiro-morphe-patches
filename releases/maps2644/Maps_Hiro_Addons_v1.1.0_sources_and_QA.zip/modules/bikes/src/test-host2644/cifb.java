public final class cifb { public int b = 1; public Object c; }
