#!/usr/bin/env python3
"""Local rejection tests. Fixtures and wrapper are QA-only, never deliver."""
from pathlib import Path
import hashlib,json,struct,zlib,zipfile
import validate
from androguard.core.dex import DEX
from loguru import logger
logger.remove()
root=validate.ROOT
fixtures=root/'validation/guard_fixtures';fixtures.mkdir(exist_ok=True)
fixture=fixtures/'QA_ONLY_current383931_changed_setup.apk'
source=validate.CURRENT
protected=[validate.BUNDLE,*sorted((root/'patch/src').rglob('*.java')),*sorted((root/'runtime_src').rglob('*.java')),*sorted((root/'extensions').glob('*.mpe'))]
before={str(p.relative_to(root)):validate.sha(p) for p in protected}
changed=[]
with zipfile.ZipFile(source) as src,zipfile.ZipFile(fixture,'w',zipfile.ZIP_DEFLATED) as dst:
 for entry in src.infolist():
  data=src.read(entry.filename)
  if entry.filename.startswith('classes') and entry.filename.endswith('.dex'):
   dex=DEX(data)
   for c in dex.get_classes():
    if c.get_name()!='Le87;':continue
    for m in c.get_methods():
     if m.get_name()!='y' or m.get_descriptor()!='(Lxw5;)V':continue
     code=m.get_code(); first=next(code.get_bc().get_instructions())
     assert first.get_name()=='move-object/from16'
     off=m.get_code_off()+16
     original=data[off:off+4]
     assert original==bytes.fromhex('08001300'),original.hex()
     buf=bytearray(data);buf[off+2]=0x14
     buf[12:32]=hashlib.sha1(buf[32:]).digest()
     buf[8:12]=struct.pack('<I',zlib.adler32(buf[12:])&0xffffffff)
     repaired=bytes(buf)
     assert hashlib.sha1(repaired[32:]).digest()==repaired[12:32]
     assert (zlib.adler32(repaired[12:])&0xffffffff)==struct.unpack('<I',repaired[8:12])[0]
     afterdex=DEX(repaired)
     found=[mm for cc in afterdex.get_classes() if cc.get_name()=='Le87;' for mm in cc.get_methods() if mm.get_name()=='y' and mm.get_descriptor()=='(Lxw5;)V']
     assert len(found)==1
     mutated=next(found[0].get_code().get_bc().get_instructions())
     assert mutated.get_name()=='move-object/from16'
     changed.append({'dex_entry':entry.filename,'method':'Le87;->y(Lxw5;)V','instruction_offset':off,'before':original.hex(),'after':repaired[off:off+4].hex(),'semantic_change':'First move-object/from16 source v19 -> v20; instruction width unchanged','dex_checksum_updated':True,'dex_signature_updated':True,'parse_after_mutation':True})
     data=repaired
  dst.writestr(entry,data)
assert len(changed)==1,changed
qa=root/'qa_harness/QA_ONLY_never_deliver.mpp'
if not qa.exists():qa=validate.qa_bundle()
rejected_changed=validate.run('reject_unknown_setup_body',fixture,qa,[validate.QA_NAME],expected_success=False)
fixed=root/'validation/modified383931_same_repair_only/validation_unsigned.apk'
rejected_again=validate.run('reject_fixed_current_reapply',fixed,qa,[validate.QA_NAME],expected_success=False)
logs={}
for label,needle in [('reject_unknown_setup_body','検証済み構造と一致しません：Le87;->y(Lxw5;)V'),('reject_fixed_current_reapply','補正対象が適用済み、または未対応です：Lt70;->onPageCommitVisible')]:
 text=(root/'validation'/label/'events.jsonl').read_text()+'\n'+(root/'validation'/label/'stdout.log').read_text()+'\n'+(root/'validation'/label/'stderr.log').read_text()
 assert needle in text,(label,text[-5000:])
 logs[label]={'expected_rejection':needle,'matched':True,'unsigned_output_absent':not (root/'validation'/label/'validation_unsigned.apk').exists()}
after={str(p.relative_to(root)):validate.sha(p) for p in protected}
assert before==after
report={'pass':True,'scope':'Local QA only; no fixtures or QA wrapper are user deliverables','modified_input_sha256':validate.sha(source),'fixture_sha256':validate.sha(fixture),'mutation':changed,'checks':logs,'unknown_body_report':rejected_changed,'reapply_report':rejected_again,'protected_artifacts_unchanged':before,'physical_device_tested':False}
(root/'GUARD_QA.json').write_text(json.dumps(report,ensure_ascii=False,indent=2)+'\n')
print(json.dumps({'pass':True,'report':str(root/'GUARD_QA.json'),'checks':logs},ensure_ascii=False))
