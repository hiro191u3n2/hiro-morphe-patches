from pathlib import Path
import sys,importlib.util,json,re,hashlib,zipfile,gc
ROOT=Path('/workspace/scratch/69dbfd2eb346/berry_runtime_audit')
sys.path.insert(0,str(ROOT/'python-deps'))
spec=importlib.util.spec_from_file_location('base',ROOT/'current383931/audit_addon_output.py')
base=importlib.util.module_from_spec(spec);spec.loader.exec_module(base)
OUT=ROOT/'bfcache_fix/repair'
TARGET='Lhiro/berrybfcache/'
orig_body=base.body
captured={}

def body(method):
 b=orig_body(method)
 ident=method.get_class_name()+'->'+method.get_name()+method.get_descriptor()
 if b:
  max_args=0
  for ins in method.get_instructions():
   if ins.get_name().startswith('invoke-'):
    n=getattr(ins,'A',getattr(ins,'AA',None))
    if n is not None:max_args=max(max_args,n)
  captured[ident]={'outgoing':b['outgoing'],'required':max_args}
  assert b['outgoing']>=max_args,(ident,b['outgoing'],max_args)
  b=dict(b);b.pop('outgoing')
 return b
base.body=body

def exact_classes(apk,names):
 results={}
 with zipfile.ZipFile(apk) as z:
  for n in z.namelist():
   if not re.fullmatch(r'classes\d*\.dex',n):continue
   d=base.DEX(z.read(n))
   for c in d.get_classes():
    if c.get_name() in names:
     results[c.get_name()]={'flags':c.get_access_flags(),'superclass':c.get_superclassname(),'interfaces':c.get_interfaces(),'source':None if c.get_source_file_idx()==0xffffffff else c.CM.get_string(c.get_source_file_idx()),'annotations':base.annotations(c)}
     results[c.get_name()]['methods']={m.get_name()+m.get_descriptor():orig_body(m) for m in c.get_methods()}
     results[c.get_name()]['fields']={f.get_name()+':'+f.get_descriptor():[f.get_access_flags(),base.encoded(f.get_init_value())] for f in c.get_fields()}
 return results

def run(version,oldapk,newapk,client,adapter,setupowner,setupname,tab):
 global captured
 print('Reading',version,'baseline',flush=True);captured={};old=base.snapshot(oldapk);oldcap=captured
 print('Reading',version,'repair',flush=True);captured={};new=base.snapshot(newapk);newcap=captured
 dif={k:base.compare_dict(old[k],new[k]) for k in ['class','field','method','method_body','method_raw','entries']}
 wanted_changed={setupowner+'->'+setupname+'('+tab+')V',client+'->onPageStarted(Landroid/webkit/WebView; Ljava/lang/String; Landroid/graphics/Bitmap;)V'}
 native_added={adapter+'->hiroInstallBfcache()V',client+'->hiroCompleteBfcache(Landroid/webkit/WebView; Ljava/lang/String;)V',client+'->onPageCommitVisible(Landroid/webkit/WebView; Ljava/lang/String;)V'}
 native_fields={adapter+'->hiroBfcacheInstalled:Z'}
 added_runtime_classes=[c for c in dif['class']['added'] if c.startswith(TARGET)]
 assert dif['class']['changed']==[client],dif['class']['changed']
 assert not dif['class']['removed']
 assert len(added_runtime_classes)==len(dif['class']['added'])
 assert not dif['field']['changed'] and not dif['field']['removed'],dif['field']
 assert {x for x in dif['field']['added'] if not x.startswith(TARGET)}==native_fields
 assert not dif['method']['changed'] and not dif['method']['removed'],dif['method']
 assert {x for x in dif['method']['added'] if not x.startswith(TARGET)}==native_added
 assert set(dif['method_body']['changed'])==wanted_changed,dif['method_body']['changed']
 assert not dif['method_body']['removed']
 sig=re.compile(r'^META-INF/(?:[^/]+\.(?:RSA|DSA|EC|SF)|MANIFEST\.MF)$',re.I)
 resources={k:[x for x in v if not re.fullmatch(r'classes\d*\.dex',x) and not sig.match(x)] for k,v in dif['entries'].items()}
 arsc_diff = resources == {'added': [], 'removed': [], 'changed': ['resources.arsc']}
 if arsc_diff:
  assert version=='383740'
  assert json.loads((OUT/'INDEPENDENT_repair_audit_arsc383740.json').read_text())['result']=='PASS_SEMANTIC'
 else:
  assert not any(resources.values()),resources
 ods=exact_classes(oldapk,{client,adapter,setupowner});nds=exact_classes(newapk,{client,adapter,setupowner})
 a,b=dict(ods[client]),dict(nds[client]);a.pop('methods');a.pop('fields');b.pop('methods');b.pop('fields')
 ia,ib=a.pop('interfaces'),b.pop('interfaces');assert a==b
 assert set(ib)==set(ia)|{'Lhiro/berrybfcache/CompletionTarget;'}
 for owner,method,prefix_count in [(client,'onPageStarted(Landroid/webkit/WebView; Ljava/lang/String; Landroid/graphics/Bitmap;)V',1),(setupowner,setupname+'('+tab+')V',6)]:
  ab=ods[owner]['methods'][method];bb=nds[owner]['methods'][method]
  assert ab['instructions']==bb['instructions'][prefix_count:],(owner,method,'tail')
  for k in ['registers','incoming','tries']:assert ab[k]==bb[k],(owner,method,k)
 oldhelper=[k for k in old['method_body'] if k.startswith(('Lhiro/berry/','Lhiro/berryzoom/','Lapp/hiro/berry/runtime/','LHiroBerryBrowserChooser'))]
 assert all(old['method_body'][k]==new['method_body'][k] for k in oldhelper)
 outs_only=[k for k in oldcap if k in newcap and oldcap[k]['outgoing']!=newcap[k]['outgoing'] and old['method_body'][k]==new['method_body'][k]]
 report={'result':'PASS','version':version,'input':{'path':str(oldapk),'sha256':base.sha(oldapk.read_bytes())},'output':{'path':str(newapk),'sha256':base.sha(newapk.read_bytes())},'scope':{k:len(old[k]) for k in ['class','field','method']},'differences':dif,'normalized_outs_size_only':outs_only,'checks':{'only_two_existing_method_bodies_change':True,'existing_method_tails_registers_and_exception_handlers_unchanged':True,'all_existing_method_declarations_unchanged':True,'client_interface_only_metadata_change':True,'one_native_boolean_field_and_three_native_methods_added':True,'runtime_additions_confined_to_namespace':True,'all_original_four_helper_method_bodies_unchanged':True,'original_helper_method_count':len(oldhelper),'manifest_and_other_resources_byte_identical':True,'arsc_content_equivalent':True,'arsc_byte_identical':not arsc_diff,'all_outs_sizes_cover_invoke_register_counts':True},'non_dex_changes':resources,'limits':['Physical Android rendering/installation not tested','Debug line metadata and APK signing/layout excluded','outs_size reductions allowed only if still sufficient for every invoke and all other body content is equal']}
 (OUT/('INDEPENDENT_repair_audit_'+version+'.json')).write_text(json.dumps(report,ensure_ascii=False,indent=2)+'\n')
 print(json.dumps({k:report[k] for k in ['result','version','scope','checks']},ensure_ascii=False),flush=True)
 gc.collect()

run('383740',ROOT/'original_diagnostic101/production/validation_unsigned.apk',OUT/'validation/original383740/validation_unsigned.apk','Lc70;','Lc41;','Lsm2;','v','Ltt5;')
run('383931',ROOT.parent/'upload/Berry_Browser-v3.83.93.1-Hiro_Morphe_Patches-v1.0.328.apk',OUT/'validation/modified383931_same_repair_only/validation_unsigned.apk','Lt70;','Lu51;','Le87;','y','Lxw5;')
